import React, {Component} from 'react';

const CustomInput = (props) => {
    return (  
  <div className="form-group">
       <input
      className="form-input"
      id={props.name}
      name={props.name}
      type={props.type}
      value={props.value1}
      onChange={props.handleChange}
      placeholder={props.placeholder}
      class={props.className} 
    />
  </div>
)
}

export default CustomInput;