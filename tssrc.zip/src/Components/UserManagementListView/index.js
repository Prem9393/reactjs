import React, { Component } from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';
import Table from '../../Components/Table/table';
import styles from './listview.css';

const TableColumn = (props) => {
    if(props.column) {
        return props.column.map((item, index) => {
            return <th key={index}>{item.label}</th>
        });
    }
    return true;
}

class UserManagementListView extends Component {

    constructor(props){
        super(props);
    }

    defaultImageforUser(first_name, last_name){
        let name = first_name.charAt(0) + last_name.charAt(0);
        return name.toUpperCase();
    }

    render(){
        return (
            <div className="user-management-list-view">
                <div class="profile-list-section">
                    <div class="table-responsive">
                        <table class="table profile-list-table table-hover w-auto">
                            <thead>
                                <tr>
                                    <th scope="col" class="th-lg ">Name</th>
                                    <th scope="col">GLN</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.props.userDetails.map((user, index) => 
                                    <tr key={index}>
                                        <td>
                                            <div class="profile-list-name">
                                                <img src={(user.user_image) ? Config.user_img_path + user.user_image.trim() : this.defaultImageforUser(user.user_name, user.last_name) } class="img-responsive" alt={this.defaultImageforUser(user.user_name, user.last_name)}/>
                                                <p>{user.user_name}</p>	
                                            </div>
                                        </td>
                                        <td>{user.InformationProviderGLN}</td>
                                        <td>{user.user_type}</td>
                                        <td>{user.email}</td>
                                        <td> {user.user_telephone}</td>
                                        <td>
                                            <div class="edit-del-btn-wrapper">
                                                <Link to={'edituser/'+user.id}>DELETE</Link>
                                                <Link to={'edituser/'+user.id} class="btn bypass-btn">Edit</Link>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        )
    }
}

export default UserManagementListView;