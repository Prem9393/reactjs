import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';

class SlidingPanelTitle extends Component{
    constructor(props){
        super(props);
    }
    render(){

        return  (           
            <div className="row">
				<div className="col-md-6">
					<p className="slide-pane_product-id">
						<span>{this.props.autoqc_details !=  undefined ? this.props.autoqc_details.GTIN : ''}</span>
					</p>
				</div>
				<div className="col-md-6">
					<div className="modal-btn-wrapper">
						<button type="button" className="btn btn-primary">Move to ManualQC</button>
					</div>
				</div>
            </div>
       );
    }
}

export default SlidingPanelTitle;


