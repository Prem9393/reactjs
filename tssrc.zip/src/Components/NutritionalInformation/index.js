import React, { Component } from 'react';
  /*import Select from 'react-select';
const options = [
  { value: 'chocolate', label: 'Chocolate' },
   { value: 'strawberry', label: 'Strawberry' },
   { value: 'vanilla', label: 'Vanilla' } 
];*/

class NutritionalInformation extends Component {
   constructor(props) {
      super(props)
      this.handleSelectChange = this.handleSelectChange.bind(this);
      this.displayTableData = this.displayTableData.bind(this);
      this.handleServingSideChange = this.handleServingSideChange.bind(this);
      this.nutrition_filters = this.nutrition_filters.bind(this);
      this.state = {
         removeSelected: true,
         disabled: false,
         value: [],
         rtl: false,
      }
      this._table_list = '';
      this._allergens_list = '';
   }

   nutrition_filters(options) {
      var _options = '';
      if (options.length) {
         _options = options.map((item, index) => {
            return <option key={index} value={item.servingSize}>{item.servingSize} </option>
         });
      }
      return _options;
   }

   displayTableData(value) {
      if (value && value.length) {
         this._table_list = value.map((list, key) => {
            if (list) {
               return <tr key={key}><td>{list.nutrientTypeCode}</td><td>{list.nutrientName}</td><td>{list.quantityContained}</td><td>{list.quantityContainedUom}</td><td></td></tr>;
            }
         })
      }
      else {
         this._table_list = <tr><td colspan="5"> No Nutrition Data Uploaded</td></tr>;
      }

      return this._table_list;
   }

   displayAllergens(value) {
      if (value && value.length) {
         this._allergens_list = value.map((list, key) => {
            if (list) {
               return <tr key={key}><td>{list.allergen}</td><td>{list.containment}</td></tr>;
            }
         })
      }
      else {
         this._allergens_list = <tr><td colspan="5"> No Allergens Data Uploaded</td></tr>;
      }

      return this._allergens_list;
   }


   handleSelectChange = (value) => {
      this.setState({ value });
   }

   handleServingSideChange(event) {
      var _nutrition_details = {
         token: this.props.token,
         gtin: this.props.match.params.gtin,
         serving_size: event.target.value,
      }
      this.props.handleNutritionValue(_nutrition_details);
   }

   render() {
      //const { value } = this.state;
      return (<div className="col-xs-12 col-md-8 food_nutritional">
         <div className="nutri_info lightgray">
            <h3>Nutritional Information <span className="pull-right">% Daily Value*</span></h3>
            <div className="form-group">
               <label>Serving Size</label>
               <select className="form-control select2 select2-hidden-accessible" value={this.props.nutrition_filters[0] ? this.props.nutrition_filters[0]['servingSize'] : ''} name="serving_size" onChange={this.handleServingSideChange}>
                  <option value="">Select Size</option>
                  {this.nutrition_filters(this.props.nutrition_filters)}
               </select>
            </div>
            <div className="box myBox">
               <div className="box-body">
                  <table className="table table-bordered table-striped">
                     <thead>
                        <tr>
                           <th>Nutrient Code</th>
                           <th>Nutrient Name</th>
                           <th>Quantity</th>
                           <th>Uom</th>
                           <th>% Daily Value</th>
                        </tr>
                     </thead>
                     <tbody>
                        {this.displayTableData(this.props.nutritions)}
                     </tbody>
                  </table>
               </div>
            </div>
            <h3>Ingredients</h3>
            <div className="form-group">
               <input type="text" className="type form-control" value={this.props.nutrition_ingredients} />
            </div>
            <h3>Allergens</h3>
            <div className="box myBox">
               <div className="box-body">
                  <table className="table table-bordered table-striped">
                     <thead>
                        <tr>
                           <th>Allergen</th>
                           <th>Containment</th>
                        </tr>
                     </thead>
                     <tbody>
                        {this.displayAllergens(this.props.nutrition_allergens)}
                     </tbody>
                  </table>
               </div>
            </div>
            {/* <div className="form-group">

               <Select id="status-select" options={options} clearable={true} searchable={true} placeholder={false} defaultValue={value}
                  onChange={this.handleSelectChange} multi />

            </div> */}
            <h3>Other Information</h3>
            <div className="otinfo_accr darkgryhead" id="otinfo_accr">
               <div className="row">
                  <div className="col-xs-12 col-sm-6">
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr1">
                                 Claims
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr1" className="panel-collapse collapse">
                           1
                           </div>
                     </div>
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr2">
                                 Certifications
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr2" className="panel-collapse collapse">
                           2
                           </div>
                     </div>
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr3">
                                 GMO Disclosure
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr3" className="panel-collapse collapse">
                           3
                           </div>
                     </div>
                  </div>
                  <div className="col-xs-12 col-sm-6">
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr4">
                                 Health &amp; Safety
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr4" className="panel-collapse collapse">
                           1
                           </div>
                     </div>
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr5">
                                 Product Instructions
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr5" className="panel-collapse collapse">
                           2
                           </div>
                     </div>
                     <div className="panel panel-default">
                        <div className="panel-heading">
                           <h4 className="panel-title">
                              <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr6">
                                 Sustainability
                                 </a>
                           </h4>
                        </div>
                        <div id="otinfo_accr6" className="panel-collapse collapse">
                           3
                           </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      );
   }
}

export default NutritionalInformation;