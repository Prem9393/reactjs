import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import Config from '../../Config';
import Moment from 'moment';

const TableColumn = (props) => {
    if(props.column) {
        return props.column.map((item, index) => {
            return <th key={index}>{item.label}</th>
        });
    }
    return true;
}

const QualityControlStatus = (props) => {
    return <td key={props}><div className="form-group"><div className="radio"><i className="fa fa-check-circle"></i></div><div className="radio"><i className="fa fa-times-circle"></i></div></div></td>;
}

const fontAwesome = (index, props) => {
    if(props) {
        return <td key={index}><i className={props}></i></td>
    } else {
        return <td key={index}></td>
    }
}

const assignedTo = (props) => {
    return <td  key={props}><div className="form-group"><select className="form-control"><option>Select</option><option>Sifiso Buthelezi</option><option>Dimakatso Mnisi</option><option>Esther Young</option><option>Thembi Xaba</option><option>Ruth Cilliers</option></select></div></td>;
}

const ProductBrowserStatusImage = (index, props) => {
    return <td key={index}><div className="text-center status_percentage"><img src={Config.thumbnail_img_path+props.status_image} alt="" /><p className="text-info">{props.status}</p></div></td>
}

const ProductBrowserImage = (index, props) => {
    return <td key={index}><div className="prdt_img"><div><img src={(props.product_image_name) ? Config.thumbnail_img_path + props.product_image_name : Config.assetspath + 'default.png'} alt="" /><div className="imgratio"><span><i className="fa fa-image"></i><span className="pixels">{props.total_images}x</span></span></div></div></div></td>
}

const UserImage = (index, props) => {
    return <td key={index}><div className="prdt_img"><div><img src={(props.user_image) ? Config.user_img_path + props.user_image : Config.assetspath + 'default.png'} alt="" /><div className="imgratio"><span><i className="fa fa-image"></i><span className="pixels">{props.total_images}x</span></span></div></div></div></td>
}

const AddRequestToQueue = (index, data , props) => {
    return <td key={index}>
        <div className="text-center"> 
            <div className="add-btn" data-action={(data.add_to_queue) ? 'remove' : 'add'} data-gtin={data.GTIN} type='button' onClick={props.handleBasket}><i className={(data.add_to_queue) ? 'fa fa-close fa-2x' : 'fa fa-plus-circle fa-2x'}></i></div>
        </div>                             
    </td>
}

const ProductEditLink = (index, data, props) => {
    if(props.user_type == 4 || props.user_type == 1 || props.user_type == 5 || props.user_type == 6 ){
        return <td key={index}>
            <div><Link to={Config.userPath[props.user_type]+'editproduct/'+data.GTIN}>{data.product_name}</Link></div>
        </td>
    } 
    return <td key={index}>
            <div>{data.product_name}</div>
        </td>
}

const UserEditLink = (index, data, props) => {
    
    return <td key={index}>
        <div><Link to={'edituser/'+data.id}>{data.first_name}</Link></div>
    </td>
}

const CompanyEditBtnLink = (index, data, props) => {
    if(props.user_type == 3 || props.user_type == 4){
        return ( <span key={index}><Link to={Config.userPath[props.user_type]+'editcompany/'+data.id}>
                        <div className="btn btn-info btn-sm edit-btn" >
                                    Edit
                        </div>
                  </Link>
             </span>);
          
    } else {
        return <span key={index}>
            <div> 
                   <span className="btn btn-info btn-sm edit-btn" >
                     Edit
                  </span>
            </div>
        </span>
    }
}


const AcceptBtnBtnLink = (index, data, props) => {
   
    return (<button type="button" className="btn bypass-btn"
     onClick={() => props.OpenPanel(data.aID, data.GTIN, data.GUID)}>Accept</button>)
}


const CompanyEditLink = (index, data, props) => {
    if(props.user_type == 3 || props.user_type == 4){
        return <td key={index}>
                 <div><Link to={Config.userPath[props.user_type]+'editcompany/'+data.id}>{data.CompanyName}</Link></div>
              </td>
    } else {
        return <td key={index}>
            <div>{data.CompanyName}</div>
        </td>
    }
}

const AutoQcProductEditLink = (index, data, props) => {
   
  //if(props.user_type == 3){
        return <td key={index} onClick={() => props.OpenPanel(data.time, data.GTIN, data.GUID,data.aID)}>
              <div >{data.GTIN}</div>
           </td>
  // }
}

const ManualQcProductEditLink = (index, data, props) => {
    
    if(props.user_type == 3){
        return <td key={index}>
              <div  onClick={() => props.OpenPanel(data.pID, data.GTIN)}>{data.GTIN}</div>              
           </td>
    }
}

const AutoQcProductName = (index, data, props) => {
    
        return <td className="anchor-link" key={index} onClick={() => props.OpenPanel(data.time, data.GTIN, data.GUID, data.aID)}>
        <div >{data.gtinName+' ['+data.productType+'] '}</div>
    </td>
}

const AutoQcDate = (index, data, props) => {
        Moment.locale('en');
        var dt = data.time;

        return <td key={index}>
              <div>{Moment(dt).format('MMM Do YYYY')}</div>          
           </td>
}

const AutoQcStatusCode = (index, data, props) => {
    
    return <td key={index}>
        <div className="status-td">
            <p>REJECTED</p>
                <div className="progress">
                    <div className="progress-bar" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style={{width: "25%"}}></div>
                </div>
        </div>
</td>
}

const AutoQcBypass = (index, data, props) => {    
    return <td key={index}>
    <button type="button" className="btn btn-primary bypass-btn">Bypass</button>
</td>
}


const callBack = (function_name, index, data, column_value,props) => {
    let funcation_data = [];
    if(function_name === 'QualityControlStatus') {
        funcation_data = QualityControlStatus(index);
    } else if(function_name === 'fontawesome') {
        funcation_data = fontAwesome(index, column_value);
    } else if(function_name === 'assigned') {
        funcation_data = assignedTo(index);
    } else if(function_name === 'ProductBrowserStatusImage') {
        funcation_data = ProductBrowserStatusImage(index, data);
    } else if(function_name === 'ProductBrowserImage') {
        funcation_data = ProductBrowserImage(index, data);
    }else if(function_name === 'AddRequestToQueue') {
        funcation_data = AddRequestToQueue(index, data, props);
    }else if(function_name === 'ProductEditLink') {
        funcation_data = ProductEditLink(index, data, props);
    } else if(function_name === 'UserEditLink') {
        funcation_data = UserEditLink(index, data, props);
    } else if(function_name === 'UserImage') {
        funcation_data = UserImage(index, data, props);
    } else if(function_name === 'CompanyEditLink') {
        funcation_data = CompanyEditLink(index, data, props);
    } else if(function_name === 'CompanyEditBtnLink') {
        funcation_data = CompanyEditBtnLink(index, data, props);
    } else if(function_name === 'AutoQcProductEditLink') {
        funcation_data = AutoQcProductEditLink(index, data, props);
    } else if(function_name === 'ManualQcProductEditLink') {
        funcation_data = ManualQcProductEditLink(index, data, props);
    } else if(function_name === 'AutoQcProductName') {
        funcation_data = AutoQcProductName(index, data, props);
    } else if(function_name === 'AutoQcDate') {
        funcation_data = AutoQcDate(index, data, props);
    } else if(function_name === 'AutoQcStatusCode') {
        funcation_data = AutoQcStatusCode(index, data, props);
    } else if(function_name === 'AutoQcBypass') {
        funcation_data = AutoQcBypass(index, data, props);
    }else if(function_name === 'AcceptBtnBtnLink') {
        funcation_data = AcceptBtnBtnLink(index, data, props);
    }
    
    return funcation_data;
}

const TableRows = (props) => {
    console.log("props.rows.here",props);

    if(props.rows){
        if(  props.rows.length > 0) {
            let no_of_columns = props.column.length;
            return props.rows.map((item, index) => {
                let rows = [];
                for(let i = 0; i < no_of_columns; i++) {
                     
                    if(props.column[i].type === 'checkbox') {     
                           
                            var checkbox = <div className="form-group"><input type="checkbox" checked={props.state.items.checked} className="custom-control-input" name="tablecheckbox[]" id={"customCheck"+index} onClick={() => props.getCheckboxCount(index)} />
                            <label className="custom-control-label td-label" htmlFor={"customCheck"+index}></label>
                            {/* <input type="checkbox" /><label>dsa</label> */}</div>
                            rows.push(<td key={i}>{checkbox}</td>);                      
                        
                    } else if(props.column[i].type === 'callback') {
                       
                        let data = callBack(props.column[i].callback_function, i, item, item[props.column[i].key],props);
                        rows.push(data);
                    } 
                    else if(props.column[i].type ==='EditBtn') {
                    let Editdata = callBack(props.column[i].callback_function, i, item, item[props.column[i].key],props);
                 
                        let btn = ( <span className="EditAndDelete"> 
                                        {Editdata}
                                        
                                        { props.user_type == 3 || props.user_type == 4 ? <span className="btn btn-danger btn-sm delete-btn" id={item.id} onClick={() => props.DeleteCompany(item.id)}>
                                            Delete 
                                        </span> : '' }
                                    </span>
                            );

                        rows.push(<td key={i}>{btn}</td>);

                    }else if(props.column[i].type ==='AcceptBtn') {
                        let AcceptBtn = callBack(props.column[i].callback_function, i, item, item[props.column[i].key],props);
                     
                        
                            let btn = ( <span className="EditAndDelete"> 
                                            {AcceptBtn}                                           
                                        </span>
                                );
    
                            rows.push(<td key={i}>{btn}</td>);
    
                    }
                    else if(props.column[i].key === 'UserName'){
                        rows.push(<td key={i}>{item.company_admin_supplier!= null ? item.company_admin_supplier.first_name+item.company_admin_supplier.last_name : ''}</td>);
                    } 
                    else if(props.column[i].key === 'UserEmail'){
                        rows.push(<td key={i}>{item.company_admin_supplier != null ? item.company_admin_supplier.email : ''}</td>);
                    }
                    else if(props.column[i].key === 'CompanyLogo'){ 
                        
                       let img = <img src={(item.CompanyLogo) ? Config.user_img_path + item.CompanyLogo : Config.companylogopath + 'default.png'} alt={item.CompanyName} className="img-circle company_logo"/>
                       rows.push(<td key={i}>{img}</td>);
                    }
                    else {
                        rows.push(<td key={i}>{item[props.column[i].key]}</td>);
                    }

                   
                }
                return <tr key={index}>{rows}</tr>
            });
        }else{
            if(props.name == 'company_profile'){
                return <tr><td colSpan="9" className='no_products text-center'>No Companies found.</td></tr>;
            } else if(props.name == 'prefix_management'){
                return <tr><td colSpan="12" className='no_products text-center'>No Prefix found.</td></tr>;
            } else if(props.name == 'user_management'){
                return <tr><td colSpan="9" className='no_products text-center'>No Users found.</td></tr>;
            } else {
                return <tr><td colSpan="" className='no_products text-center'>No Products found.</td></tr>;
            }
           // return <tr><td colSpan="9" className='no_products text-center'>No Products found.</td></tr>;
        }
    }
    else{
        if(props.name == 'company_profile'){
            return <tr><td colSpan="9" className='no_products text-center'>No Companies found.</td></tr>;
        } else if(props.name == 'prefix_management'){
            return <tr><td colSpan="12" className='no_products text-center'>No Prefix found.</td></tr>;
        } else if(props.name == 'user_management'){
            return <tr><td colSpan="9" className='no_products text-center'>No Users found.</td></tr>;
        } else {
            return <tr><td colSpan="" className='no_products text-center'>No Products found.</td></tr>;
        }
        
    }
}

export default class TableComponent extends Component {
    constructor(props){
        super(props);
        this.handleBasket = this.handleBasket.bind(this);
    }
    handleBasket(e){
        let action = e.currentTarget.dataset.action;
        let gtin = e.currentTarget.dataset.gtin;

        let basket_products = document.getElementById( 'basket_products' ).value;
        if(basket_products !== '1'){
            if(action === 'add'){
                e.currentTarget.dataset.action = 'remove';
                e.target.className = 'fa fa-close fa-2x'
            }else{
                e.currentTarget.dataset.action = 'add';
                e.target.className = 'fa fa-plus-circle fa-2x'
            }
        }
        this.props.manageBasket(gtin,action);
    }
    render() {
        
        return (
            <table id={this.props.name} name={this.props.name} className={this.props.classname}>
                <tbody>
                    <tr>
                        <TableColumn {...this.props} />
                    </tr>

                    <TableRows handleBasket={this.handleBasket} {...this.props} />
                </tbody>
            </table>
        )
    }
}