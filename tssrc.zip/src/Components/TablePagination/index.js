/* Pagination Component -------------------------------------------------*/

import React, { Component } from 'react';
import { connect } from 'react-redux';
import ActionCreators from  '../../Actions/ActionCreators';



class TablePagination extends React.Component {
    constructor(props) {
        super(props);
        this.state = { pager: {}, pageOfItems:[] };
    
        
        
    }

    componentWillMount() {
        // set page if items array isn't empty
        if (this.props.items && this.props.items.length) {
            this.setPage(this.props.initialPage);
        }
    }

    componentDidUpdate(prevProps, prevState) {
        // reset page if items array has changed
        if (this.props.items !== prevProps.items) {
            this.setPage(this.props.initialPage);
        }
    }

    setPage(page) {

      
        
        var items = this.props.items;
        var pager = this.state.pager;
        var pageSize = this.props.pageSize;
          
       

        if (page < 1 || page > pager.totalPages) {
            return;
        }

        // get new pager object for specified pa                                                    ge
        pager = this.getPager(items.length, page, pageSize);

        

        // get new page of items from items array
        var pageOfItems = items.slice(pager.startIndex, pager.endIndex + 1);

        this.setState({pageOfItems: pageOfItems});
        // update state
        this.setState({ pager: pager });
        // call change page function in parent component
       this.props.onChangePage(pageOfItems);



       //   this.props.dispatch( ActionCreators.currentPageData(this.state.pageOfItems) )
    
         //console.log("how many times", pageOfItems)
    

    }

    getPager(totalItems, currentPage, pageSize) {
        // default to first page
        currentPage = currentPage || 1;

        console.log("hee", pageSize)

        // default page size is 10
        pageSize = pageSize || 10;

        // calculate total pages
        var totalPages = Math.ceil(totalItems / pageSize);

        var startPage, endPage;
        if (totalPages <= 10) {
            // less than 10 total pages so show all
            startPage = 1;
            endPage = totalPages;
        } else {
            // more than 10 total pages so calculate start and end pages
            if (currentPage <= 6) {
                startPage = 1;
                endPage = 10;
            } else if (currentPage + 4 >= totalPages) {
                startPage = totalPages - 9;
                endPage = totalPages;
            } else {
                startPage = currentPage - 5;
                endPage = currentPage + 4;
            }
        }

        // calculate start and end item indexes
        var startIndex = (currentPage - 1) * pageSize;
        var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

        // create an array of pages to ng-repeat in the pager control
        var pages = [...Array((endPage + 1) - startPage).keys()].map(i => startPage + i);

        // return object with all pager properties required by the view
        return {
            totalItems: totalItems,
            currentPage: currentPage,
            pageSize: pageSize,
            totalPages: totalPages,
            startPage: startPage,
            endPage: endPage,
            startIndex: startIndex,
            endIndex: endIndex,
            pages: pages
        };
    }

    render() {

 
        
        var pager = this.state.pager;

        if (!pager.pages || pager.pages.length <= 1) {
            // don't display pager if there is only 1 page
            return null;
        }

        return (
            <ul className="pagination">
                <li className={pager.currentPage === 1 ? 'disabled' : ''}>
                    <a onClick={() => this.setPage(1)}>«</a>
                </li>
                <li className={pager.currentPage === 1 ? 'disabled' : ''}>
                    <a onClick={() => this.setPage(pager.currentPage - 1)}>⟨</a>
                </li>
                {
                    pager.pages.map((page, index) =>
                    <li key={index} className={pager.currentPage === page ? 'active' : ''}>
                        <a onClick={() => this.setPage(page)}>{page}</a>
                    </li>)
                }
                <li className={pager.currentPage === pager.totalPages ? 'disabled' : ''}>
                    <a onClick={() => this.setPage(pager.currentPage + 1)}>⟩</a>
                </li>
                <li className={pager.currentPage === pager.totalPages ? 'disabled' : ''}>
                    <a onClick={() => this.setPage(pager.totalPages)}>»</a>
                </li>
            </ul>
        );
    }
}




// const propTypes = {
//     items: React.PropTypes.array.isRequired,
//     onChangePage: React.PropTypes.func.isRequired,
//     initialPage: React.PropTypes.number    
// }

// const defaultProps = {
//     initialPage: 1
// }


// TablePagination.propTypes = propTypes;
// TablePagination.defaultProps = defaultProps;

//  const mapDispatchToProps = (dispatch) => {

//      console.log('dis', dispatch)
//      return {
//          dispatch
//      }
//  }

export default TablePagination;



// $('#pagination-demo').twbsPagination({
// totalPages: 5,
// // the current page that show on start
// startPage: 1,

// // maximum visible pages
// visiblePages: 5,

// initiateStartPageClick: true,

// // template for pagination links
// href: false,

// // variable name in href template for page number
// hrefVariable: '{{number}}',

// // Text labels
// first: 'First',
// prev: 'Previous',
// next: 'Next',
// last: 'Last',

// // carousel-style pagination
// loop: false,

// // callback function
// onPageClick: function (event, page) {
// 	$('.page-active').removeClass('page-active');
//   $('#page'+page).addClass('page-active');
// },

// // pagination Classes
// paginationClass: 'pagination',
// nextClass: 'next',
// prevClass: 'prev',
// lastClass: 'last',
// firstClass: 'first',
// pageClass: 'page',
// activeClass: 'active',
// disabledClass: 'disabled'

// });



