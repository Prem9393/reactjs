import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';

class UserProfileBox extends Component{
    constructor(props){
        super(props);
    }
    render(){

        return  (
            
                <div className="user_profile">
                <div class="col-md-4">      
                <Link to={'edituser/'+this.props.userDetails.id}>                             
                    <div class="box box-widget widget-user">                                   
                    <div class="widget-user-header bg-aqua-active">
                        <h3 class="widget-user-username">{this.props.userDetails.first_name.trim()}</h3>
                        <h5 class="widget-user-desc">{this.props.userDetails.email.trim()}</h5>
                    </div>
                    <div class="widget-user-image">
                        <img class="img-circle" src={(this.props.userDetails.user_image) ? Config.user_img_path + this.props.userDetails.user_image : Config.companylogopath + 'default.png'} alt="User Avatar" />
                    </div>
                    <div class="box-footer">
                        <div class="row">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                            <h5 class="description-header">{this.props.userDetails.InformationProviderGLN.trim()}</h5>
                            <span class="description-text">GLN</span>
                            </div>                                           
                        </div>                                       
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                            <h5 class="description-header">{this.props.userDetails.user_type}</h5>
                            <span class="description-text">Type</span>
                            </div>                                           
                        </div>
                        <div class="col-sm-4">
                            <div class="description-block">
                            <h5 class="description-header">{this.props.userDetails.user_telephone}</h5>
                            <span class="description-text">Phone</span>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                    </Link>                                    
                </div>
        </div>
                        );
    }
}

export default UserProfileBox;


