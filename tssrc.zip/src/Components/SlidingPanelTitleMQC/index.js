import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';

class SlidingPanelTitleMQC extends Component{
    constructor(props){
        super(props);
       
    }
    render(){
       
        return  ( 
			<div class="row">
				<div className="col-md-6">
					<p className="slide-pane_product-id"><span>{this.props.manualqc_details !=  undefined ? this.props.manualqc_details.GTIN : ''}</span></p>
					<h3 className="titleProductName">{this.props.manualqc_details.gtinName !=  undefined ? this.props.manualqc_details.gtinName : ''}</h3>
				</div>
				<div className="col-md-6">
					<div class="modal-btn-wrapper">
						<button type="button" className="btn btn-primary accept-btn">Accept Publication</button>
						<button type="button" className="btn btn-primary reject-btn">Reject Publication</button>
					</div>
				</div>
			</div>
       );
    }
}

export default SlidingPanelTitleMQC;


