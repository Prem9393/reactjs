import React, { Component } from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';
import styles from './cardview.css';

class UserManagementCardView extends Component {
    constructor(props){
        super(props);
    }    

    capitalizeFirstLetter(name){
        return name.charAt(0).toUpperCase() + name.slice(1)
    }

    defaultImageforUser(first_name, last_name){
        let name = first_name.charAt(0) + last_name.charAt(0);
        return name.toUpperCase();
    }

    render(){
        // console.log()
        return (
            <div className="user-management-card-view">
                <div class="profile-card-section">
                    <div class="row">
                    <div class="col-md-3">
                        <div class="add-new-profile-wrapper profile-grid">
                            <a >
                                <div class="add-img-wrapper img-name-wrapper">
                                    <img src="assets/images/add-new.svg" class="img-responsive" />
                                    <div class="add-profile-text">
                                        <Link to={Config.userPath[this.props.usertype]+'insertuser'}>Add User </Link>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    {this.props.userDetails.map((user, index) =>
                        <div class="col-md-3" key={index}>
                            <div class="profile-grid">
                                <Link to={'edituser/'+user.id}>
                                    <div class="img-profile-wrapper">
                                        <img src={(user.user_image) ? Config.user_img_path + user.user_image.trim() : this.defaultImageforUser(user.user_name, user.last_name)} class="img-responsive" alt={this.defaultImageforUser(user.user_name, user.last_name)}/>
                                        <div class="profile-pos">
                                            <h2>{user.user_type.toUpperCase()}</h2>
                                        </div>
                                        <div class="profile-name">
                                            <p class="name">{this.capitalizeFirstLetter(user.user_name)}</p>
                                            <p class="desgination">{user.user_type}</p>
                                        </div>
                                    </div>
                                    <div class="profile-details">
                                        <ul>
                                            <li class="profile-id">
                                                <img src="assets/images/user.svg" class="img-responsive" />
                                                <p><span>GLN</span>
                                                    {user.InformationProviderGLN}
                                                </p>
                                            </li>
                                            <li class="profile-email">
                                                <img src="assets/images/email.svg" class="img-responsive" />
                                                <p><span>Email</span>
                                                    {user.email}
                                                </p>
                                            </li>
                                            <li class="profile-phone">
                                                <img src="assets/images/phone.svg" class="img-responsive" />
                                                <p><span>Phone</span>
                                                    {user.user_telephone}
                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                </Link>
                            </div>
                        </div>
                    )}
                </div>
                </div>
            </div>
        );
    }
}

export default UserManagementCardView;