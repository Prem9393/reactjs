import React, {Component} from 'react';
import { Field } from 'redux-form';

const lang = ['NL','XU']; 

const LanguageSet = (props) => {
    
    return (  
        <div className="form-group">
        <label>Brand Name</label>
       <div className="input-group lang_div">
          
           <span class="input-group-addon">EN</span>
           <Field name={PREFIX+'languageSpecificBrandName[en]'}  placeholder={"Brand Name EN"} component={Common.renderInput} type="text" id="cu_brandname" className="col-md-8 form-control hsmall" onBlur={this.props.handleChange.bind(this, 'cu')} />
           {/* <button type="button" onClick={()=> this.setState({addLang_BrandName: true}) } className="btn-lang">Other Language</button> */}

           <button type="button" onClick={()=> this.setState({addLang_BrandName: true})} className="col-md-2 btn-lang"><i class="fa fa-plus"></i></button>
       </div>

           {
                props.addLang_BrandName ? 

                lang.map((value, index)=>(
                    <div key={index}  className="input-group lang_div lang_div1">
                    <span class="input-group-addon">{value}</span>
                <Field name={"cu_languageSpecificBrandName["+value.toLocaleLowerCase()+"]"} placeholder={"Brand Name "+value} component={Common.renderInput} type="text" id={"cu_brandname["+value+"]"} className="col-md-12 form-control hsmall" onBlur={this.props.handleChange.bind(this, 'cu')} />

                </div>))
                :""
            }

       </div>


    )
}

export default LanguageSet;