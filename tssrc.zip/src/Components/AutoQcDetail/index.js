import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';
import serialize from 'form-serialize';
import ActionCreators from '../../Actions/ActionCreators';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import  './AutoQcDetail.css';
import Moment from 'moment';

const ParentList = (props) => {  
    console.log  (props.state);
    if(props.autoqc_parent_details != undefined ){
              return ( <div className="form-group">
                    <div className="inline-checkbox">
                        {
                        Object.values(props.autoqc_parent_details).length > 0 ? 
                        Object.values(props.autoqc_parent_details).map((list,index) => (
                        <div key={list.aID} className={index == 0 ? 'autoqc parent' +(props.state["differences_"+list.productType] == false ? ' active'  : '')  : 'autoqc sub'+index+(props.state["differences_"+list.productType] == false ? ' active'  : '')  }><a onClick={() => props.OnChangeValue(list.time, list.GTIN, list.GUID,list.aID)}>{list.gtinName} </a></div>  )): 'No Product(s) Found'                                           
                            }
                    </div>
              </div> )
        }
    return '';
}


class AutoQcDetail extends Component{
    constructor(props){
        super(props);
        this.state = {
            select_data : '',
            aID: '',
            GTIN: '',
            GUID: '',
            time: '',
            show_differences: 'no-difference',
            differences:false,
            differences_EA:false,
            differences_PL:false,
            differences_CS:false,
            differences_SHR:false,
        },
        this.OnChangeValue = this.OnChangeValue.bind(this);
        this.MovetoManualQc = this.MovetoManualQc.bind(this);
        this.OnChangeDateValue = this.OnChangeDateValue.bind(this);
        this.ToggleDiffernces = this.ToggleDiffernces.bind(this);

    }

    OnChangeValue(time, GTIN, GUID, aID){    
         
        this.setState({time:time, 
            GTIN:GTIN, 
            GUID:GUID,
            aID:aID,
            differences:false,
            differences_EA:false,
            differences_PL:false,
            differences_CS:false,
            differences_SHR:false,});
        
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.time = time;
        values.GTIN = GTIN;
        values.aID  = aID;
        values.GUID = GUID;

        this.props.GetAutoQcDetails(values);

        // if(this.props.autoqc_details != undefined && Object.values(this.props.autoqc_details).length > 0 ){
        //     Object.keys(this.props.autoqc_details).map((list,key) => (
        //         (this.props.autoqcrevisiondata[list] != undefined && this.props.autoqcrevisiondata[list] != null  && this.props.autoqcrevisiondata[list] != '' && this.props.autoqcrevisiondata[list] != this.props.autoqc_details[list] ? this.setState({'differences':true})  : '')
        //     ));
        // }

        


        
    }

    OnChangeDateValue(e){
        
        this.setState({'differences': false,
        differences_EA:false,
        differences_PL:false,
        differences_CS:false,
        differences_SHR:false,})
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.aID =  (e.target != undefined  ? e.target.value : '');

        this.props.GetAutoRevisionQcDetails(values);
    }

    


    MovetoManualQc(e) {

    }

    static getDerivedStateFromProps(props, state) {        
                                                                       

       if (props.autoqc_parent_details != undefined  && props.productrevisions.length) {
            var select_date = [
                {'label': 'Choose Date','value': ''}
            ];
          
            props.productrevisions.forEach((revisions, index) => {
                select_date.push({                    
                        'label' : Moment(revisions.time.trim()).format('YYYY-MM-DD HH:mm:ss'),
                        'value' : revisions.aID,
                });
            });
          
           return {
                select_date : select_date,
           }
       } else {
           return true;
       }
   }

    ToggleDiffernces (values) {
        this.setState({"show_differences":values});
    }

    componentDidMount() {
        
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.time = this.props.state.time;
        values.GTIN = this.props.state.GTIN;
        values.GUID = this.props.state.GUID;
        values.aID = this.props.state.aID;

        this.props.GetAutoQcDetails(values);  
              
    }


    render(){
        const {  handleSubmit } = this.props;
       // console.log("this.props",this.props)  ;
        if(this.props.autoqc_details != undefined && Object.values(this.props.autoqc_details).length > 0) { 
            Object.keys(this.props.autoqc_details).map((list,key) => (
                this.props.autoqcrevisiondata[list] != undefined && this.props.autoqcrevisiondata[list] != null  && this.props.autoqcrevisiondata[list] != '' &&this.props.autoqcrevisiondata[list] != this.props.autoqc_details[list] ? (this.state.differences == false) ? this.setState({'differences': true}) : '' : ''));              
        }


        if(this.props.remainingproducts != undefined && Object.values(this.props.remainingproducts).length > 0 ){
            for (const [key, value] of Object.entries(this.props.remainingproducts)) {
                if(this.props.autoqcparentrevisiondetails != undefined && Object.values(this.props.autoqcparentrevisiondetails).length > 0 ){
                   
                    for (const [key2, value2] of Object.entries(value)) {
                        if(this.props.remainingproducts[key][key2] != this.props.autoqcparentrevisiondetails[key][key2] ){
                            
                        //    this.setState({ ['differences_'+key] : false})
                            console.log("2222222","differences_"+key);
                            if(this.state["differences_"+key] == false){
                                this.setState({ ['differences_'+key] : true})
                            }
                           
                        }
                        //
                    }
                }
            }
           
            
        }

        console.log(1222,this.state);

        //console.log("this.props.state",this.state);
            
        return  (
            <div className="autoqcdetail-inner">
                <form id="manage-autoqc" onSubmit={handleSubmit(this.MovetoManualQc.bind(this))}> 
                <div className="insert-company-main">
                <div className="step_3main">
                    <div className="step_3main_detailsform">
                        <div className="insertcompanyform">
                            <div className="cunitform">
                                <div className="row">
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_hierarchy">
                                            <div className="pdform-body">
                                                <h4><strong>Product Hierarchy</strong></h4>
                                                <ParentList {...this.props} state={this.state} OnChangeValue={this.OnChangeValue.bind(this)}/>
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_rejection">
                                            <div className="pdform-body">
                                                <h4><strong>Reason for rejection</strong></h4>
                                                <div className="reason-texarea">
                                                {(this.props.rejectionmessage != undefined ) ?
                                                    <div className="form-group">
                                                            <ul className="inline-checkbox">
                                                                {
                                                                Object.values(this.props.rejectionmessage).length > 0 ? 
                                                                Object.values(this.props.rejectionmessage).map((list,index) => (
                                                                <li>{list}</li>)): 'No Rejection(s) Found'                                           
                                                                    }
                                                            </ul>
                                                    </div> : 'No Rejection(s) Found'
                                                }
                                                    {/* <textarea disabled className={"insertprefixt-text-area"} value={this.props.autoqc_details.Reason} component="textarea" onChange={this.handleChange} /> */}
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_details">
                                            <div className="pdform-body">
                                                <h4><strong>Product Details</strong></h4>
                                                <div className="details-table-sec table min-hscroll">
                                                <table className="editautoqcdetails-tbl" id="editautoqcdetails-tbl" style={{width: '100%'}}>
                                                <tbody>
                                                    <tr>
                                                        <td>Item GTIN</td>
                                                        <td>{this.props.autoqc_details.GTIN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item InformationProviderGLN</td>
                                                        <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item Target Market</td>
                                                        <td>{this.props.autoqc_details.TargetMarketCountryCode}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item product Type</td>
                                                        <td>{this.props.autoqc_details.productType}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item GTIN Name</td>
                                                        <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item Brand Name</td>
                                                        <td>{this.props.autoqc_details.brandOwnerName}</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                                <div>
                                                    <b>Choose Current data to data published on:</b>
                                                        <RenderSelect 
                                                            component={Common.renderInput}
                                                            options={this.state.select_date != null ? this.state.select_date : ''}
                                                            type="select" 
                                                            className="form-control autoqc-head" 
                                                            name="select_date" 
                                                            onChange={this.OnChangeDateValue.bind(this)}
                                                        />
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                </div>
                                
                                <br />
                                <div className="row ">
                                    <div className="col-xs-12 col-sm-12 col-md-12">
                                        <div className="table-list-switcher pull-right modal-switcher">
                                            <input id="modal-toggle-on" className="toggle toggle-left" name="toggle" value="false" type="radio" defaultChecked="checked" onChange={this.handleChange} onClick={() =>this.ToggleDiffernces('no-differences')} />
                                            <label htmlFor="modal-toggle-on" className="btn" onClick={() => this.ToggleDiffernces.bind('no-differences')}>Show All</label>
                                            <input id="modal-toggle-off" className="toggle toggle-right" name="toggle" value="true" type="radio" onClick={() =>this.ToggleDiffernces('hide')} />
                                            <label htmlFor="modal-toggle-off" className="btn" onClick={() =>this.ToggleDiffernces('hide')}>Show Differences</label>
                                        </div>
                                        <div className="produst-selected-details ">                                        
                                                <div className="product-info-details">
                                                    <h4> Selected product item data published to retailers {this.props.autoqc_details.CompanyName}</h4>
                                                    
                                                    <div className="table-responsive">
                                                        <table className="editautoqc-tbl table" id="editautoqc-tbl">
                                                            <tbody>
                                                                <tr>
                                                                    <th>Field Name</th>
                                                                    <th>Current Value</th>
                                                                    <th>Previous Value</th>
                                                                </tr>
                                                                
                                                                
                                                                { this.props.autoqc_details != undefined && Object.values(this.props.autoqc_details).length > 0 ? 
                                                                        Object.keys(this.props.autoqc_details).map((list,key) => (
                                                                            <tr key={key} className={this.props.autoqcrevisiondata[list] != undefined && this.props.autoqcrevisiondata[list] != null  && this.props.autoqcrevisiondata[list] != '' &&this.props.autoqcrevisiondata[list] != this.props.autoqc_details[list] ? 'differences' : this.state.show_differences}>
                                                                                <td>Item {list}</td>
                                                                                
                                                                                <td className={this.props.autoqcrevisiondata[list] != undefined && this.props.autoqcrevisiondata[list] != this.props.autoqc_details[list] ? 'difference-blue' : ''}>{this.props.autoqc_details[list] != undefined  && this.props.autoqc_details[list] != null ? this.props.autoqc_details[list] : '-'}</td>
                                                                                
                                                                                <td className={this.props.autoqcrevisiondata[list] != undefined && this.props.autoqcrevisiondata[list] != this.props.autoqc_details[list] ? 'difference-grey' : ''}>{this.props.autoqcrevisiondata[list] != undefined  && this.props.autoqcrevisiondata[list] != null ? this.props.autoqcrevisiondata[list] :'-'}</td> 
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr> 
                                                                        ) )  : ''
                                                                        
                                                                }
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>
                                    </div>                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        </div>
            );
           
            
    }
    
}

export default AutoQcDetail;


