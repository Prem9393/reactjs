import React,{Component} from 'react';
import {Link} from 'react-router-dom';
import Config from '../../Config'
//import './DottedBox.css';

class InfoBox extends Component{
  render() {
    return (
        <div>         
              <div className="col-lg-3 col-xs-6">
              <div className={this.props.bgName}>
                <div class="inner">
                  <h3>{this.props.count}</h3>
                  <p>{this.props.text}</p>
                </div>
                <div className="icon">
                  <i className={this.props.imagename}></i>
                </div>
                {/* <Link to={this.props.link}>More info <i className="fa fa-arrow-circle-right"></i></Link> */}
              </div>
            </div>
        </div>
    )
  }
}
export default InfoBox
