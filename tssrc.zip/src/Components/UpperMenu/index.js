import React, { Component } from 'react';
import publish_to from './publish_to.png';
import heirarchy from './heirarchy.png';
import { Tabs, Tab } from 'react-bootstrap';
import './UpperMenu.css'
class UpperMenu extends Component {
    constructor(props){
        super(props)
        this.handleMenuClick = this.handleMenuClick.bind(this);
        this.state = {
            uppermenubar: false,
            actionkey: 1,
        };
        
        this.setWrapperRef = this.setWrapperRef.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
        this.handleMenuClick_heirarchy = this.handleMenuClick_heirarchy.bind(this);
        
        this.handleClickOutside = this.handleClickOutside.bind(this);
    }

    handleMenuClick(){
           let _upper_menu_status =   (this.state.uppermenubar===false) ? true :false;
           this.setState({
               uppermenubar:_upper_menu_status,
               actionkey: 1
            });
    }

    handleMenuClick_heirarchy(){
        let _upper_menu_status =   (this.state.uppermenubar===false) ? true :false;
        this.setState({
            uppermenubar:_upper_menu_status,
             actionkey: 2
         });

       
    }

    componentDidMount() {
        document.addEventListener('mousedown', this.handleClickOutside);
    }

    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }

    /**
     * Set the wrapper ref
     */
    setWrapperRef(node) {
        this.wrapperRef = node;
    }

    /**
     * Alert if clicked on outside of element
     */
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.contains(event.target) && !this.state.uppermenubar===false) {
            let _upper_menu_status =   (this.state.uppermenubar===false) ? true :false;
            this.setState({uppermenubar:_upper_menu_status});
        }
    }

    hierarchyData() {
        if(this.props.hierarchy) {
            let _hierarchy_data = this.props.hierarchy.map((item, index) => {
                let hierarchyValue = [];
                for(let i = 0; i < 1; i++) {
                    let _class_name = '';
                    let _heirarchy_name = '';
                    if(item[i].productType === 'EA') {
                        _class_name = 'heirarchy_unit_holder heirarchy_cu_unit';
                        _heirarchy_name = <div className={_class_name}>Unit <span className="heirarch_gints">{item[i].GTIN}</span><span className="heirarchy_unit">x{item[i].totalQuantityOfNextLowerLevelTradeItem}</span></div>;
                    } else if(item[i].productType === 'SHR') {
                        _class_name = 'heirarchy_unit_holder heirarchy_shrink';
                        _heirarchy_name = <div className={_class_name}>Shrink <span className="heirarch_gints">{item[i].GTIN}</span><span className="heirarchy_unit">x{item[i].totalQuantityOfNextLowerLevelTradeItem}</span></div>;
                    } else if(item[i].productType === 'CS') {
                        _class_name = 'heirarchy_unit_holder heirarchy_case';
                        _heirarchy_name = <div className={_class_name}>Case <span className="heirarch_gints">{item[i].GTIN}</span><span className="heirarchy_unit">x{item[i].totalQuantityOfNextLowerLevelTradeItem}</span></div>;
                    } else if(item[i].productType === 'PL') {
                        _class_name = 'heirarchy_unit_holder heirarchy_pallet';
                        _heirarchy_name = <div className={_class_name}>Pallet <span className="heirarch_gints">{item[i].GTIN}</span><span className="heirarchy_unit">x{item[i].totalQuantityOfNextLowerLevelTradeItem}</span></div>;
                    }
                    hierarchyValue.push(<div className="unit_holders_single" key={index}><div className=''>{_heirarchy_name}</div>
                    </div>)
                }
                return hierarchyValue;
            });
            return <div className="unit_holders">{_hierarchy_data.reverse()}</div>
        } else {
            return <div></div>
        }
    }

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    render(){
        return <div>
            <div className="upper_menu_holder">
                <div className="publish_to" onClick={this.handleMenuClick}>
                        <img src={publish_to} alt="publish_to" className="publish_to" />
                        <span>Published To</span>
                </div>
                <div className="hierarchy" onClick={this.handleMenuClick_heirarchy}>
                     <img src={heirarchy} alt="heirarchy" className="heirarchy" />
                     <span>Hierarchy</span>
                </div>
            </div>
            <div ref={this.setWrapperRef} className={"upper_menu_holder_content " + (this.state.uppermenubar ? 'show' : 'hidden')}>
                        <Tabs activeKey={this.state.actionkey} onSelect={this.handleSelect} id="publish_to_tab">
                                <Tab eventKey={1} title="Published To" tabClassName="publish_to_tab" >
                                    {(this.props.publishto) ? 
                                        this.props.publishto.map((lis_details, index)=>{
                                           return  <div className="publish_to_content" key={index}>
                                                <div className="publish_to_name">{lis_details.InformationProviderName}</div>
                                                <div className="publish_to_date">{lis_details.lastSyncDate}</div>
                                            </div>
                                        })
                                    : ''}
                                </Tab>
                                <Tab eventKey={2} title="Hierarchy" tabClassName="heirarchy_tab" >
                                    <div className="heirarchy_tab_holder">
                                        <div className="heirarchy_tab_holder_single">
                                            <div className="sku_code">SKU#{this.props.skucode}</div>
                                            {this.hierarchyData()}
                                        </div>
                                    </div>
                                </Tab>
                        </Tabs>
            </div>
        </div>
    }
}
export default UpperMenu;
