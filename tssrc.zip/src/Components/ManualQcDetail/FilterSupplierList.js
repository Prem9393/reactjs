import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';

class FilterSupplierList extends Component{
    constructor(props){
        super(props);
    }
    render(){

        return  (
            // <ul class="list-unstyled">
            //     <li class="active"><a href="javascript:;">ICU Medical Inc <span class="number">34</span></a></li>
            //     <li><a href="javascript:;">Parmalat SA Pty Ltd <span class="number">23</span></a></li>
            //     <li><a href="javascript:;">Mondelez South Africa Pty Ltd <span class="number">5</span></a></li>
            //     <li><a href="javascript:;">Unilever Foodsolutions SA <span class="number">54</span></a></li>
            //     <li><a href="javascript:;">Unilever South Africa Pty Ltd <span class="number">43</span></a></li>
            //     <li><a href="javascript:;">Reckitt Beckiser SA <span class="number">18</span></a></li>
            //     <li><a href="javascript:;">GS1 South Africa <span class="number">1</span></a></li>
            //     <li><a href="javascript:;">Clover SA Ltd <span class="number">3</span></a></li>
            // </ul>
            <div>
                <ul class="list-unstyled">
                    {                                            
                        Object.values(this.props.manualqcfilterlist).length > 0 ? 
                        Object.values(this.props.manualqcfilterlist).map((list,index) => (                            
                             <li class="active" key={index}><a onClick={this.ManualQcProductsPagination} value={list.InformationProviderGLN.trim()}>{list.company_suppliers != null ? list.company_suppliers.CompanyName.trim() : ''} <span class="number">34</span></a></li>
                        ))
                        : 'No Filter(s) found'
                    }
                </ul>
            </div>
       );
    }
}

export default FilterSupplierList;


