import React, {Component} from 'react';
import Config from '../../Config';
import {Link} from 'react-router-dom';
import serialize from 'form-serialize';
import ActionCreators from '../../Actions/ActionCreators';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import  './AutoQcDetail.css';
import Moment from 'moment';

const ParentList = (props) => {
    console.log(props)
    if(props.manualqc_parent_details != undefined ){
        console.log("props.manualqc_parent_details",props);
        // props.initialize(props.manualqc_parent_details);
              return ( <div className="form-group">
                    <div className="inline-checkbox">
                        {
                        Object.values(props.manualqc_parent_details).length > 0 ? 
                        Object.values(props.manualqc_parent_details).map((list,index) => (
                        <div key={list.aID} className={index == 0 ? 'autoqc parent' +(list.GTIN == props.manualqc_details.GTIN.trim() ? ' active'  : '')  : 'autoqc sub'+index+(list.GTIN.trim() == props.manualqc_details.GTIN.trim() ? ' active'  : '')  }><a onClick={() => props.OnChangeValue(list.aID, list.GTIN, list.GUID,props)}>{list.gtinName} {list.GTIN} - {props.manualqc_details.GTIN.trim()} </a></div>  )): 'No Product(s) Found'                                           
                            }
                    </div>
              </div> )
        }
    return '';
}


class ManualQcDetail extends Component{
    constructor(props){
        super(props);
        this.state = {
            select_data : '',
            aID: '',
            GTIN: '',
            GUID: '',
            show_differences: 'no-difference',
            differences:false,
        },
        this.OnChangeValue = this.OnChangeValue.bind(this);
        this.MovetoManualQc = this.MovetoManualQc.bind(this);
        this.OnChangeDateValue = this.OnChangeDateValue.bind(this);
        this.ToggleDiffernces = this.ToggleDiffernces.bind(this);

    }

    OnChangeValue(aID, GTIN, GUID){        
        this.setState({aID:aID, GTIN:GTIN, GUID:GUID});
        console.log("this.state",this.state)
        
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.aID = aID;
        values.GTIN = GTIN;
        values.GUID = this.props.state.GUID;

        this.props.GetManualQcDetails(values);
    }

    OnChangeDateValue(e){
        
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.aID =  e.target.value;

        this.props.GetManualRevisionQcDetails(values);       
    }

    MovetoManualQc(e) {

    }

    static getDerivedStateFromProps(props, state) {

       if (props.manualqc_parent_details != undefined  && props.productrevisions.length) {
          var select_date = [
              {'label': 'Choose Date','value': ''}
          ];
          
            props.productrevisions.forEach((revisions, index) => {
                select_date.push({                    
                        'label' : Moment(revisions.time.trim()).format('YYYY-MM-DD HH:mm:ss'),
                        'value' : revisions.aID,
                });
            });
          
           return {
                select_date : select_date,
           }
       } else {
           return true;
       }
   }

    componentDidMount() {
        console.log("this.props1",this.props);
        let form = document.querySelector('#manage-autoqc');
        let values = serialize(form, { hash: true });
        values.aID = this.props.state.aID;
        values.GTIN = this.props.state.GTIN;
        values.GUID = this.props.state.GUID;

        this.props.GetManualQcDetails(values);        
    }


    render(){
        console.log("manual qc details",this.props);
        const {  handleSubmit } = this.props;
        return  (
            <div className="autoqcdetail-inner">
                <form id="manage-autoqc" onSubmit={handleSubmit(this.MovetoManualQc.bind(this))}>
                <div className="manual-btn">
                    <input type="hidden" name="GTIN" value={this.props.manualqc_details.GTIN} />
                    <input type="hidden" name="GUID" value={this.props.manualqc_details.GUID} />
                    
                </div>  
                <div className="insert-company-main">
                <div className="step_3main">
                    <div className="step_3main_detailsform">
                        <div className="insertcompanyform">
                            <div className="cunitform">
                                <div className="row">
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_hierarchy">
                                            <div className="pdform-body">
                                                <h4><strong>Product Hierarchy</strong></h4>
                                                <ParentList {...this.props} OnChangeValue={this.OnChangeValue.bind(this)}/>
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_rejection">
                                            <div className="pdform-body">
                                                <h4><strong>Reason for rejection</strong></h4>
                                                <div className="reason-texarea">
                                                    <textarea disabled className={"insertprefixt-text-area"} value={this.props.manualqc_details.Reason} component="textarea" onChange={this.handleChange} />
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="pdform_column product_details">
                                            <div className="pdform-body">
                                                <h4><strong>Product Details</strong></h4>
                                                <div className="details-table-sec table table-responsive">
                                                <table className="editautoqc-tbl" style={{width: '100%'}}>
                                                    <tr>
                                                        <td>Item GTIN</td>
                                                        <td>{this.props.manualqc_details.GTIN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item InformationProviderGLN</td>
                                                        <td>{this.props.manualqc_details.InformationProviderGLN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item Target Market</td>
                                                        <td>{this.props.manualqc_details.TargetMarketCountryCode}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item product Type</td>
                                                        <td>{this.props.manualqc_details.productType}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item GTIN Name</td>
                                                        <td>{this.props.manualqc_details.InformationProviderGLN}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Item Brand Name</td>
                                                        <td>{this.props.manualqc_details.brandOwnerName}</td>
                                                    </tr>
                                                </table>
                                                <div>
                                                    <b>Choose Current data to data published on:</b>
                                                        <RenderSelect 
                                                            component={Common.renderInput}
                                                            options={this.state.select_date != null ? this.state.select_date : ''}
                                                            type="select" 
                                                            className="form-control autoqc-head" 
                                                            name="select_date" 
                                                            onChange={this.OnChangeDateValue.bind(this)}
                                                        />
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                </div>
                                
                                <br />
                                <div className="row ">
                                    <div className="col-xs-12 col-sm-12 col-md-12">
                                        <div className="produst-selected-details ">
                                                <div className="product-info-details">
                                                    {/* <h4> Selected product item data published to retailers </h4> */}
                                                    {/* <div class="btn-group difference_btn_group ">
                                                        <button type="button" class="btn btn-primary">Show all</button>
                                                        <button type="button" class="btn btn-primary">Show Difference</button>                                                    
                                                    </div> */}

                                                
                                                    <div class="col-md-6">
                                                        <div class="product-info-details">
                                                            <h4> Selected product item data published to retailers </h4>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="table-list-switcher pull-right modal-switcher">
                                                            <input id="toggle-on" class="toggle toggle-left" name="toggle" type="radio" value="false" />
                                                            <label for="toggle-on" class="btn">Show all</label>
                                                            <input id="toggle-off" class="toggle toggle-right" name="toggle" type="radio" value="true" />
                                                            <label for="toggle-off" class="btn">Show Difference</label>
                                                        </div>
                                                    </div>

                                                    <div className="col-md-12">
                                                        <div className="table-responsive">
                                                            <table className="editautoqc-tbl table">
                                                                <tr>
                                                                    <th>Field Name</th>
                                                                    <th>New Value</th>
                                                                    <th>Published Value</th>
                                                                </tr>
                                                                { this.props.manualqc_details != undefined && Object.values(this.props.manualqc_details).length > 0 ? 
                                                                        Object.keys(this.props.manualqc_details).map((list,key) => (
                                                                            <tr>
                                                                                <td>Item {list}</td>
                                                                                <td>{this.props.manualqc_details[list]}</td>
                                                                                <td>{this.props.manualqcrevisiondata[list]}</td> 
                                                                            </tr> 
                                                                        ) )  : ''
                                                                        
                                                                }
                                                            </table>
                                                        </div>
                                                    </div>


                                                </div>
                                        </div>
                                    </div>                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        </div>
            );
    }
}

export default ManualQcDetail;


