import {UPDATE_USER_REQUESTED, UPDATE_USER_RECEIVED, UPDATE_USER_ERROR, UPDATE_USER_ERROR_DISPLAY_STATUS } from '../Actions/Actions';
const initailstate = {
    updateuser:[],
    pagenumber:1,
    recordlimit:12,
    totalusers:0,
    updateusermessage:'',
    updatedisplaystatus:{message:""}
}

const updateuserreducer = (state = initailstate, action) =>{
    switch(action.type){

        case UPDATE_USER_REQUESTED:
        return {...state, updateusermessage:action.payload};

        case UPDATE_USER_RECEIVED:
        return Object.assign({}, state, action.payload);

        case UPDATE_USER_ERROR:
        return {...state, updateusermessage:action.payload};
        
        case UPDATE_USER_ERROR_DISPLAY_STATUS:
        console.log("stateeeeprops", state, action.payload)
        return {...state, updatedisplaystatus: action.payload };

        default :
        return Object.assign({}, state)

    }
}


export default updateuserreducer;