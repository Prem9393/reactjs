import {COMPANY_DELETE_REQUESTED,COMPANY_DELETE_RECEIVED,COMPANY_DELETE_ERROR} from '../Actions/Actions';
const initailstate = {
    companydeleteformation:[],
    companydeletemessage : ''
}

const companydeletereducer = (state = initailstate, action) =>{
    switch(action.type){

        case COMPANY_DELETE_REQUESTED:
        return {...state, companydeletemessage:action.payload};

        case COMPANY_DELETE_RECEIVED:
        return Object.assign({}, state, action.payload);

        case COMPANY_DELETE_ERROR:
        return {...state, companydeletemessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default companydeletereducer;

