import {PREFIX_DELETE_REQUESTED,PREFIX_DELETE_RECEIVED,PREFIX_DELETE_ERROR} from '../Actions/Actions';
const initailstate = {
    prefixdeleteformation:[],
    prefixdeletemessage : ''
}

const prefixdeletereducer = (state = initailstate, action) =>{
    switch(action.type){

        case PREFIX_DELETE_REQUESTED:
        return {...state, prefixdeletemessage:action.payload};

        case PREFIX_DELETE_RECEIVED:
        return Object.assign({}, state, action.payload);

        case PREFIX_DELETE_ERROR:
        return {...state, prefixdeletemessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default prefixdeletereducer;

