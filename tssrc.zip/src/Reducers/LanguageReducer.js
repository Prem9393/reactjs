import {LANGUAGE_REQUESTED, LANGUAGE_RECEIVED, LANGUAGE_ERROR, BASE_Language, BASE_LANGUAGE_ERROR} from '../Actions/Actions';
const initailstate = {
    languagelisting:[],
    pagenumber:1,
    recordlimit:12,
    totalusers:0,
    languagemessage:'',
    baseLanguage:"EN", 
    baseLanguageError:""
}

const languagereducer = (state = initailstate, action) =>{
    switch(action.type){

        case BASE_Language:
        return {...state, baseLanguage: action.payload};

        case LANGUAGE_RECEIVED:
        return Object.assign({}, state, action.payload);

        case LANGUAGE_ERROR:
        return {...state, languagelisting:action.payload};

        case BASE_LANGUAGE_ERROR:
         return  {...state, baseLanguageError: action.payload }  

        default :
        return Object.assign({}, state)
    }
}


export default languagereducer;