import {DASHBOARD_REQUEST, DASHBOARD_RECEIVED, DASHBOARD_ERROR, SELECTED_LANGUAGE, USER_LANGUAGE_ERROR } 
from '../Actions/Actions';
const initailstate = {
    dashboardlisting:[],
    dahsboardmessage:'',
    selectedLanguage:"EN",
    userbaseLanguageError:""
}

// localStorage.getItem('baseLanguage');

const DashboardReducer = (state = initailstate, action) =>{
    switch(action.type){

        case DASHBOARD_REQUEST:
        return {...state, dahsboardmessage:action.payload};

        case DASHBOARD_RECEIVED:
        return Object.assign({}, state, action.payload);

        case DASHBOARD_ERROR:
        return {...state, dahsboardmessage:action.payload};

         case SELECTED_LANGUAGE:
         return {...state, selectedLanguage:action.payload.selectedLanguage};

         case USER_LANGUAGE_ERROR:
         return {...state, userLanguageError: action.payload.userLanguageError};

        default :
        return Object.assign({}, state)

    }
}


export default DashboardReducer;

