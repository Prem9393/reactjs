import {PRODUCT_TOTAL_TO_REQUESTED, PRODUCT_TOTAL_TO_RECEIVED, PRODUCT_TOTAL_TO_ERROR} from '../Actions/Actions';

const initailstate = {
    message:'',
    hierarchy:'',
}

const ProductTotal = (state = initailstate, action) =>{
    switch(action.type){

        case PRODUCT_TOTAL_TO_REQUESTED:
        return {...state, message:action.payload};

        case PRODUCT_TOTAL_TO_RECEIVED:
        return Object.assign({}, state, action.payload);

        case PRODUCT_TOTAL_TO_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default ProductTotal;

