import {INSERT_USER_REQUESTED, INSERT_USER_RECEIVED, INSERT_USER_ERROR,INSERT_USER_ERROR_DISPLAY_STATUS } from '../Actions/Actions';
const initailstate = {
    insertuser:[],
    pagenumber:1,
    recordlimit:12,
    totalusers:0,
    insertusermessage:{ email:[]},
    insertdisplaystatus:{message:""}
}

const insertuserreducer = (state = initailstate, action) =>{
    switch(action.type){

        case INSERT_USER_REQUESTED:
        return {...state, insertusermessage:action.payload};

        case INSERT_USER_RECEIVED:
        return Object.assign({}, state, action.payload);

        case INSERT_USER_ERROR:
        return {...state, insertusermessage:action.payload};

        case INSERT_USER_ERROR_DISPLAY_STATUS:
            {console.log("*********", state, action.payload)}   
        return {...state, insertdisplaystatus:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default insertuserreducer;