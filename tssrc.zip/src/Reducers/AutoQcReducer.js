import {AUTOQC_LISTING_REQUESTED, AUTOQC_LISTING_RECEIVED, AUTOQC_LISTING_ERROR} from '../Actions/Actions';
const initailstate = {
    autoqclist:[],
    pagenumber:1,
    qcproductsupplier:[],
    recordlimit:10,
    totalqcproducts:0,
    autoqclistingmessage:''
}

const autoqclistingreducer = (state = initailstate, action) =>{
    switch(action.type){

        case AUTOQC_LISTING_REQUESTED:
        return {...state, autoqclistingmessage:action.payload};

        case AUTOQC_LISTING_RECEIVED:
        return Object.assign({}, state, action.payload);

        case AUTOQC_LISTING_ERROR:
        return {...state, autoqclistingmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default autoqclistingreducer;