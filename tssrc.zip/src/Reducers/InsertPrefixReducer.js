import {INSERT_PREFIX_REQUESTED, INSERT_PREFIX_RECEIVED, INSERT_PREFIX_ERROR, ADD_INSERT_PREFIX_DATA} from '../Actions/Actions';
const initailstate = {
    insertprefix:[],
    prefixlisting:[],
    pagenumber:1,
    recordlimit:12,
    totalprefix:0,
    insertprefixmessage:'',
    insertprefixdata:{}
}

const insertprefixreducer = (state = initailstate, action) =>{
    switch(action.type){

        case INSERT_PREFIX_REQUESTED:
        return {...state, insertprefixmessage:action.payload};

       case ADD_INSERT_PREFIX_DATA:
        return { 
            ...state,
            prefixlisting: [...state.prefixlisting, action.payload.insertprefixdata]
        }

        case INSERT_PREFIX_RECEIVED:
        
        return Object.assign({}, state, action.payload);

        case INSERT_PREFIX_ERROR:
        return {...state,insertprefixmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default insertprefixreducer;