import {FORGET_PASSWORD_REQUEST, FORGET_PASSWORD_RECEIVED, FORGET_PASSWORD_ERROR} from '../Actions/Actions';

const initailstate = {
    requestmessage:'',
}

const forgotpassword = (state = initailstate, action) =>{
    switch(action.type){

       

        default :
        return Object.assign({}, state)

    }
}


export default forgotpassword;

