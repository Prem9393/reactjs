import {INSERT_COMPANY_REQUESTED, INSERT_COMPANY_RECEIVED, INSERT_COMPANY_ERROR} from '../Actions/Actions';
const initailstate = {
    insertcompany:[],
    pagenumber:1,
    recordlimit:12,
    totalcompany:0,
    insertcompanymessage:''
}

const insertcompanyreducer = (state = initailstate, action) =>{
    switch(action.type){

        case INSERT_COMPANY_REQUESTED:
        return {...state, insertcompanymessage:action.payload};

        case INSERT_COMPANY_RECEIVED:
        return Object.assign({}, state, action.payload);

        case INSERT_COMPANY_ERROR:
        return {...state,insertcompanymessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default insertcompanyreducer;