import {MQC_FILTER_DATA_REQUESTED,MQC_FILTER_DATA_RECEIVED,MQC_FILTER_DATA_ERROR} from '../Actions/Actions';
const initailstate = {
    filterlist:[],
    filterdatamessage : ''
}

const manualqcfilter = (state = initailstate, action) =>{
    switch(action.type){

        case MQC_FILTER_DATA_REQUESTED:
        return {...state, filterdatamessage:action.payload};

        case MQC_FILTER_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case MQC_FILTER_DATA_ERROR:
        return {...state, filterdatamessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default manualqcfilter;

