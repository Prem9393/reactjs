import {PREFIX_LISTING_REQUESTED, PREFIX_LISTING_RECIEVED, PREFIX_LISTING_ERROR, ADD_BTN_ACTIVE, PREFIX_CURRENT_PAGE_DATA, PREFIX_DISPLAY_STATUS, ADD_INSERT_PREFIX_DATA} from '../Actions/Actions';
const initailstate = {
    prefixlisting:[],
    pagenumber:1,
    recordlimit:12,
    totalprefix:0,
    prefixlistingmessage:'',
    addBtnActive: true,
    prefixCurrentPageData:[],
    prefixDisplayMessage:""
}

const prefixlistingreducer = (state = initailstate, action) =>{
    switch(action.type){

      
        case PREFIX_LISTING_REQUESTED:
        return {...state, prefixlistingmessage:action.payload};

        case PREFIX_LISTING_RECIEVED:
        return Object.assign({}, state, action.payload);

        case PREFIX_LISTING_ERROR:
        return {...state, prefixlistingmessage:action.payload};

        case ADD_BTN_ACTIVE:
        return {...state, addBtnActive:action.payload.addBtnActive};

        case PREFIX_CURRENT_PAGE_DATA:
        return {...state, prefixCurrentPageData: action.payload};

        case PREFIX_DISPLAY_STATUS:
            console.log("prefixDisplayMessage", action.payload)
        return {...state, prefixDisplayMessage: action.payload.message};    
        
        // case ADD_INSERT_PREFIX_DATA:
        // console.log("check iiiii", { 
        //     ...state,
        //     prefixlisting: [...state.prefixlisting, action.payload.insertprefixdata]
        // })
        // return { 
        //     ...state,
        //     prefixlisting: [...state.prefixlisting, action.payload.insertprefixdata]
        // }
        

        default :
        return Object.assign({}, state)

    }
}


export default prefixlistingreducer;