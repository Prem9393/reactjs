import {AUTOQC_REVISION_DATA_REQUESTED,AUTOQC_REVISION_DATA_RECEIVED,AUTOQC_REVISION_DATA_ERROR} from '../Actions/Actions';
const initailstate = {
    form_data:[],
    autoqcrevisiondata:[],
    autoqc_revisiondetails:[],
    message : '',
	code : 0
}

const autoqcrevisiondatareducer = (state = initailstate, action) =>{
    switch(action.type){

        case AUTOQC_REVISION_DATA_REQUESTED:
        return {...state, message:action.payload};

        case AUTOQC_REVISION_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case AUTOQC_REVISION_DATA_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default autoqcrevisiondatareducer;

