import {USER_FORM_DATA_REQUESTED,USER_FORM_DATA_RECEIVED,USER_FORM_DATA_ERROR} from '../Actions/Actions';
const initailstate = {
    form_data:[],
    user_details:[],
    message : '',
	code : 0
}

const loaduserformreducer = (state = initailstate, action) =>{
    switch(action.type){

        case USER_FORM_DATA_REQUESTED:
        return {...state, message:action.payload};

        case USER_FORM_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case USER_FORM_DATA_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default loaduserformreducer;