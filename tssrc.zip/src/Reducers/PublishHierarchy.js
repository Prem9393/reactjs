import {PUBLISH_TO_REQUESTED, PUBLISH_TO_RECEIVED, PUBLISH_TO_ERROR} from '../Actions/Actions';

const initailstate = {
    message:'',
    publishto:'',
    hierarchy:'',
}

const PublishHierarchy = (state = initailstate, action) =>{
    switch(action.type){

        case PUBLISH_TO_REQUESTED:
        return {...state, message:action.payload};

        case PUBLISH_TO_RECEIVED:
        return Object.assign({}, state, action.payload);

        case PUBLISH_TO_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default PublishHierarchy;

