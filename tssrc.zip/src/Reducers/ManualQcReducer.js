import {MANUALQC_LISTTING_REQUESTED, MANUALQC_LISTTING_RECIEVED, MANUALQC_LISTING_ERROR} from '../Actions/Actions';
const initailstate = {
    manualqclisting:[],
    pagenumber:1,
    recordlimit:10,
    totalproducts:0,
    manualqclistingmessage:''
}

const manualqclistingreducer = (state = initailstate, action) =>{
    switch(action.type){

        case MANUALQC_LISTTING_REQUESTED:
        return {...state, manualqclistingmessage:action.payload};

        case MANUALQC_LISTTING_RECIEVED:
        return Object.assign({}, state, action.payload);

        case MANUALQC_LISTING_ERROR:
        return {...state, manualqclistingmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default manualqclistingreducer;