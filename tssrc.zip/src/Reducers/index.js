import { combineReducers } from 'redux';
import {reducer as reduxFormReducer } from 'redux-form'
import AuthReducer from './AuthReducer';
import CompanyNameReducer from './CompanyNameReducer';
import productListing from './ProductListingReducer';
import uploadexcelreducer from './UploadExcelReducer';
import productFilter from './ProductFilterReducer';
import uploadxmlreducer from './UploadXMLReducer';
import uploadassetsreducer from './UploadAssetsReducer';
import dashboardreducer from './DashboardReducer';
import basketreducer from './BasketReducer';
import productreducer from './ProductReducer';
import productoptionsreducer from './ProductOptionsReducer';
import subcategorylistingreducer from './SubCategoryListReducer';
import marketlistingreducer from './MarketListReducer';
import exportexcelreducer from './ExportExcelReducer';
import exportpdfreducer from './ExportPdfReducer';
import loadformdatareducer from './LoadFormDataReducer';
import loadcompanydatareducer from './LoadCompanyDataReducer';
import nutritionreducer from './NutritionReducer';
import Producttotal from './ProductTotal';
import PublishHierarchy from './PublishHierarchy';
import companylist from './CompanyListingReducer';
import userlist from './UserListingReducer';
import loaduserformdatareducer from './LoadUserFormDataReducer';
import modifyprefixreducer from './ModifyPrefixReducer';
import searchprefixreducer from './SearchPrefixReducer';
import prefixlistreducer from './PrefixListingReducer';
import insertuserreducer from './InsertUserReducer';
import updateuserreducer from './UpdateUserReducer';
import insertprefixreducer from './InsertPrefixReducer';
import updateprefixreducer from './UpdatePrefixReducer';
import insertcompanyreducer from './InsertCompanyReducer';
import updatecompanyreducer from './UpdateCompanyReducer';
import languagelistingreducer from './LanguageReducer';
import companydeletereducer from './CompanyDeleteReducer';
import autoqcreducer from './AutoQcReducer';
import autoqcdatareducer from './AutoQcDataReducer';
import autoqcrevisiondatareducer from './AutoQcRevisionDataReducer';
import manualqcreducer from './ManualQcReducer';
import manualqcfilterlist from './ManualQcFilterReducer';
import { reducer as forms } from 'redux-form';
import manualqcdatareducer from './ManualQcDataReducer';
import manualqcrevisiondatareducer from './ManualQcRevisionDataReducer';
//import forgotpasswordreducer from './ForgotpasswordReducer';

const RootReducer = combineReducers({
	auth:AuthReducer,
	companyname:CompanyNameReducer,
	productlisting : productListing,
	form: reduxFormReducer,
	uploadexcel : uploadexcelreducer,
	uploadxml : uploadxmlreducer,
	uploadassets : uploadassetsreducer,
	productfilter : productFilter,
	dashboard:dashboardreducer,
	basket:basketreducer,
	product:productreducer,
	productoptions:productoptionsreducer,
	subcategorylist:subcategorylistingreducer,
	marketlist:marketlistingreducer,
	exportexcel:exportexcelreducer,
	exportpdf:exportpdfreducer,
	loadformdata:loadformdatareducer,
	loadcompanydata:loadcompanydatareducer,
	nutritionreducer:nutritionreducer,
	publishhierarchy:PublishHierarchy,
	producttotal:Producttotal,
	companylist: companylist,
	userlist: userlist,
	loaduserformdata: loaduserformdatareducer,
	modifyprefix: modifyprefixreducer,
	searchprefix: searchprefixreducer,
	form: forms,
	prefixlist: prefixlistreducer,
	insertuser:insertuserreducer,
	updateuser:updateuserreducer,
	insertcompany:insertcompanyreducer,
	updatecompany:updatecompanyreducer,
	insertprefix:insertprefixreducer,
	updateprefix:updateprefixreducer,
	languagelisting: languagelistingreducer,
	companydelete: companydeletereducer,
	autoqclist:autoqcreducer,
	autoqcdata:autoqcdatareducer,
	manualqclist:manualqcreducer,
	manualqcfilterlist:manualqcfilterlist,
	autoqcrevisiondata:autoqcrevisiondatareducer,
	manualqcrevisiondata:manualqcrevisiondatareducer,
	manualqcdata:manualqcdatareducer,
	//forgotpassword:forgotpasswordreducer,
});

export default RootReducer;