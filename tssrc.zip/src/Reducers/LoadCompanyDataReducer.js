import {COMPANY_FORM_DATA_ERROR,COMPANY_FORM_DATA_RECEIVED,COMPANY_FORM_DATA_REQUESTED} from '../Actions/Actions';
const initailstate = {
    company_details:[],
    product_details:[],
    message : '',
	code : 0
}

const loadcompanydatareducer = (state = initailstate, action) =>{
    switch(action.type){

        case COMPANY_FORM_DATA_REQUESTED:
        return {...state, message:action.payload};

        case COMPANY_FORM_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case COMPANY_FORM_DATA_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default loadcompanydatareducer;

