import {MANUALQC_DATA_REQUESTED,MANUALQC_DATA_RECEIVED,MANUALQC_DATA_ERROR} from '../Actions/Actions';
const initailstate = {
    form_data:[],
    manualqcdata:[],
    manualqc_details:[],
    message : '',
	code : 0
}

const manualqcdatareducer = (state = initailstate, action) =>{
    switch(action.type){

        case MANUALQC_DATA_REQUESTED:
        return {...state, message:action.payload};

        case MANUALQC_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case MANUALQC_DATA_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default manualqcdatareducer;

