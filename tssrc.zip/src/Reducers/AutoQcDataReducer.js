import {AUTOQC_DATA_REQUESTED,AUTOQC_DATA_RECEIVED,AUTOQC_DATA_ERROR} from '../Actions/Actions';
const initailstate = {
    form_data:[],
    autoqcdata:[],
    autoqc_details:[],
    message : '',
	code : 0
}

const autoqcdatareducer = (state = initailstate, action) =>{
    switch(action.type){

        case AUTOQC_DATA_REQUESTED:
        return {...state, message:action.payload};

        case AUTOQC_DATA_RECEIVED:
        return Object.assign({}, state, action.payload);

        case AUTOQC_DATA_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default autoqcdatareducer;

