import {COMPANY_LISTTING_REQUESTED, COMPANY_LISTTING_RECIEVED, COMPANY_LISTTING_ERROR} from '../Actions/Actions';
const initailstate = {
    companylisting:[],
    pagenumber:1,
    recordlimit:12,
    totalcompany:23,
    companylistingmessage:''
}

const companylistingreducer = (state = initailstate, action) =>{
    switch(action.type){

        case COMPANY_LISTTING_REQUESTED:
        return {...state, companylistingmessage:action.payload};

        case COMPANY_LISTTING_RECIEVED:
        return Object.assign({}, state, action.payload);

        case COMPANY_LISTTING_ERROR:
        return {...state, companylistingmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default companylistingreducer;

