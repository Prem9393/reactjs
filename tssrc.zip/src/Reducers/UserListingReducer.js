import {USER_LISTING_REQUESTED, USER_LISTING_RECIEVED, USER_LISTING_ERROR} from '../Actions/Actions';
const initailstate = {
    userlisting:[],
    pagenumber:1,
    recordlimit:12,
    totalusers:0,
    userlistingmessage:''
}

const userlistingreducer = (state = initailstate, action) =>{
    switch(action.type){

        case USER_LISTING_REQUESTED:
        return {...state, userlistingmessage:action.payload};

        case USER_LISTING_RECIEVED:
        return Object.assign({}, state, action.payload);

        case USER_LISTING_ERROR:
        return {...state, userlistingmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default userlistingreducer;