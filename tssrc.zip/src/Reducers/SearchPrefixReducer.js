import {SEARCH_PREFIX_REQUESTED,SEARCH_PREFIX_RECEIVED,SEARCH_PREFIX_ERROR} from '../Actions/Actions';
const initailstate = {
    prefixlist:[],
    message:''
}

const searchprefixreducer = (state = initailstate, action) =>{
    switch(action.type){

        case SEARCH_PREFIX_REQUESTED:
        return {...state, message:action.payload};

        case SEARCH_PREFIX_RECEIVED:
        return Object.assign({}, state, action.payload);

        case SEARCH_PREFIX_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default searchprefixreducer;

