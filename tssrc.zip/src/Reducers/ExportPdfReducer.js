import {EXPORT_PDF_REQUESTED,EXPORT_PDF_RECEIVED,EXPORT_PDF_ERROR} from '../Actions/Actions';

const initailstate = {
    pdfexportmessage:'',
}

const ExcelPdfReducer = (state = initailstate, action) =>{
    switch(action.type){

        case EXPORT_PDF_REQUESTED:
        return {...state, pdfexportmessage:action.payload};

        case EXPORT_PDF_RECEIVED:
        return Object.assign({}, state, action.payload);

        case EXPORT_PDF_ERROR:
        return {...state, pdfexportmessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default ExcelPdfReducer;

