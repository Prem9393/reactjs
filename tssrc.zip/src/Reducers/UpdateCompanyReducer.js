import {UPDATE_COMPANY_REQUESTED, UPDATE_COMPANY_RECEIVED, UPDATE_COMPANY_ERROR, UPDATE_CODE_OFF} from '../Actions/Actions';
const initailstate = {
    updatecompany:[],
    pagenumber:1,
    recordlimit:12,
    totalcompany:0,
    updatecompanymessage:'',
    updatecode:0
}

const updatecompanyreducer = (state = initailstate, action) =>{

    
    switch(action.type){

        case UPDATE_COMPANY_REQUESTED:
        return {...state, updatecompanymessage:action.payload};

        case UPDATE_COMPANY_RECEIVED:
        return Object.assign({}, state, action.payload);

        case UPDATE_CODE_OFF:
        return {...state, updatecode: 0};

        case UPDATE_COMPANY_ERROR:
        return {...state, updatecompanymessage:action.payload };

        default :
        return Object.assign({}, state)

    }
}


export default updatecompanyreducer;