import {MODIFY_PREFIX_REQUESTED,MODIFY_PREFIX_RECEIVED,MODIFY_PREFIX_ERROR} from '../Actions/Actions';
const initailstate = {
    insertmessage:"",
    insertcode:'',
    message : '',
	code : 0
}

const modifyprefixreducer = (state = initailstate, action) =>{


    switch(action.type){

        case MODIFY_PREFIX_REQUESTED:
        return {...state, message:action.payload};

        case MODIFY_PREFIX_RECEIVED:
        return Object.assign({}, state, action.payload);
       //return Object.assign({}, state, action.payload);

        case MODIFY_PREFIX_ERROR:
        return {...state, message:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default modifyprefixreducer;

