import {TABLE_RECORDS_DELETE_REQUESTED, TABLE_RECORDS_DELETE_RECEIVED, TABLE_RECORDS_DELETE_ERROR} from '../Actions/Actions';
const initailstate = {
    tabledeleteformation:[],
    tabledeletemessage : ''
}

const tabledeletereducer = (state = initailstate, action) =>{
    switch(action.type){

        case TABLE_RECORDS_DELETE_REQUESTED:
        return {...state, tabledeletemessage:action.payload};

        case TABLE_RECORDS_DELETE_RECEIVED:
        return Object.assign({}, state, action.payload);

        case TABLE_RECORDS_DELETE_ERROR:
        return {...state, tabledeletemessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default tabledeletereducer;

