import React, { Component } from 'react';
import {Provider, connect} from 'react-redux';
import WebRouter from './Container/WebRouter'
import AppStore from './Store/AppStore'
import ActionCreators from './Actions/ActionCreators'
import './App.css';

const mapStateToProps = (state) => ({
  auth:state.auth.auth,
  name:state.auth.name,
  user_type:state.auth.user_type,
  user_id:state.auth.user_id,
  user_company_id:state.auth.user_company_id,
  userLanguage:state.auth.userLanguage != '' ? state.auth.userLanguage : 'EN',
  information_provider_gln:state.auth.information_provider_gln,
  is_view:state.auth.is_view,
  is_modify:state.auth.is_modify,
  is_user_view:state.auth.is_user_view,
  is_user_modify:state.auth.is_user_modify,
  is_product_view:state.auth.is_product_view,
  is_product_edit:state.auth.is_product_edit,
  is_product_upload:state.auth.is_product_upload,
  image:state.auth.image,
  token:state.auth.token,
  forgotpassword:state.auth.requestmessage,
  loginmessage:state.auth.loginmessage,
  registermessage:state.auth.registermessage,
  resetmessage:state.auth.resetmessage,
  forgetmessage:state.auth.forgetmessage,
  companyname : state.companyname.companyname,

  logincode:state.auth.logincode,
  registercode:state.auth.registercode,
  forgetcode:state.auth.forgetcode,
  resetcode : state.auth.resetcode,
  status : state.auth.readonly_status
 
})


const mapDispatchToProps = (dispatch) => ({
  ResetStateMessage: (values) => dispatch(ActionCreators.ResetStateMessage(values)),
  UserLogin: (values) => dispatch(ActionCreators.userLogin(values)),
  userRegister: (values) => dispatch(ActionCreators.userRegister(values)) ,
  GetCompanyName: () => dispatch(ActionCreators.CompanyName()),
  UserLogout: (values) => dispatch(ActionCreators.userLogout(values)),
  ForgotPassword: (values) => dispatch(ActionCreators.ForgotPassword(values)),
  ResetPassword: (values) => dispatch(ActionCreators.ResetPassword(values)),
})

const MainComponent  = connect(mapStateToProps, mapDispatchToProps)(WebRouter);

class App extends Component {
  render() {
    return <Provider store={AppStore}><MainComponent/></Provider>
  }
}

export default App;
