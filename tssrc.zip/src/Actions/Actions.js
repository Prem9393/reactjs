export const AUTH_SUCCESS = "Authentication Successfull";
export const AUTH_FAILED = "Authentication Failed";
export const AUTH_ERROR = "Authentication has some error try after some time";
export const AUTH_REQUESTED = "Authentication Requested";
export const SELECTED_LANGUAGE= "selected language";
export const BASE_Language = "base language";

export const COMPANY_NAME_REQUESTED = "Compnay Name requested";
export const COMPANY_NAME_RECIEVED ="Compnay Name received";
export const COMPANY_NAME_ERROR = "Compnay Name Error";

export const REGISTER_REQUEST = "Register Requested";
export const REGISTER_RECEIVED = "Register Received";
export const REGISTER_ERROR = "Register Error";

export const FORGET_PASSWORD_REQUEST = "Forget Password Requested";
export const FORGET_PASSWORD_RECEIVED = "Forget Password received";
export const FORGET_PASSWORD_ERROR = "Forget Password Error";



export const RESET_PASSWORD_REQUEST = "Reset Password Requested";
export const RESET_PASSWORD_RECEIVED = "Reset Password received";
export const RESET_PASSWORD_ERROR = "Reset Password Error";


export const EXCEL_FILE_UPLOAD_REQUEST = "Excel File Upload Request";
export const EXCEL_FILE_UPLOADED ="Excel File Uploaded Successfully";
export const EXCEL_FILE_UPLOAD_ERROR = "Excel File Upload Error";

export const XML_FILE_UPLOAD_REQUEST = "XML File Upload Request";
export const XML_FILE_UPLOADED ="XML File Uploaded Successfully";
export const XML_FILE_UPLOAD_ERROR = "XML File Upload Error";

export const ASSETS_UPLOAD_REQUEST = "Assets Upload Request";
export const ASSETS_UPLOADED ="Assets Uploaded Successfully";
export const ASSETS_UPLOAD_ERROR = "Assets Upload Error";

export const PRODUCT_LISTTING_REQUESTED = "Product List Requested";
export const PRODUCT_LISTTING_RECIEVED = "Product List Received";
export const PRODUCT_LISTTING_ERROR =  "Product List Error";

export const FILTER_DATA_REQUESTED = "Filter Data Requested";
export const FILTER_DATA_RECEIVED = "Filter Data Received";
export const FILTER_DATA_ERROR =  "Filter Data Error";

export const ADD_OR_EDIT_BASKET_REQUESTED = "Add/Edit Basket Products Requested";
export const ADD_OR_EDIT_BASKET_RECEIVED = "Add/Edit Basket Products Success";
export const ADD_OR_EDIT_BASKET_ERROR = "Add/Edit Basket Products Error";

export const REQUEST_LOGOUT = "Request Logout";
export const LOGGED_OUT ="Logged Out";
export const LOGOUTERROR = "Logout Error";

export const API_FAILED = "Api cannot be reached";
export const API_REQUESTED = "Api Request Placed";
export const API_SUCCESS = "Datas fetched successfully";

export const DASHBOARD_REQUEST = "Dashbaord cannot be reached";
export const DASHBOARD_RECEIVED = "Dashbaord Request Placed";
export const DASHBOARD_ERROR = "Dashbaord fetched successfully";

export const INSERT_PRODUCT_REQUESTED = "Insert Product Requested";
export const INSERT_PRODUCT_RECEIVED = "Product Inserted";
export const INSERT_PRODUCT_ERROR = "Insert Product Error";

export const UPDATE_PRODUCT_REQUESTED = "Insert Product Requested";
export const UPDATE_PRODUCT_RECEIVED = "Product Inserted";
export const UPDATE_PRODUCT_ERROR = "Insert Product Error";

export const SUB_CATEGORY_REQUESTED = "SubCategory Requested";
export const SUB_CATEGORY_RECEIVED = "SubCategory Received";
export const SUB_CATEGORY_ERROR = "SubCategory Error";

export const MARKET_REQUESTED = "Market Requested";
export const MARKET_RECEIVED = "Market Received";
export const MARKET_ERROR = "Market Error";

export const PRODUCT_OPTIONS_REQUESTED = "Product Options Requested";
export const PRODUCT_OPTIONS_RECEIVED = "Product Options Received";
export const PRODUCT_OPTIONS_ERROR =  "Product Options Error";

export const EXPORT_EXCEL_REQUESTED = "Export Excel Requested";
export const EXPORT_EXCEL_RECEIVED = "Export Excel received";
export const EXPORT_EXCEL_ERROR = "Export Excel Error";

export const PRODUCT_FORM_DATA_REQUESTED = "Product Form Data Requested";
export const PRODUCT_FORM_DATA_RECEIVED = "Product Form Data Received";
export const PRODUCT_FORM_DATA_ERROR = "Product Form Data Error";


export const NUTRITION_REQUESTED = "Nutrition  Requested";
export const NUTRITION_RECEIVED = "Nutrition Received";
export const NUTRITION_ERROR = "Nutrition Error";

export const TABLE_RECORDS_DELETE_REQUESTED = "Delete record  Requested";
export const TABLE_RECORDS_DELETE_RECEIVED = "Delete record Received";
export const TABLE_RECORDS_DELETE_ERROR = "Delete record Error";

export const EXPORT_PDF_REQUESTED = "Export PDF Requested";
export const EXPORT_PDF_RECEIVED = "Export PDF received";
export const EXPORT_PDF_ERROR = "Export PDF Error";

export const PUBLISH_TO_REQUESTED = "Publish to requested";
export const PUBLISH_TO_RECEIVED = "Publish to received";
export const PUBLISH_TO_ERROR = "Publish to Error";

export const PRODUCT_TOTAL_TO_REQUESTED = "Publish to requested";
export const PRODUCT_TOTAL_TO_RECEIVED = "Publish to received";
export const PRODUCT_TOTAL_TO_ERROR = "Publish to Error";

export const COMPANY_LISTTING_REQUESTED = "Publish to requested";
export const COMPANY_LISTTING_RECIEVED = "Publish to received";
export const COMPANY_LISTTING_ERROR = "Publish to Error";

export const INSERT_COMPANY_REQUESTED = "Publish to requested";
export const INSERT_COMPANY_RECEIVED = "Publish to received";
export const INSERT_COMPANY_ERROR = "Publish to Error";


export const COMPANY_TYPE_REQUESTED = "Publish to requested";
export const COMPANY_TYPE_RECEIVED = "Publish to received";
export const COMPANY_TYPE_ERROR = "Publish to Error";

export const USER_LISTING_REQUESTED = "Publish to requested";
export const USER_LISTING_RECIEVED = "Publish to received";
export const USER_LISTING_ERROR = "Publish to Error";
export const INSERT_USER_ERROR_DISPLAY_STATUS ="insertUser Error display status";
export const UPDATE_USER_ERROR_DISPLAY_STATUS ="updateUser Error display status";

export const INSERT_USER_REQUESTED = "Publish to requested";
export const INSERT_USER_RECEIVED = "Publish to received";
export const INSERT_USER_ERROR = "Publish to Error";

export const COMPANY_FORM_DATA_REQUESTED = "Publish to requested";
export const COMPANY_FORM_DATA_RECEIVED = "Publish to received";
export const COMPANY_FORM_DATA_ERROR = "Publish to Error";

export const USER_FORM_DATA_REQUESTED = "Publish to requested";
export const USER_FORM_DATA_RECEIVED = "Publish to received";
export const USER_FORM_DATA_ERROR = "Publish to Error";

export const ADD_INSERT_PREFIX_DATA ="Add insert prefix data";
export const INSERT_PREFIX_REQUESTED = "Publish to requested";
export const INSERT_PREFIX_RECEIVED = "Publish to received";
export const INSERT_PREFIX_ERROR = "Publish to Error";

export const UPDATE_USER_REQUESTED = "Publish to requested";
export const UPDATE_USER_RECEIVED = "Publish to received";
export const UPDATE_USER_ERROR = "Publish to Error";

export const MODIFY_PREFIX_REQUESTED = "Publish to requested";
export const MODIFY_PREFIX_RECEIVED = "Publish to received";
export const MODIFY_PREFIX_ERROR = "Publish to Error";

export const SEARCH_PREFIX_REQUESTED = "Publish to requested";
export const SEARCH_PREFIX_RECEIVED = "Publish to received";
export const SEARCH_PREFIX_ERROR = "Publish to Error";


export const PREFIX_LISTING_REQUESTED = "Publish to requested";
export const PREFIX_LISTING_RECIEVED = "Publish to received";
export const PREFIX_LISTING_ERROR = "Publish to Error";
export const ADD_BTN_ACTIVE="add btn active";
export const PREFIX_CURRENT_PAGE_DATA="prefix current page data";


export const PREFIX_DELETE_REQUESTED = "Publish to requested";
export const PREFIX_DELETE_RECEIVED = "Publish to received";
export const PREFIX_DELETE_ERROR = "Publish to Error";

export const UPDATE_COMPANY_REQUESTED = "Publish to requested";
export const UPDATE_COMPANY_RECEIVED = "Publish to received";
export const UPDATE_COMPANY_ERROR = "Publish to Error";

export const TRANSFER_PREFIX_REQUESTED = "Publish to requested";
export const TRANSFER_PREFIX_RECEIVED = "Publish to received";
export const TRANSFER_PREFIX_ERROR = "Publish to Error";

export const SUSPEND_PREFIX_REQUESTED = "Publish to requested";
export const SUSPEND_PREFIX_RECEIVED = "Publish to received";
export const SUSPEND_PREFIX_ERROR = "Publish to Error";

export const UPDATE_CODE_OFF = "update code off";
export const PREFIX_DISPLAY_STATUS = "prefix display status";

export const LANGUAGE_REQUESTED = "Publish to requested";
export const LANGUAGE_RECEIVED = "Publish to received";
export const LANGUAGE_ERROR = "Publish to Error";

export const BASE_LANGUAGE = "user base language";
export const BASE_LANGUAGE_ERROR = "base language error";
export const USER_LANGUAGE_ERROR ='user language error';

export const COMPANY_DELETE_REQUESTED = "Publish to requested";
export const COMPANY_DELETE_RECEIVED = "Publish to received";
export const COMPANY_DELETE_ERROR = "Publish to Error";
export const COMPANY_DISPLAY_STATUS = "Company display status";

export const AUTOQC_LISTING_REQUESTED = "Publish to requested";
export const AUTOQC_LISTING_RECEIVED = "Publish to received";
export const AUTOQC_LISTING_ERROR = "Publish to Error";

export const MANUALQC_LISTTING_REQUESTED = "Publish to requested";
export const MANUALQC_LISTTING_RECIEVED = "Publish to received";
export const MANUALQC_LISTING_ERROR = "Publish to Error";

export const MQC_FILTER_DATA_REQUESTED = "Publish to requested";
export const MQC_FILTER_DATA_RECEIVED = "Publish to received";
export const MQC_FILTER_DATA_ERROR = "Publish to Error";

export const AUTOQC_DATA_REQUESTED = "Publish to requested";
export const AUTOQC_DATA_RECEIVED = "Publish to received";
export const AUTOQC_DATA_ERROR = "Publish to Error";

export const AUTOQC_REVISION_DATA_REQUESTED = "Publish to requested";
export const AUTOQC_REVISION_DATA_RECEIVED = "Publish to received";
export const AUTOQC_REVISION_DATA_ERROR = "Publish to Error";


export const MANUALQC_DATA_REQUESTED = "Publish to requested";
export const MANUALQC_DATA_RECEIVED = "Publish to received";
export const MANUALQC_DATA_ERROR = "Publish to Error";

export const MANUALQC_REVISION_DATA_REQUESTED = "Publish to requested";
export const MANUALQC_REVISION_DATA_RECEIVED = "Publish to received";
export const MANUALQC_REVISION_DATA_ERROR = "Publish to Error";