
const AppValidation = {

	ValidateLoginForm(values){

		const errors = {}
		if (!values.email) {
			errors.email = 'Email is Required';
		}
		else if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(values.email)))
		{
			errors.email = 'Enter valid Email Address';
		} 
		else if (values.email.length > 30) {
			errors.email = 'Must be 30 characters or less';
		}
		
		if (!values.password) {
			errors.password = 'Password is Required';
		} else if (values.password.length<6) {
			errors.password = 'Password must have atleat 6 characters';
		}

		return errors
		  
	},

	ValidateRegistationForm(values){
		const errors = {}
		if(!values.first_name){
			errors.first_name = 'First Name is required';
		}

		if (!values.last_name){
			errors.last_name = 'Last Name is required';
		}

		if (!values.email){
			errors.email = 'Email is Required';
		}

		if (!values.email){
			errors.email = 'Must be 20 characters or less';
		}
		else if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(values.email))){
			errors.email = 'Enter valid Email Address';
		}
		
		if (!values.password) {
			errors.password = 'Password is Required';
		} else if (values.password.length<6){
			errors.password = 'Password must have atleat 6 characters';
		}

		if (!values.confirmpassword) {
			errors.confirmpassword = 'Confirm Password is Required';
		} else if (values.confirmpassword.length<6){
			errors.confirmpassword = 'Confirm Password must have atleat 6 characters';
		}

		if(values.password!==values.confirmpassword){
			errors.password = 'Password must be same as confirm password';
			errors.confirmpassword = 'Confirm Password be same as password';
		}

		if (!values.companyname) {
			errors.companyname = 'Company Name is Required';
		}

		return errors;
	},
	
	ValidateProductForm(values){
		const errors = {}
		if(!values.cu_Category){
			errors.cu_Category = 'The category name field is required.';
		}
		
		if(!values.cu_SubCategory){ 
			errors.cu_SubCategory = 'The sub category name field is required.';
		}
		
		if(!values.cu_GTIN){
			errors.cu_GTIN = 'The gtin code field is required.';
		} else if(isNaN(Number(values.cu_GTIN))){
			errors.cu_GTIN = 'The gtin code must be numeric.';
		}

		
		if(values.shr_GTIN){
			if(isNaN(Number(values.shr_GTIN))){
				errors.shr_GTIN = 'The gtin code must be numeric.';
			}
		}
	
		if(values.case_GTIN){
			if(isNaN(Number(values.case_GTIN))){
				errors.case_GTIN = 'The gtin code must be numeric.';
			}
		}

	    if(values.pallet_GTIN){
			if(isNaN(Number(values.pallet_GTIN))){
				errors.pallet_GTIN = 'The gtin code must be numeric.';
			}
		}

		if(!values.cu_NetContentUoM){ 
			errors.cu_NetContentUoM = 'The UOM field is required.';
		}

		if(!values.cu_NetContent){ 
			errors.cu_NetContent = 'The NetContent field is required.';
		}

		if(!values.cu_alternateItemIdentification){ 
			errors.cu_alternateItemIdentification = 'The NetContent field is required.';
		}

		if(isNaN(Number(values.cu_vat_exemp_percentage))){ 
			errors.cu_vat_exemp_percentage = 'The Percentage field is required.';
		}

		if(isNaN(Number(values.cu_height))){ 

			errors.cu_height = 'The Height field is numeric.';
		}

		if(isNaN(Number(values.cu_width))){ 
			errors.cu_width = 'The Height field is numeric.';
		}


		if(isNaN(Number(values.cu_depth))){ 
			errors.cu_depth = 'The Depth field is numeric.';
		}

		if(isNaN(Number(values.cu_grossWeight))){ 
			errors.cu_grossWeight = 'The Gross Weight field is numeric.';
		}

		if(isNaN(Number(values.cu_packagingWeight))){ 
			errors.cu_packagingWeight = 'The Packaging Weight field is numeric.';
		}

		if(isNaN(Number(values.cu_netWeight))){ 
			errors.cu_netWeight = 'The Net Weight field is numeric.';
		}
	

		if(!values.cu_languageSpecificBrandName){ 
			errors.cu_languageSpecificBrandName = 'The Brand Name field is required.';
		}

		// if(!values.cu_brand_name){
		// 	errors.cu_brand_name = 'The brand name field is required.';
		// }
		// if(!values.cu_functional_name){
		// 	errors.cu_functional_name = 'The functional name field is required.';
		// }
		// if(!values.cu_variant_name){
		// 	errors.cu_variant_name = 'The variant name field is required.';
		// }
		// if(!values.cu_net_content){
		// 	errors.cu_net_content = 'The net content field is required.';
		// }
		// if(!values.cu_start_availability_date){
		// 	errors.cu_start_availability_date = 'The start availability date field is required.';
		// }
		return errors;
	},

	ValidateUserForm(values){
	
		const errors = {}
		
		if(!values.first_name){
			errors.first_name = 'The first name field is required.';
		}

		if(!values.last_name){
			errors.last_name = 'The Last name field is required.';
		}

		if(!values.email){
			errors.email = 'The Email field is required.';
		}
		
		if (!values.email){
			errors.email = 'Must be 20 characters or less';
		}
		else if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(values.email))){
			errors.email = 'Enter valid Email Address';
		}


		if(!values.password){
			errors.password = 'The Password field is required.';
		}

		if(!values.user_name){
			errors.user_name = 'The user name field is required.';
		}

		if(!values.user_company || values.user_company == undefined ){
			errors.user_company = 'The user company field is required';
		}

		// if(!values.InformationProviderGLN){
		// 	errors.InformationProviderGLN = 'The InformationProviderGLN field is required.';
		// }

		if(!values.user_telephone){
			errors.user_telephone = 'The Telephone field is required.';
		}
		
		if(!values.userLanguage ){
			errors.userLanguage  = 'The UserLanguage field is required.';
		}
		

		// if(!values.user_type){
		// 	errors.user_type = 'The user type is required.';
		// }

		return errors;
	},

	ValidateCompanyForm(values) {

		//console.log("incoming values", values)
		const errors = {}

		if(!values.CompanyName){
			errors.CompanyName = 'The CompanyName field is required.';
		}

		if(!values.ContactName){
			errors.ContactName = 'The ContactName field is required.';
		}

		if(!values.CompanyGLN){
			errors.CompanyGLN = 'The CompanyGLN field is required.';
		}		

		if(!values.ContactEmail){
			errors.ContactEmail = 'The ContactEmail field is required.';
		}

		if(!values.BatchUserId){
			errors.BatchUserId = 'The BatchUserId field is required.';
		}

		if(!values.ContactTel){
			errors.ContactTel = 'The ContactTel field is required.';
		}

		if(!values.ContactFax){
			errors.ContactFax = 'The ContactFax field is required.';
		}

		if(!values.WebServiceGLN){
			errors.WebServiceGLN = 'The WebServiceGLN field is required.';
		}

		if(!values.WebServiceKey){
			errors.WebServiceKey = 'The WebServiceKey field is required.';
		}

		if(!values.BuildingName){
			errors.BuildingName = 'The BuildingName field is required.';
		}

		if(!values.StreetNumberName){
			errors.StreetNumberName = 'The StreetNumberName field is required.';
		}

		if(!values.SubrubName){
			errors.SubrubName = 'The SubrubName field is required.';
		}

		if(!values.CityName){
			errors.CityName = 'The CityName field is required.';
		}

		if(!values.PostalCode){
			errors.PostalCode = 'The PostalCode field is required.';
		}

		if(!values.Province){
			errors.Province = 'The Province field is required.';
		}

		if(!values.PostalProvince){
			errors.PostalProvince = 'The PostalProvince field is required.';
		}
		if(!values.PostalPostalCode){
			errors.PostalPostalCode = 'The PostalPostalCode field is required.';
		}
		if(!values.PostalCityName){
			errors.PostalCityName = 'The PostalCityName field is required.';
		}

		if(!values.PostalSubrubName){
			errors.PostalSubrubName = 'The PostalSubrubName field is required.';
		}
		if(!values.IsCompliant){
			errors.IsCompliant = 'The IsCompliant field is required.';
		}
		if(!values.CompliantPercentage){
			errors.CompliantPercentage = 'The CompliantPercentage field is required.';
		}
		if(!values.AdditionalContactName){
			errors.AdditionalContactName = 'The AdditionalContactName field is required.';
		}
		if(!values.AdditionalContactEmail){
			errors.AdditionalContactEmail = 'The AdditionalContactEmail field is required.';
		}
		if(!values.AdditionalContactTel){
			errors.AdditionalContactTel = 'The AdditionalContactTel field is required.';
		}

		if(!values.first_name){
			errors.first_name = 'The first name field is required.';
		}

		if(!values.last_name){
			errors.last_name = 'The last name field is required.';
		}

		if(!values.email_id){
			errors.email_id = 'The email id field is required.';
		}

		if(!values.user_telephone){
			errors.user_telephone = 'The user telephone field is required.';
		}

		if(!values.user_name){
			errors.user_name = 'The user name field is required.';
		}

		if(!values.password){
			errors.password = 'The password field is required.';
		}	

		return errors;
	},

	ValidateEditCompanyForm(values){
		
		const errors = {}

		if(!values.CompanyName){
			errors.CompanyName = 'The CompanyName field is required.';
		}

		if(!values.ContactName){
			errors.ContactName = 'The ContactName field is required.';
		}

		if(!values.CompanyGLN){
			errors.CompanyGLN = 'The CompanyGLN field is required.';
		}		

		if(!values.ContactEmail){
			errors.ContactEmail = 'The ContactEmail field is required.';
		}

		if(!values.BatchUserId){
			errors.BatchUserId = 'The BatchUserId field is required.';
		}

		if(!values.ContactTel){
			errors.ContactTel = 'The ContactTel field is required.';
		}

		if(!values.ContactFax){
			errors.ContactFax = 'The ContactFax field is required.';
		}

		if(!values.WebServiceGLN){
			errors.WebServiceGLN = 'The WebServiceGLN field is required.';
		}

		if(!values.WebServiceKey){
			errors.WebServiceKey = 'The WebServiceKey field is required.';
		}

		if(!values.BuildingName){
			errors.BuildingName = 'The BuildingName field is required.';
		}

		if(!values.StreetNumberName){
			errors.StreetNumberName = 'The StreetNumberName field is required.';
		}

		if(!values.SubrubName){
			errors.SubrubName = 'The SubrubName field is required.';
		}

		if(!values.CityName){
			errors.CityName = 'The CityName field is required.';
		}

		if(!values.PostalCode){
			errors.PostalCode = 'The PostalCode field is required.';
		}

		if(!values.Province){
			errors.Province = 'The Province field is required.';
		}

		if(!values.PostalProvince){
			errors.PostalProvince = 'The PostalProvince field is required.';
		}

		// if(!values.PostalPoBox){
		// 	errors.PostalPoBox = 'The PostalPoBox field is required.';
		// }

		
		if(!values.PostalPostalCode){
			errors.PostalPostalCode = 'The PostalPostalCode field is required.';
		}
		if(!values.PostalCityName){
			errors.PostalCityName = 'The PostalCityName field is required.';
		}

		if(!values.PostalSubrubName){
			errors.PostalSubrubName = 'The PostalSubrubName field is required.';
		}
		if(!values.IsCompliant){
			errors.IsCompliant = 'The IsCompliant field is required.';
		}
		if(!values.CompliantPercentage){
			errors.CompliantPercentage = 'The CompliantPercentage field is required.';
		}
		if(!values.AdditionalContactName){
			errors.AdditionalContactName = 'The AdditionalContactName field is required.';
		}
		if(!values.AdditionalContactEmail){
			errors.AdditionalContactEmail = 'The AdditionalContactEmail field is required.';
		}
		if(!values.AdditionalContactTel){
			errors.AdditionalContactTel = 'The AdditionalContactTel field is required.';
		}

		// if(!values.first_name){
		// 	errors.first_name = 'The first name field is required.';
		// }

		// if(!values.last_name){
		// 	errors.last_name = 'The last name field is required.';
		// }

		// if(!values.email_id){
		// 	errors.email_id = 'The email id field is required.';
		// }

		// if(!values.user_telephone){
		// 	errors.user_telephone = 'The user telephone field is required.';
		// }

		// if(!values.user_name){
		// 	errors.user_name = 'The user name field is required.';
		// }

		// if(!values.password){
		// 	errors.password = 'The password field is required.';
		// }	

		return errors;

	},


	ValidatEditUserForm(values) {

		console.log("ii", values)
		const errors = {}
		if(!values.first_name){
			errors.first_name = 'The first name field is required.';
		}

		if(!values.last_name){
			errors.last_name = 'The Last name field is required.';
		}

		if(!values.email){
			errors.email = 'The Email field is required.';
		}

		if (!values.email){
			errors.email = 'Must be 20 characters or less';
		}
		else if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(values.email))){
			errors.email = 'Enter valid Email Address';
		}

		if(!values.password){
			errors.password = 'The Password field is required.';
		}

		if(!values.user_name){
			errors.user_name = 'The user name field is required.';
		}

		// if(!values.InformationProviderGLN){
		// 	errors.InformationProviderGLN = 'The InformationProviderGLN field is required.';
		// }

		if(!values.user_telephone){
			errors.user_telephone = 'The Telephone field is required.';
		}

		 if(!values.user_type){
		 	errors.user_type = 'The user type is required.';
		 }

		 if(!values.userLanguage){			
			errors.userLanguage = 'The user language is required.';
		}
		 
		return errors;
	},

	ValidatePrefixForm(values) {
		//console.log("123213",values);
		const errors = {}
		if(!values.company_id){
			errors.company_id = 'The Brand Owner Field is required.';
		}

		if(!values.prefix){
			errors.prefix = 'The prefix Field is required.';
		}

		if(!values.prefix_start){
			errors.prefix_start = 'The prefix start Field is required.';
		}

		if(!values.prefix_end){
			errors.prefix_end = 'The prefix end Field is required.';
		}

		if(!values.qty){
			errors.qty = 'The qty Field is required.';
		}

		if(!values.created_by){
			errors.created_by = 'The created by Field is required.';
		}

		if(!values.supplier){
			errors.supplier = 'The supplier Field is required.';
		}

		return errors;

	},


	ValidateEditProductForm(values){
		const errors = {}

		console.log("***", values)
	   
		
		if(!values.cu_category_name){
			errors.cu_category_name = 'The category name field is required.';
		}

		if(!values.cu_sub_category_name){ 
			errors.cu_sub_category_name = 'The sub category name field is required.';
		}

		// if(!values.cu_gtin_code){
		// 	errors.cu_gtin_code = 'The gtin code field is required.';
		// }else if(isNaN(Number(values.cu_gtin_code))){
		// 	errors.cu_gtin_code = 'The gtin code must be numeric.';
		// }
		
		if(!values.cu_brand_name){
			errors.cu_brand_name = 'The brand name field is required.';
		}
		if(!values.cu_functional_name){
			errors.cu_functional_name = 'The functional name field is required.';
		}
		//if(!values.cu_variant_name){
		//	errors.cu_variant_name = 'The variant name field is required.';
		//}
		if(!values.cu_net_content){
			errors.cu_net_content = 'The net content field is required.';
		}

		if(!values.cu_GTIN){
			errors.cu_GTIN = 'The gtin code field is required.';
		} else if(isNaN(Number(values.cu_GTIN))){
			errors.cu_GTIN = 'The gtin code must be numeric.';
		}

		
		if(values.shr_GTIN){
			if(isNaN(Number(values.shr_GTIN))){
				errors.shr_GTIN = 'The gtin code must be numeric.';
			}
		}
		
		if(values.case_GTIN){
			if(isNaN(Number(values.case_GTIN))){
				errors.case_GTIN = 'The gtin code must be numeric.';
			}
		}

	    if(values.pallet_GTIN){
			if(isNaN(Number(values.pallet_GTIN))){
				errors.pallet_GTIN = 'The gtin code must be numeric.';
			}
		}
		 


		return errors;
	},

	ForgetPassword(values){
		const errors = {}
		if(!values.email){
			errors.email = 'Email field is required.';
		}
		return errors;
	},


	ResetPassword(values){
		const errors = {}
		
		if (!values.confirmpassword) {
			errors.confirmpassword = 'Confirm Password is Required';
		} else if (values.confirmpassword.length<6){
			errors.confirmpassword = 'Confirm Password must have atleat 6 characters';
		}

		if(values.password!==values.confirmpassword){
			errors.password = 'Password must be same as confirm password';
			errors.confirmpassword = 'Confirm Password be same as password';
		}

		return errors
		  
	},



};

export default AppValidation;


export const normalizeMaxLength = max => value => {
    if(!value)
          return value;
     if (value.length <= max){
         return value;
       }
     }  
    
    
export const normalizeNumber = values => {
    const onlyNums =/^[0-9]\d*$/.test(values);

    if(!values)
      return values;

    if (onlyNums)
       return values;
}

export const validateEmail = value => { 
    
    return value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
    ? 'Invalid email address'
    : undefined
}


export const normalizeNumberAndSetLimit = max=> values => {
	const errors = {}

    const onlyNums =/^[0-9]\d*$/.test(values);
    if(!values)
	   return values;
	
    //  if(values){
	// 	if(isNaN(Number(values))){
	// 		AppValidation.ValidateEditProductForm( {shr_GTIN: values})
	// 	    } 
	//   }

    if (onlyNums)
        if (values.length <= max){
         return values;
       }  
}


export const requiredNumberAndSetLimit = max=> values =>{
	
	const onlyNums =/^[0-9]\d*$/.test(values);
    if(!values)
       return values;

    if (onlyNums)
        if (values.length <= max){
         return values;
       }  

	return 'GTIN field should be Numbers';
}

