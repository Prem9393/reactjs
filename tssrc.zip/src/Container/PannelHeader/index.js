import React, {Component, Fragment} from 'react';
import {Link} from 'react-router-dom';
import Config from '../../Config';
import { Dropdown,MenuItem  } from 'react-bootstrap'; 
import  ActionCreators from '../../Actions/ActionCreators';
import { connect } from 'react-redux';




class PannelHeader extends Component{
    constructor(props) {
        super(props);
    
        this.handleClick = this.handleClick.bind(this);
        this.handleOutsideClick = this.handleOutsideClick.bind(this);
        this.selectedLang = this.selectedLang.bind(this);
    
        this.state = {
          popupVisible: false, 
          dropdownOpen: false,
        //   selectedLang: "EN",
          languagelistingPannelheader: [],
          mainTitle: "",
          subTitle:"",
        };
    }

    componentWillMount(){

       this.props.dispatch(ActionCreators.getLanguageCode(this.props.userBaseLangugae));
    }

    handleClick() {
        if (!this.state.popupVisible) {
          document.addEventListener('click', this.handleOutsideClick, false);
        } else {
          document.removeEventListener('click', this.handleOutsideClick, false);
        }
    
        this.setState(prevState => ({
           popupVisible: !prevState.popupVisible,
        }));
    }


    handleOutsideClick(e) {
        if (this.node.contains(e.target)) {
          return;
        }
        this.handleClick();
    }

    selectedLang(value){
     }

    render(){

        console.log("panel header props",this.props);
        if(this.props.userdetails.userimage){
            let userImage = <img src={this.props.userdetails.userimage} alt=""  className="rounded-circle"/>;
        }else{
            let userImage = <img src="assets/images/header_profile.png" alt=""  className="rounded-circle"/>;
        }

        return <Fragment><div className="head_name">
                    <div className="mhamicon pull-left"  onClick={this.props.handlemanu}>
                        <Link to="#" className="mham"><i className="fa fa-bars fa-2x"></i>
                        </Link>
                    </div>

                    {/* <div className="company_name">

                        <div className="toggle_header" onClick={this.props.gettoggle}>
                            <i className="fa fa-bars fa-2x"></i>
                        </div>
                        <Link to={Config.userPath[this.props.user_type] + 'dashboard'}>
                            {Config.userTypesText[this.props.user_type]} Dashboard
                        </Link>                 
                    </div> */}

                    <div className="company_name">
                        <div className="toggle_header display-none">
                            <i className="fa fa-bars fa-2x"></i>
                        </div>
                        <a href="#"><span>work lists</span>{Config.userTypesText[this.props.user_type]}</a>
					</div>
                   
                </div>

                <div className="header_profile">

                    {/* <a class="nav-link dropdown-toggle waves-effect waves-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><img src="assets/images/header_profile.png" alt="user" class="rounded-circle" /></a> */}

                    <Dropdown id="dropdown-custom-1" className="nav-link dropdown-toggle waves-effect waves-dark">
                        {/* <Dropdown.Toggle>
                            <img src={this.props.userdetails.userimage} alt=""  className="rounded-circle"/>
                            {this.props.userdetails.username}
                        </Dropdown.Toggle> */}

                        <Dropdown.Toggle  id="dropdown-custom-components">
                            <a className="nav-link dropdown-toggle waves-effect waves-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                               
                                <img src="assets/images/header_profile.png" alt=""  className="rounded-circle"/>
                                {/* <img src={this.props.userdetails.userimage} alt=""  className="rounded-circle"/> */}
                            </a>
                        </Dropdown.Toggle>

                        <Dropdown.Menu className="super-colors user_profile_dropdown">
                            <MenuItem eventKey="3" className="user-header-profile">
                            <img src={this.props.userdetails.userimage} className="img-circle" alt="" />
                            <p>{this.props.userdetails.username}</p>
                            </MenuItem>
                            <MenuItem eventKey="4">
                                <div className="pull-left">
                                    <button className="btn btn-default btn-flat">Profile</button>
                                </div>
                                <div className="pull-right">
                                <button className="btn btn-default btn-flat" onClick={this.props.logout}>
                                    <i className="fa fa-sign-out"></i> 
                                    Logout
                                </button>
                                </div>
                            </MenuItem>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>

                
                 </Fragment>;
    }
}

const mapStateToProps = (state, ownProps) => {


    return {s: state};

 }

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch
    }
}


export default connect(null, mapDispatchToProps)(PannelHeader);




