import React, { Component } from 'react';
import { Field } from 'redux-form';
import ListView from './ListView';
import Pagination from '../../Components/Pagination';
import TablePagination from '../../Components/TablePagination';
import Basket from '../../Container/ProductBrowser/Basket';
import Config from '../../Config';
import Common from '../../Common';
import ActionCreators from '../../Actions/ActionCreators'
import Loader from '../../Components/Loader';

class UserList extends Component {
    constructor(props) {
        super(props)
        this.UserPagination = this.UserPagination.bind(this);
        this.state = {
                isLoading: true,
                pageOfItems: [],
                search:'',
                filteredUserList:[],
                pageSize:12,
                cardView : true
           }
        this.onChangePage = this.onChangePage.bind(this);
        this.handlechange = this.handlechange.bind(this);
        this.handleUserListView = this.handleUserListView.bind(this);
    }

    onChangePage(pageOfItems) {
        // update state with new page of items
        this.setState({ pageOfItems: pageOfItems});
    }

   

    componentDidMount() {

        var form_fields = {
            recordlimit: this.props.recordlimit,
            pagenumber: this.props.pagenumber,
            totalusers: this.props.totalusers,   
            current_user: this.props.id,   
            user_type: this.props.user_type,        
        }
        
        this.props.UserListing(form_fields);
        
    }

    UserPagination(pagenumber) {
        // var form_fields = {
        //     recordlimit: this.props.recordlimit,
        //     pagenumber: pagenumber,
        //     totalusers: this.props.totalusers,            
        // }
        // this.setState({ isLoading: true });
        // this.props.UserListing(form_fields);
    }

    handleUserListView(){
        this.setState(previousCardView => {
            return{
                cardView : !previousCardView.cardView
            }
        });
    }

    handlechange(e){
        let searchValue =e.target.value;

        this.setState({
            search: searchValue.toString().substr(0,20),
          })

        let filteredUserList = this.props.userlisting.filter((user) => { 
     return ( user.first_name.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1 || user.email.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1 )
        })
        this.setState({ filteredUserList})
    }

    componentWillReceiveProps(nextProps) {
        console.log('componentWillReceiveProps', nextProps);
        if(nextProps.userlistingmessage !==''){
             this.setState({isLoading:false});
        }
    }
  
    componentWillUnmount() {
        this.props.dispatch(ActionCreators.insertUserCodeOff(0));
        this.props.dispatch(ActionCreators.updateUserCodeOff(0));
    }

    render(){
        console.error(this.props);
        return (
            <div className="container-fluid">
                <Loader showloader={this.state.isLoading}/>
                <div className="row no-gutter">
                    <div className="col-sm-12 col-xs-12">
                        <div className="setp_2maintable custom"> 
                                <div className="top_search">
                                    <div className="row content-main-header">
                                        <div className="col-md-6">
                                            <div className="content-head-left-side">
                                                <div className="project-count-wrap">
                                                    <p>Users<span><strong>{this.props.totalusers}</strong></span></p>
                                                </div>
                                                <div className="filter-container">
                                                    <div className="form-group has-search">
                                                        <span className="fa fa-search form-control-feedback"></span>
                                                        <Field component={Common.renderInput}  type="text" id="search_name_email" className="form-control" name="search_name_email" name="search_GTIN" onChange={this.handlechange} placeholder="Filter by name, email or GLN"  />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="button-group">
                                                <div className="table-list-switcher pull-right">
                                                    <input id="toggle-on" className="toggle toggle-left" name="toggle" value="false" type="radio" defaultChecked="checked" onChange={this.handleUserListView} />
                                                    <label htmlFor="toggle-on" className="btn">Cards</label>
                                                    <input id="toggle-off" className="toggle toggle-right" name="toggle" value="true" type="radio" onChange={this.handleUserListView}/>
                                                    <label htmlFor="toggle-off" className="btn">List</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div className="table-responsive user_listing custom_table">
                                    {/* <input type="text" id="search_name_email" className="form-control" name="search_name_email" onChange={this.handlechange} placeholder="Search Name / Email" />
                                    <div className="button-group">
                                        <a className="btn btn-primary btn-flat" onClick={this.handleUserListView}>View type</a>
                                        <div className="table-list-switcher pull-right">
                                            <input id="toggle-on" className="toggle toggle-left" name="toggle" value="false" type="radio" defaultChecked="checked" onChange={this.handleUserListView} />
                                            <label htmlFor="toggle-on" className="btn">Cards</label>
                                            <input id="toggle-off" className="toggle toggle-right" name="toggle" value="true" type="radio" onChange={this.handleUserListView}/>
                                            <label htmlFor="toggle-off" className="btn">List</label>
                                        </div>
                                    </div>
                                    <Basket usertype={this.props.user_type} basketcount={this.props.basketcount} filterProducts={this.filterProducts} export={this.exportExcel} exportPdf={this.exportPDF} />  */}
                               

                                {/* <section class="content-header">
                                    <h1>
                                        User List
                                    </h1>    
                                    {this.props.user_type == 1 || this.props.user_type == 2 || this.props.user_type == 3 || this.props.user_type == 4 ?
                                <div className="button-group">
                                    <a className="btn btn-primary btn-flat" href={Config.baseUrl+Config.userPath[this.props.user_type]+'insertuser'} 
                                       onClick={ 
                                            this.props.dispatch(ActionCreators.updatedisplaystatusOff()),
                                            this.props.dispatch(ActionCreators.insertdisplaystatusOff())
                                          }>
                                              Add New
                                      </a>

                                   </div> :  ''}                                
                                </section> */}

                                 {
                                     this.props.insertcode ==1 ? 
                                   <div class="alert alert-success" role="alert">
                                      User inserted successfully...!
                                   </div>: ""
                                 }

                                   {
                                     this.props.updatecode ==1 ? 
                                  <div class="alert alert-success" role="alert">
                                     User updated successfully...!
                                  </div>: ""
                                 }

                                <ListView  {...this.state } {...this.props} />
                                <center>
                                    <TablePagination pageSize={ this.state.pageSize } items={this.state.search ==="" ?this.props.userlisting: this.state.filteredUserList } searchValue={this.state.search} onChangePage={this.onChangePage} />
                                </center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default UserList;

