import React, { Component } from 'react';
import Config from '../../Config';
import { Provider, connect } from 'react-redux';
import { reduxForm } from 'redux-form';

import ListingMain from './list';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators'

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    id: state.auth.id,
    userlisting:state.userlist.userlisting,
    userlistingmessage:state.userlist.userlistingmessage,
    pagenumber:state.userlist.pagenumber,
    recordlimit:state.userlist.recordlimit,
    totalusers:state.userlist.totalusers,
    insertcode:state.userlist.insertcode,
    updatecode:state.userlist.updatecode

})


const mapDispatchToProps = (dispatch) => ({
    UserListing: (values) => dispatch(ActionCreators.UserListing(values)),
    insertUserCodeOff: (values) => dispatch(ActionCreators.insertUserCodeOff(values)),
    updateUserCodeOff: (values) => dispatch(ActionCreators.updateUserCodeOff(values))

})  

const UserListComponent = connect(mapStateToProps, mapDispatchToProps)(ListingMain);

class UserManagement extends Component {

    componentDidMount() {
        document.title = Config.name + ' User Management ';
    }
    render() {
        return <Provider store={AppStore}><UserListComponent {...this.props} /></Provider>
    }
}


export default reduxForm({
    form: 'UserFilters',
})(UserManagement);


