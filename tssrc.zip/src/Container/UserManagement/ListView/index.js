import React, { Component } from 'react';
// import Table from '../../../Components/Table';
import Table from '../../../Components/Table/table';
import Config from '../../../Config';
import UserprofileBox from '../../../Components/UserProfileBox';    
import UserManagementCardView from '../../../Components/UserManagementCardView';
import UserManagementListView from '../../../Components/UserManagementListView';

    const tableColumn = [
        {key: 'user_image', label: 'Image', isSort: true,  isImage: true, type: 'callback', callback_function: 'UserImage'},
        {key: 'first_name', label: 'Name', isSort: true, type: 'callback', callback_function: 'UserEditLink'},
        {key: 'email', label: 'Email', isSort: true},
        {key: 'user_telephone', label: 'Telephone', isSort: true},        
        {key: 'user_type', label: 'Type', isSort: true},
        {key: 'created_at', label: 'Date Created', isSort: true},
        {key: 'updated_at', label: 'Date Updated', isSort: true},
    ]; 
    
    
class ListView extends Component {
    constructor(props){
        super(props);
    }
    render() {
        console.error(this.props);
        if(this.props.pageOfItems.length > 0) {
            return(
                <div className="user_list_items">
                    { this.props.cardView === true ? (
                            <UserManagementCardView usertype={this.props.user_type} userDetails={this.props.pageOfItems} />
                        )  : (
                            <UserManagementListView usertype={this.props.user_type} userDetails={this.props.pageOfItems} />
                        )
                    }                    
                </div>
                // <Table user_type={this.props.user_type} column={tableColumn} rows={this.props.pageOfItems} name="user_management" classname="table table-bordered table-striped table-hover"/>
            )

        }
        return true;
    }
}

export default ListView;
