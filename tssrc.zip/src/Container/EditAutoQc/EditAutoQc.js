import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import Config from '../../Config';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect } from 'react-router-dom';
import Loader from '../../Components/Loader';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import FileBase64 from 'react-file-base64';
import './EditAutoQc.css';
import Table from '../../Components/Table/table';
import {Link} from 'react-router-dom';

const tableColumn = [
    {label: 'Item GTIN', key: 'GTIN'},
    {label: 'Item InformationProviderGLN', key: 'InformationProviderGLN'},
    {label: 'Item InformationProviderName', key: 'InformationProviderName'},
    {label: 'Item Target Market', key: 'TargetMarketCountryCode'},
    {label: 'Item product Type', key: 'productType'},
    {label: 'Item Item Global Classification Category Code', key: 'Category'},
    {label: 'Item Global Classification Category Name', key: 'gpcCategoryName'},
    {label: 'Item Global Classification Category Definition', key: 'gpcCategoryDefinition'},
    {label: 'Item Alternate Item Identification', key: 'alternateItemIdentification'},
    {label: 'Item GTIN Name', key: 'gtinName'},
    {label: 'Item Brand Name', key: 'brandOwnerName'},
    {label: 'Item countryOfOrigin', key: 'countryOfOrigin'},
    {label: 'Item Consumer Unit', key: 'isConsumerUnit'},
    {label: 'Item Invoice Unit', key: 'isInvoiceUnit'},
    {label: 'Item Orderable Unit', key: 'isOrderableUnit'},
    {label: 'Item Net Content', key: 'netContent'},
];

const ParentList = (props) => {
    if(props.autoqc_parent_details != undefined ){
        console.log("props.autoqc_parent_details",props);
              return ( <div className="form-group">
                    <div className="inline-checkbox">
                        {
                        Object.values(props.autoqc_parent_details).length > 0 ? 
                        Object.values(props.autoqc_parent_details).map((list,index) => (
                        <div className={index == 0 ? 'autoqc parent' +(list.GTIN.trim() == props.match.params.gtin.trim() ? ' active'  : '')  : 'autoqc sub'+index+(list.GTIN.trim() == props.match.params.gtin.trim() ? ' active'  : '')  }><Link to={Config.userPath[props.user_type]+'editautoqcproduct/'+list.pID+'/'+list.GTIN.trim()}  onClick={() => props.OnChangeValue(list.pID, list.GTIN)}>{list.gtinName}</Link></div>  )): 'No Product(s) Found'                                           
                            }
                    </div>
              </div> )
        }
    return '';
}

class EditAutoQc extends Component {
    constructor(props, context) {
        super(props, context);
        this.MovetoManualQc = this.MovetoManualQc.bind(this);
        this.OnChangeValue = this.OnChangeValue.bind(this);
        
        this.state = {
            editAutoQcCode : false,
        };

    }    


    componentDidMount() {
        this.setState({editAutoQcCode: true});
        let form = document.querySelector('#edit-user');
        let values = serialize(form, { hash: true });
        values.id = this.props.match.params.id;
        values.gtin = this.props.match.params.gtin;
        this.props.GetAutoQcDetails(values);
    }

    MovetoManualQc(e) {

    }

    OnChangeValue(pID, GTIN){
        let form = document.querySelector('#edit-user');
        let values = serialize(form, { hash: true });
        values.id = pID;
        values.gtin = GTIN;
        this.props.GetAutoQcDetails(values);
    }


    render() {
        if (this.props.autoqccode === 1 && this.state.editQcCode) {
            //alert('User Updated Successfully');
            return <Redirect to={Config.userPath[this.props.user_type] + 'autoqc'} />
        }
        console.log("EditAutoQc",this.props.autoqc_details);
        const { handleSubmit } = this.props;

        return (
            <form id="insert-company">
                <div className="insert-company-main">
                <div className="step_3main">
                    <div className="step_3main_detailsform">
                        <div className="insertcompanyform">
                            <div className="cunitform">
                                <div className="row">
                                    <div className="col-xs-12 col-sm-6 col-md-6">
                                        <div className="pdform_column">
                                            <div className="pdform-body">
                                                <h4><strong>Product Hierarchy</strong></h4>
                                                <ParentList {...this.props} OnChangeValue={this.OnChangeValue}/>
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-6">
                                        <div className="pdform_column">
                                            <div className="pdform-body">
                                                <h4><strong>Reason for rejection</strong></h4>
                                                <textarea disabled className={"insertprefixt-text-area"} value={this.props.autoqc_details.Reason} component="textarea" onChange={this.handleChange} />
                                            </div>
                                        </div> 
                                    </div> 
                                </div>
                                <br />
                                <div className="row ">
                                    <div className="col-xs-12 col-sm-9 col-md-7">
                                        <div className="pdform_column">
                                            <div className="pdform-body">
                                                <div className="user-info-details">
                                                    <table className="editautoqc-tbl">
                                                        <tr>
                                                            <th>Item GTIN</th>
                                                            <td>{this.props.autoqc_details.GTIN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item InformationProviderGLN</th>
                                                            <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item InformationProviderName</th>
                                                            <td>{this.props.autoqc_details.InformationProviderName}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Target Market</th>
                                                            <td>{this.props.autoqc_details.TargetMarketCountryCode}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item product Type</th>
                                                            <td>{this.props.autoqc_details.productType}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Item Global Classification Category Code</th>
                                                            <td>{this.props.autoqc_details.Category}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Global Classification Category Name</th>
                                                            <td>{this.props.autoqc_details.gpcCategoryDefinition}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Global Classification Category Definition</th>
                                                            <td>{this.props.autoqc_details.alternateItemIdentification}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Alternate Item Identification</th>
                                                            <td>{this.props.autoqc_details.gtinName}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item GTIN Name</th>
                                                            <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Brand Name</th>
                                                            <td>{this.props.autoqc_details.brandOwnerName}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item countryOfOrigin</th>
                                                            <td>{this.props.autoqc_details.countryOfOrigin}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Consumer Unit</th>
                                                            <td>{this.props.autoqc_details.isConsumerUnit}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Invoice Unit</th>
                                                            <td>{this.props.autoqc_details.isInvoiceUnit}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Orderable Unit</th>
                                                            <td>{this.props.autoqc_details.isOrderableUnit}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Net Content</th>
                                                            <td>{this.props.autoqc_details.netContent}</td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12 col-sm-9 col-md-5">
                                        <div className="pdform_column">
                                            <div className="pdform-body">
                                            <table className="editautoqc-tbl" style={{width: '100%'}}>
                                                        <tr>
                                                            <th>Item GTIN</th>
                                                            <td>{this.props.autoqc_details.GTIN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item InformationProviderGLN</th>
                                                            <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Target Market</th>
                                                            <td>{this.props.autoqc_details.TargetMarketCountryCode}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item product Type</th>
                                                            <td>{this.props.autoqc_details.productType}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item GTIN Name</th>
                                                            <td>{this.props.autoqc_details.InformationProviderGLN}</td>
                                                        </tr>
                                                        <tr>
                                                            <th>Item Brand Name</th>
                                                            <td>{this.props.autoqc_details.brandOwnerName}</td>
                                                        </tr>

                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="pdform_column">
                                        <div className="pdform-body">
                                            <button type="submit" className="btn btn-primary">Move to ManualQC</button>
                                        </div>
                                    </div>
                                </div>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        );
    }
}

export default reduxForm({
    form: 'EditAutoQcForm',
})(EditAutoQc);




