import React, { Component } from 'react';
import Config from '../../Config';
import { Provider, connect } from 'react-redux';

import EditForm from './EditAutoQc';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    autoqc_details:state.autoqcdata.autoqc_details,
    autoqc_parent_details:state.autoqcdata.autoqc_parent_details,
    id:state.auth.id,
    user_auth:state.auth
})


const mapDispatchToProps = (dispatch) => ({
    GetAutoQcDetails: (values) => dispatch(ActionCreators.GetAutoQcDetails(values)),
})

const EditAutoQcComponent = connect(mapStateToProps, mapDispatchToProps)(EditForm);

class EditAutoQc extends Component {
    
    componentDidMount() {
        document.title = Config.name + ' Edit AutoQc';
    }
    
    render() {
        return <Provider store={AppStore}><EditAutoQcComponent {...this.props} /></Provider>
    }
}


export default EditAutoQc;


