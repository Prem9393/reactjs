import React, { Component } from 'react';
import Table from '../../Components/Table/table';
//import '../custom/css/adminlte.css';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import Config from '../../Config';
import { Col, Row } from 'react-bootstrap';
import {reset} from 'redux-form';
import { reduxForm, Field, change } from 'redux-form';
import { connect } from 'react-redux';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';
import Pagination from '../../Components/QcPagination';
import serialize from 'form-serialize';
import Loader from '../../Components/Loader';
import SlidingPane from 'react-sliding-pane';
import AutoQcDetail  from '../../Components/AutoQcDetail';
import './AutoQc.css';
import SlidingPanelTitle from '../../Components/SlidingPanelTitle';


const tableColumn = [
    {label: '', key: 'id', type: 'checkbox'},
    {label: 'GTIN' , key: 'GTIN', isSort: true, type: 'callback', callback_function: 'AutoQcProductEditLink'},
    {label: 'Description' , key: 'gtinName', type: 'callback', callback_function: 'AutoQcProductName'},
    {label: 'Supplier', key: 'InformationProviderName'},
    {label: 'Date', key: 'time', type: 'callback', callback_function: 'AutoQcDate'},
    {label: 'Status', key: 'StatusCode', type: 'callback', callback_function: 'AutoQcStatusCode'},
    {label: '', key: 'action', type: 'callback', callback_function: 'AutoQcBypass'},

];


class AutoQc extends Component {

    constructor(props, context) {
        super(props, context);
        this.state = {
            isLoading: true,
            isPaneOpen: false,
            isPaneOpenLeft: false,
            checked:false,
            items:[],
            differences_EA:false,
            differences_PL:false,
            differences_CS:false,
            differences_SHR:false,
        };

        this.OpenPanel = this.OpenPanel.bind(this);
        this.AutoQcProductsPagination = this.AutoQcProductsPagination.bind(this);
        this.getCheckboxCount = this.getCheckboxCount.bind(this);
    }

    static getDerivedStateFromProps(props, state) {
        if  (props.autoqclist != undefined && props.autoqclist.length > 0) {
            return {
                isLoading: false,
                items: props.autoqclist.concat(),
            }
        } else {
            return null;
        }
    }

    AutoQcProductsPagination(pagenumber) {
        var form = document.querySelector('#autoqc-frm');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = pagenumber;
        form_fields.record_limit = this.props.recordlimit;
        this.setState({ isLoading: true });
        this.props.AutoQcListing(form_fields);
    }

    AutoQcFilterProductsPagination() {
        var form = document.querySelector('#autoqc-frm');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = this.props.pagenumber;
        form_fields.record_limit = this.props.recordlimit;
      //  this.setState({ isLoading: true });

      //  console.log("AutoQcFilterProductsPagination form_fields",form_fields);
        this.props.AutoQcListing(form_fields);
    }

    clearItems(){
        this.props.dispatch(reset('AutoQcForm'));   
        this.props.AutoQcListing();
      }

    OpenPanel(time,GTIN,GUID,aID){
        this.setState({ isPaneOpen: true, time:time, GTIN:GTIN, GUID:GUID,aID:aID,differences_EA:false,
            differences_PL:false,
            differences_CS:false,
            differences_SHR:false,});
        
    }

    

    getCheckboxCount(idx){
        const items = this.state.items.concat();
            items[idx].checked = !items[idx].checked;
            this.setState({items});

       // this.setState({ checked});        
    }

    componentDidMount() {
        document.title = Config.name + ' Quality Control';

        var form = document.querySelector('#autoqc-frm');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = this.props.pagenumber;
        form_fields.record_limit = this.props.recordlimit;


        this.props.AutoQcListing(form_fields);
    }

    getInitialState() {
        return {
            items: this.props.items.concat(),
        };
    }

    onCheckChange(idx) {
        return () => {
            const items = this.state.items.concat();
           
            items[idx].checked = !items[idx].checked;
            if(this.state.items[idx].checked = "false"){
                items[idx].checked = "true";
            } else {
                items[idx].checked = "false";
            }
            this.setState({items});
            
        }
    }

    totalChecked() {
        if(this.state.items != undefined){
            return this.state.items.filter(props => props.checked).length;
        }
        
    }


    render(){
        
       
     //   console.log('listing state', this.state)
        const {  handleSubmit } = this.props;
        return (
            <div className="autoqc-inner">
                <form id="autoqc-frm" >
                <Loader showloader={this.state.isLoading} />
                <div className="step_3main bg-grey">
                        <div className="row content-main-header">
                            <div className="col-md-6">
                                <div className="content-head-left-side">
                                    <div className="project-count-wrap">
                                        <p>Rejected products<span><strong>{this.props.totalproducts}</strong></span></p>
                                    </div>
                                    <div className="filter-container">
                                        <div className="form-group has-search">
                                            <span className="fa fa-search form-control-feedback"></span>
                                            <Field component={Common.renderInput}  type="text" id="search_GTIN" className="form-control autoqc-head" name="search_GTIN" onChange={this.AutoQcFilterProductsPagination.bind(this)} placeholder="Fliter by description or GTIN"  />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="cont-head-right-side">
                                    <div className="col-md-4">
										<div className="suppliers-dropdown pull-right">
											<div className="input-group date">
												<span className="input-group-addon"><i className="fa fa-cube "></i></span>
												<RenderSelect 
													component={Common.renderInput}
													custom_options_start={[{ 'label': 'All Suppliers', 'value': '' }]}  options={this.props.qcproductsupplier != null ? this.props.qcproductsupplier : ''}
													type="select" 
													id="search_Supplier"
													className="mdb-select md-form colorful-select dropdown-primary" 
													name="search_Supplier" 
													onChange={this.AutoQcFilterProductsPagination.bind(this)}
													placeholder="Search Supplier" 
												/>
											</div>
										</div>
									</div>
                                    <div className="col-md-4">
                                        <div className="date-picker-wrap pull-right">
                                            <div id="datepicker" className="input-group date">
                                                <span className="input-group-addon"><i className="glyphicon glyphicon-calendar"></i></span>
                                                <RenderSelect 
                                                    component={Common.renderInput}
                                                    custom_options_start={[{ 'label': 'All Dates', 'value': '' }]}  options={this.props.qcproducttime != null ? this.props.qcproducttime : ''}
                                                    type="select" 
                                                    id="search_Date"
                                                    className="mdb-select md-form colorful-select dropdown-primary" 
                                                    name="search_Date" 
                                                    onChange={this.AutoQcFilterProductsPagination.bind(this)}
                                            />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-4">
                                        
                                        <div className="table-list-switcher pull-right">
                                            <input id="toggle-on" className="toggle toggle-left" name="toggle" value="false" type="radio" defaultChecked="checked" onChange={this.handleChange} />
                                            <label htmlFor="toggle-on" className="btn">Table</label>
                                            <input id="toggle-off" className="toggle toggle-right" name="toggle" value="true" type="radio" />
                                            <label htmlFor="toggle-off" className="btn">List</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="inner-main-padding">
                            <div className="table-data-wrapper table-responsive">
                                <Table
                                    {...this.props}
                                    user_type={this.props.user_type}
                                    state={this.state}
                                    OpenPanel={this.OpenPanel}
                                    column={tableColumn}
                                    rows={this.props.autoqclist} 
                                    name="quality_control"
                                    classname="table table-hover"
                                    getCheckboxCount={this.getCheckboxCount}
                                />
                            </div>
                        </div>
                        
                        <div className="table-pagination">
							<div className="checked-items-btn-wrapper">
								<div className="checked-btn-pos">
									{ this.totalChecked() > 0 ? <button type="button" className="btn btn-primary bypass-btn">Bypass { this.totalChecked() } Item(s)</button> : '' }
								</div>
							</div>
							<div className="left-btn-pagination">
								<Pagination {...this.props} AutoQcProductsPagination={this.AutoQcProductsPagination}/>
							</div>
                        </div>
                    </div>
                    <div ref={ref => this.el = ref}>
                        <SlidingPane
                            className='some-custom-class'
                            overlayClassName='some-custom-overlay-class'
                            isOpen={ this.state.isPaneOpen }
                            title={<SlidingPanelTitle {...this.props}/>} 
                            subtitle={this.props.autoqc_details.gtinName+' ['+this.props.autoqc_details.productType+'] '}                             
                            onRequestClose={ () => {
                                // triggered on "<" on left top click or on outside click
                                this.setState({ isPaneOpen: false });
                            } }>
                            <AutoQcDetail {...this.props} state={this.state} />
                        </SlidingPane>            
                    </div>
                </form>
        </div>
        )
    }
}

const Form = reduxForm({
    form: 'AutoQcForm',
})(AutoQc);

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    autoqclist: state.autoqclist.autoqclisting,
    totalproducts: state.autoqclist.totalqcproducts,
    pagenumber: state.autoqclist.pagenumber,
    recordlimit: state.autoqclist.recordlimit,
    qcproductsupplier:state.autoqclist.qcproductsupplier,
    autoqc_details:state.autoqcdata.autoqc_details,
    autoqcparentrevisiondetails:state.autoqcrevisiondata.autoqcparentrevisiondetails,
    productrevisions:state.autoqcdata.productrevisions,
    autoqc_parent_details:state.autoqcdata.autoqc_parent_details,
    qcproducttime:state.autoqclist.qcproducttime,
    autoqcrevisiondata:state.autoqcrevisiondata.autoqc_revisiondetails,
    remainingproducts:state.autoqclist.remainingproducts,
    rejectionmessage:state.autoqclist.rejectionmessage,
})


const mapDispatchToProps = (dispatch) => ({
    AutoQcListing: (values) => dispatch(ActionCreators.AutoQcListing(values)),
    GetAutoQcDetails: (values) => dispatch(ActionCreators.GetAutoQcDetails(values)),
    GetAutoRevisionQcDetails: (values) => dispatch(ActionCreators.GetAutoRevisionQcDetails(values)),
})

export default connect(mapStateToProps, mapDispatchToProps)(Form);