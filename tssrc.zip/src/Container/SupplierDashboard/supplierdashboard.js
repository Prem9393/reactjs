import React,{Component} from 'react';
import { Col,Row  } from 'react-bootstrap';
import Piechart from '../../Components/Charts/Piechart'
import ImageChart from '../../Components/ImageChart';
import InfoBox from '../../Components/InfoBox'
import Config from '../../Config';
import Loader from '../../Components/Loader';
import {Doughnut} from 'react-chartjs-2';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';

const option1 =  {
	cutoutPercentage: 80,
	legend: {
		display: false
	},
	layout:{
		padding:40
	}, 
	elements: {
		arc: {
			roundedCornersFor: 0
		},
		center: {
			text: '67%',
		}
	}
};

var data = {
	labels: ['Red', 'Green', 'Yellow'],
	datasets: [{
			data: [300, 50, 100],
			backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
			hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
	}]
};

const products = [ {
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Braai Cleaner 500 - ml",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "BabySoft 2 ply Toilet Paper White 18 - rolls",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Samsung Freezer Silver 491 - pc",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Mel's Shampoo Shinny 12 - pc",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "POND'S Lasting Oil Control Vanishing Cream For Very Oily Skin 100 - ml",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Nescafe Instant Coffee Gold 200 GR",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
},{
	gtin: "6002816003095",description: "Weber Briquettes Hardwood Charcoal 4 - kg",assigned: "NA",duration: "NA"
}];
const columns = [{
  dataField: 'gtin',
	text: 'GTIN',
	sort: true
}, {
  dataField: 'description',
	text: 'Description',
	sort: true
}, {
  dataField: 'assigned',
	text: 'Assigned',
	sort: true
},{
  dataField: 'duration',
	text: 'Duration',
	sort: true
}];

const GetImageChart = (props) =>{
    let leftdetails='';
    let bgName ='';
    let iconName ='';
    if(props.details){
        if(props.details.length){
            leftdetails = props.details.map((list, key)=>{
             
                if(key ==1){
                    bgName = 'small-box bg-green';
                    iconName = 'ion ion-clock';
                }else if(key ==2){
                    bgName = 'small-box bg-aqua-active';
                    iconName = 'ion ion-checkmark-circled';
                } else if(key ==3){
                    bgName = 'small-box bg-red';
                    iconName = 'ion ion-edit';
                }else {
                    bgName = 'small-box bg-lime';
                    iconName = 'ion ion-alert-circled';
                }

            return (<InfoBox 
                key={key} 
                link={Config.userPath[props.user_type]+'productbrowser/'+list.status_name}
                bgName= {bgName } 
                imagename={iconName} 
                count={list.count} 
                text={list.status_name}/>)
            })
        }
    }
    return leftdetails;
 }
 


export default class SupplierDashbaord extends Component{

    constructor(props){
        super(props);
        this.state ={
            rightpannel:[],
            products:0,
            leftpannel:[],
            colorcode:[],
            colorcount:[],
            isLoading: true
        }
    }

    static getDerivedStateFromProps(props,state){
        if(props.dashboard.hasOwnProperty('active_count')){
            return {
				leftpannel : props.dashboard.left_panel,				
				entirepannel : props.dashboard.entire_panel,
                products : props.dashboard.active_count,
                rightpannel : props.dashboard.right_panel,
                colorcode : props.dashboard.pie_chart.color_code,
                colorcount : props.dashboard.pie_chart.color_count,
                isLoading: false
            }
        }
        return null
       
    }

    componentDidMount(){
        document.title = Config.name+' Dashboard ';
        var token_value={
            token:this.props.token
        }
        this.props.DashbaordListing(token_value);
        this.props.ResetStateMessage('login');
        this.props.ResetStateMessage('register');
		this.props.ResetStateMessage('reset');
		this.props.ResetStateMessage('forget');
    }


  render() {
    const chart4 = {
			labels: ['Auto QC Failure', 'Manual QC Failure', 'Audit Failure'],
			datasets: [{
					label: '# of Votes',
					data: [12, 19, 3],
					backgroundColor: [
							'rgba(222, 78, 59, 1)',
							'rgba(243, 156, 18, 1)',
							'rgba(0, 192, 239, 1)',
					],
					borderColor: [
							'rgba(222, 78, 59, 1)',
							'rgba(243, 156, 18, 1)',
							'rgba(0, 192, 239, 1)'							
					],
					borderWidth: 1
			}],
			text: '45%'
	};
		
		
    return (
      <div className="supplierdashboard dashboard_chart">
        <Loader showloader={this.state.isLoading} />
    <Row>
				<Col xs={12} md={12}>
						<div className="row">
                            <GetImageChart details = {this.state.entirepannel} user_type={this.props.user_type}/>
						</div>
				</Col>
				
				
				{/* <Col xs={12} md={6}>
							<div className="no_files" >
									<div id="pieChart">
										<Piechart width={200} height={200}  data={chart4} option={option1} text={'8 Active'}/>
                                        <div className="chartCount">
                                            {this.state.products} <br/> Active
                                        </div>
									</div>
							</div>
				</Col>
				<Col xs={12} md={3}>
						<div className="right_side">
                        <GetImageChart details = {this.state.rightpannel} user_type={this.props.user_type}/>
						</div>
				</Col> */}
                </Row>

                <Row>
        <div className="col-md-8">
          <div className="box">
            <div className="box-header with-border">
              <h3 className="box-title">Enrichment Status</h3>

              
            </div>
            
            <div className="box-body">
              <div className="row">
			  	
                <div className="col-md-10">
                  <div className="progress-group">
					<div className="progress-bar" style={{backgroundColor: '#555', width: '15%'}}>Images</div>
                    <div className="progress lg">
                      <div className="progress-bar progress-bar-green" style={{width: '20%'}}>98</div>
					  <div className="progress-bar progress-bar-yellow" style={{width: '30%'}}>129</div>
					  <div className="progress-bar progress-bar-red" style={{width: '50%'}}>218</div>
                    </div>
                  </div>
				  <div className="progress-group">
					<div className="progress-bar" style={{backgroundColor: '#555', width: '15%'}}>Brand Enrichment</div>
                    <div className="progress lg">
                      <div className="progress-bar progress-bar-green" style={{width: '20%'}}>170</div>
					  <div className="progress-bar progress-bar-yellow" style={{width: '20%'}}>35</div>
					  <div className="progress-bar progress-bar-red" style={{width: '20%'}}>150</div>
                    </div>
                  </div>
				  <div className="progress-group">
					<div className="progress-bar" style={{backgroundColor: '#555', width: '15%'}}>Product Label</div>
				    <div className="progress lg">
				      <div className="progress-bar progress-bar-green" style={{width: '10%'}}>45</div>
				  	  <div className="progress-bar progress-bar-yellow" style={{width: '15%'}}>60</div>
				  	  <div className="progress-bar progress-bar-red" style={{width: '75%'}}>250</div>
				    </div>
				  </div>
				  <div className="progress-group">
					<div className="progress-bar" style={{backgroundColor: '#555', width: '15%'}}>Basic Data</div>
				    <div className="progress lg">
				      <div className="progress-bar progress-bar-green" style={{width: '100%'}}>355</div>
				  	  <div className="progress-bar progress-bar-yellow" style={{width: '20%'}}></div>
				  	  <div className="progress-bar progress-bar-red" style={{width: '20%'}}></div>
				    </div>
				  </div>
                  
				  
                </div>
                
			
                <div className="col-md-2">

                  <div className="progress-group">
                    <span className="progress-text">Complete</span>
					<span className="progress-number"><b></b></span>

                    <div className="progress sm">
                      <div className="progress-bar progress-bar-green" style={{width: '100%'}}></div>
                    </div>
                  </div>
                 
				  
                  <div className="progress-group">
                    <span className="progress-text">Work in Progress</span>
					<span className="progress-number"><b></b></span>

                    <div className="progress sm">
                      <div className="progress-bar progress-bar-yellow" style={{width: '100%'}}></div>
                    </div>
                  </div>
                 
				  
                  <div className="progress-group">
                    <span className="progress-text">Not yet Started</span>
                    <span className="progress-number"><b></b></span>

                    <div className="progress sm">
                      <div className="progress-bar progress-bar-red" style={{width: '100%'}}></div>
                    </div>
                  </div>
                 
				  
                </div>
               
				
              </div>
            
            </div>
           
            
          </div>
        
        </div>
       
		
				<div className="col-md-4">
		          <div className="box">
		            <div className="box-header">
		              <h3 className="box-title">Rejected</h3>
		
		             
		            </div>
		           
		            <div className="box-body">
		              <div className="row">
		                <div className="col-md-12">
		                  <div className="chart-responsive">
											<Doughnut data={chart4} />
		                  </div>
		                  
		                </div>
		                
		                {/* <div className="col-md-6">
		                  <ul className="chart-legend clearfix">
		                    <li><i className="fa fa-circle-o text-red"></i> Auto QC Failure</li>
		                    <li><i className="fa fa-circle-o text-yellow"></i> Manual QC Failure</li>
		                    <li><i className="fa fa-circle-o text-aqua"></i> Audit Failure</li>
		                  </ul>
		                </div> */}
		              
		              </div>
		             
		            </div>
		         
		          </div>
		         
				</div> 
				
     

      </Row>



      <Row>
        <div class="col-md-8">
          
		  
		  <div class="box box-warning">
		    <div class="box-header">
		      <h3 class="box-title">Pending Approval</h3>
		    </div>
		    <div class="box-body">

					<BootstrapTable keyField='id' data={ products } columns={ columns } pagination={ paginationFactory() }/>

		     
		    </div>
		   
		  </div>
		  
		</div>
		
		 <div class="col-md-4">
			
                <Row>
                    <div class="col-md-12 ">

		              <div class="nav-tabs-custom">
		                          <ul class="nav nav-tabs">
		                            <li class="active"><a href="#tab_1" data-toggle="tab">Product Search</a></li>
		                            <li><a href="#tab_2" data-toggle="tab">Import Data</a></li>
		                            <li><a href="#tab_3" data-toggle="tab">Upload Image</a></li>
		                          </ul>
		                          <div class="tab-content">
		                            <div class="tab-pane active" id="tab_1">
										<form role="form">
							              <div class="box-body">
							                <div class="form-group">
							                  <label for="exampleInputEmail1">Search Items</label>
							                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter search term" />
							                </div>
							              </div>
							              
							
							              <div class="box-footer">
							                <button type="submit" class="btn btn-primary">Submit</button>
							              </div>
							            </form>
		                            </div>
		                            
		                            <div class="tab-pane" id="tab_2">
										<form role="form">
							              <div class="box-body">
							                <div class="form-group">
							                  <label for="exampleInputFile">File input</label>
							                  <input type="file" id="exampleInputFile" />
							                </div>
							              </div>
							              
							
							              <div class="box-footer">
							                <button type="submit" class="btn btn-primary">Submit</button>
							              </div>
							            </form>
		                            </div>
		                            
		                            <div class="tab-pane" id="tab_3">
									   <form role="form">
		                 	              <div class="box-body">
		                 	                <div class="form-group">
		                 	                  <label for="exampleInputFile">File input</label>
		                 	                  <input type="file" id="exampleInputFile" />
		                 	                </div>
		                 	              </div>
		                 	              
		                 	
		                 	              <div class="box-footer">
		                 	                <button type="submit" class="btn btn-primary">Submit</button>
		                 	              </div>
		                 	            </form>
		                            </div>
		                            
		                          </div>
		                          
		                        </div>
                            </div>
										

														<div class="col-md-12">
				         
				          <div class="box box-success">
				            <div class="box-header with-border">
				              <h3 class="box-title">Notifications</h3>
				
				             
				            </div>
				           
				<div class="box-body">
				  <ul class="products-list product-list-in-box">
				    <li class="item">
				      <div class="product-img">
				        <img src="assets/images/default-50x50.gif" alt="Product Image" />
				      </div>
				      <div class="product-info">
				        <a href="javascript:void(0)" class="product-title">Notification 1
				          <span class="label label-warning pull-right">NEWS</span></a>
				        <span class="product-description">
				             Description
				            </span>
				      </div>
				    </li>
				  
				    <li class="item">
				      <div class="product-img">
				        <img src="assets/images/default-50x50.gif" alt="Product Image" />
				      </div>
				      <div class="product-info">
				        <a href="javascript:void(0)" class="product-title">Notification 2
				          <span class="label label-info pull-right">NOTICE</span></a>
				        <span class="product-description">
				              Description
				            </span>
				      </div>
				    </li>
				    
				    <li class="item">
				      <div class="product-img">
				        <img src="assets/images/default-50x50.gif" alt="Product Image" />
				      </div>
				      <div class="product-info">
				        <a href="javascript:void(0)" class="product-title">Notification 3 <span
				            class="label label-danger pull-right">ALERT</span></a>
				        <span class="product-description">
				              Description
				            </span>
				      </div>
				    </li>
				   
				  </ul>
				</div>
				<div class="box-footer text-center">
				  <a href="javascript:void(0)" class="uppercase">View All Notifications</a>
				</div>
				</div>
			
				</div>

                </Row>
        	
		 </div>
		</Row>


      </div>
    );
  }
}
