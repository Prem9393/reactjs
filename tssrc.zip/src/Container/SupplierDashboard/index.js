import React,{Component} from 'react';
import {Provider, connect} from 'react-redux';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators'
import SupplierDashboard from './supplierdashboard'
//import './AdminLTE.min.css'

const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    user_type:state.auth.user_type,
    user_id:state.auth.user_id,
    user_company_id : state.auth.user_company_id,
    userLanguage : state.auth.userLanguage != '' ? state.auth.userLanguage : 'EN',
      is_view:state.auth.is_view,
      is_modify:state.auth.is_modify,
      is_user_view:state.auth.is_user_view,
      is_user_modify:state.auth.is_user_modify,
      is_product_view:state.auth.is_product_view,
      is_product_edit:state.auth.is_product_edit,
      is_product_upload:state.auth.is_product_upload,
    token:state.auth.token,
    dashboard:state.dashboard.dashboardlisting,
    dahsboardmessage:state.dashboard.dahsboardmessage,
})

const mapDispatchToProps = (dispatch) => ({
    ResetStateMessage: (values) => dispatch(ActionCreators.ResetStateMessage(values)),
    DashbaordListing: (values) => dispatch(ActionCreators.userDashboard(values)),
})

const DashboardComponent  = connect(mapStateToProps, mapDispatchToProps)(SupplierDashboard);

class DashboardHolder extends Component{

  componentDidMount() {
    // const script = document.createElement("script");
    // script.async = true;
    // script.src = "/assets/js/dashboard2.js";
    
    // document.body.appendChild(script);

    // const style = document.createElement("script");
    // style.async = true;
    // style.src = "/assets/js/bower_component/chart.js/Chart.js";
    
    // document.body.appendChild(script);
  }


  render() {
    return <Provider store={AppStore}><DashboardComponent/></Provider>
  }
}

export default DashboardHolder;