import React, { Component } from 'react';
import { reduxForm } from 'redux-form'
import Config from '../../Config';
import InsertCompanyDetails from './CompanyDetail';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import {Redirect}  from 'react-router-dom';
import SimpleReactValidator from 'simple-react-validator';
import { Button } from 'react-bootstrap';

class InsertCompany extends Component {
    constructor(props, context) {
        super(props, context);
        this.validator = new SimpleReactValidator();
        this.handleSelect = this.handleSelect.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.onChange = this.onChange.bind(this);
        this.nextPage = this.nextPage.bind(this);
        this.getFiles = this.getFiles.bind(this);
        
        this.state = {
            files:'',
            actionkey: 1,
            company_details:[],
            insertcode:false,
            currentTab:""
        };

        
    }

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    onChange(tabKey, currenttab){
     this.setState({actionkey: tabKey })
    }

    handleChange(name,event){
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        // const name = target.name;
        this.setState({
            [name]: value
        });
    }

    getFiles(files){
          console.log("files",files);
          this.setState({ files: files })
    }


    componentWillMount(){
        this.setState({insertcode: true})
    }
    

    manageCompany(values){
        // console.log(this.props.CompanyTypeList());
        if( this.validator.allValid() ){
          //  alert('You submitted the form and stuff!');
          } else {
            this.validator.showMessages();
          }

        var form = document.querySelector('#insert-company');
        var values = serialize(form,{ hash: true });
        values.token = this.props.token; 

        console.log("this.state",this.state);
        
        if(this.state.files.base64){
            values.CompanyLogo = this.state.files.base64
        }
        
        console.log("insert values", values)
        this.props.InsertCompany(values);
    }

    static getDerivedStateFromProps(props, state){

        return{
            actionkey : state.actionkey
        }
    }

   
    nextPage() {
        this.setState({ actionkey: this.state.actionkey+1});
    }


    render() {

        if(this.props.insertcode === 1 ){
            return <Redirect to={Config.userPath[this.props.user_type]+'companyprofile'}/>
        }
        

        const {  handleSubmit } = this.props;

        return (
            <form id="insert-company" onSubmit={handleSubmit(this.manageCompany.bind(this))}>
                <div className="insert-company-main">
                <div className="step_3main">
                    <div className="step_3main_detailsform">
                        <h5 className="insert-company-header"><strong> Insert Company Details</strong></h5>
                        <InsertCompanyDetails getFiles={this.getFiles} handleChange={this.handleChange } onChange={this.onChange } {...this.state} {...this.props}/>

                    </div>
                </div>
                </div>
            </form>
        );
    }
}



export default reduxForm({
    form: 'CompanyForm',
    validate:Validation.ValidateCompanyForm
})(InsertCompany);