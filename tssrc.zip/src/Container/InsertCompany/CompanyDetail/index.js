import React, { Component } from 'react';
import { Field, reduxForm, formValueSelector, change } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';
import SimpleReactValidator from 'simple-react-validator';
import { normalizeMaxLength, normalizeNumber, normalizeNumberAndSetLimit } from '../../../Validations';
import { companyDetailValidation } from '../../helpers/validationhelper';
import FileBase64 from 'react-file-base64';
import Config from '../../../Config';
import Table from '../../../Components/Table/table';

//import img from '../../../images/128.png';

const tableColumn = [
    {label: 'id', key: 'id'},
    {label: 'First Name' , key: 'first_name'},
    {label: 'Last Name' , key: 'last_name'},
    {label: 'Login Name', key: 'user_name'},
    {label: 'Email', key: 'email'},
    {label: 'Contact No', key: 'user_telephone'},
    {label: 'Status', key: 'is_active'},
];



class InsertCompanyDetails extends Component {

    constructor(props) {

        super(props);
        
        this.validator = new SimpleReactValidator();
     
        this.handleChange = this.handleChange.bind(this);
        this.state = {
            files:'',
            tabkey: 1,
            select_options: [
                { label: 'Supplier/Manufacturer', value: '1' },
                { label: 'Retailer', value: '2' },
                { label: '3rd Party', value: '7' },
            ],

            parent_company: [
                { label: 'GS1 Southafrica', value: '1' },
            ],
            title: "",
            BatchUserId: "",
            CompanyName: "",
            ContactName: "",
            CompanyGLN: "",
            ContactEmail: "",
            ContactTel: "",
            ContactFax: "",
            WebServiceGLN: "",
            WebServiceKey: "",
            country_list: [
                { label: 'South Africa', value: '1' },
            ],
            checkBoxSelected: true
        }
    }



    onChangeValue(e) {

    }

    handleChange(e) {
        this.setState({ checkBoxSelected: !this.state.checkBoxSelected });

        if (this.state.checkBoxSelected) {
            this.props.dispatch(change('CompanyForm', 'PostalPoBox', this.props.StreetNumberName));
            this.props.dispatch(change('CompanyForm', 'PostalSubrubName', this.props.SubrubName));
            this.props.dispatch(change('CompanyForm', 'PostalCityName', this.props.CityName));
            this.props.dispatch(change('CompanyForm', 'PostalPostalCode', this.props.PostalCode));
            this.props.dispatch(change('CompanyForm', 'PostalCountry', this.props.ParentCompany));
            this.props.dispatch(change('CompanyForm', 'PostalProvince', this.props.Province));
        } else {
            this.props.dispatch(change('CompanyForm', 'PostalPoBox', ''));
            this.props.dispatch(change('CompanyForm', 'PostalSubrubName', ''));
            this.props.dispatch(change('CompanyForm', 'PostalCityName', ''));
            this.props.dispatch(change('CompanyForm', 'PostalPostalCode', ''));
            this.props.dispatch(change('CompanyForm', 'PostalCountry', ''));
            this.props.dispatch(change('CompanyForm', 'PostalProvince', ''));

        }

    }
    handleChangeField(e){
        this.setState({[e.target.id]: e.target.value})    
    }


    render() {

        
      
         let img = Config.companylogopath + 'default.png';
         
        return (
            <div className="insertcompanyform">
                <div className="cunitform">
                        <div className="">
                            <div className="pdform_column">
                                <div className="pdform-body">
                                <div className="form-group ">
                                <h5><strong>Contact Name / Contact Details</strong></h5>
                                        <label>Company Logo</label>
                                        
                                        {/* <Field
                                            name="CompanyName"
                                            component={Common.renderInput}
                                            type="text"
                                            id="CompanyName"
                                            className="form-control hsmall"
                                            onChange={this.onChangeValue.bind(this)}
                                            onBlur={this.props.handleChange.bind(this, 'Company Name')}
                                            normalize={normalizeMaxLength(100)}
                                            onBlur={this.handleChangeField.bind(this)}
                                        /> */}

                                        {this.validator.message('title', this.state.title, 'required|alpha')}
                                    </div>

                                    <div className="form-group ">
                                        
                                        <label>Company Name</label>
                                        <Field
                                            name="CompanyName"
                                            component={Common.renderInput}
                                            type="text"
                                            id="CompanyName"
                                            className="form-control hsmall"
                                            onChange={this.onChangeValue.bind(this)}
                                            onBlur={this.props.handleChange.bind(this, 'Company Name')}
                                            normalize={normalizeMaxLength(100)}
                                            onBlur={this.handleChangeField.bind(this)}
                                        />

                                        {this.validator.message('title', this.state.title, 'required|alpha')}
                                    </div>


                                    <div className="form-group ">
                                        <label>Company GLN</label>
                                        <Field
                                            name="CompanyGLN"
                                            component={Common.renderInput}
                                            type="text"
                                            id="CompanyGLN"
                                            className="form-control hsmall"
                                            onBlur={this.props.handleChange.bind(this, 'company_details')}
                                            onChange={this.onChangeValue.bind(this)}
                                            normalize={normalizeNumberAndSetLimit(100)}
                                            onBlur={this.handleChangeField.bind(this)}
                                        />
                                    </div>

                                    <div className="form-group ">
                                        <label>Company Type</label>
                                        <RenderSelect options={this.state.select_options} onChange={this.onChangeValue.bind(this)} className="form-control hsmall arrow" name="CompanyType" id="CompanyType" />
                                    </div>

                                    <div className="form-group ">
                                        <label>Parent Company</label>
                                        <Field name="ParentCompany" onChange={this.onChangeValue.bind(this)} component={Common.renderSelect} type="select" id="ParentCompany" options={this.state.parent_company} className="form-control hsmall" />
                                    </div>
                            <div className="row m-0">
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Batch User Id</label>
                                        <Field
                                            name="BatchUserId"
                                            component={Common.renderInput}
                                            type="text"
                                            onChange={this.onChangeValue.bind(this)}
                                            onBlur={this.props.handleChange.bind(this, 'company_details')}
                                            id="BatchUserId"
                                            className="form-control hsmall"
                                            normalize={normalizeNumberAndSetLimit(100)}
                                        />
                                    </div>
                                    </div>

                                    <div className=" col-md-4">
                                    <div className="form-group">
                                        <label>Web Service GLN</label>
                                        <Field
                                            name="WebServiceGLN"
                                            component={Common.renderInput}
                                            onChange={this.onChangeValue.bind(this)}
                                            type="text" onBlur={this.props.handleChange.bind(this, 'company_details')}
                                            id="WebServiceGLN"
                                            className="form-control hsmall"
                                            normalize={normalizeNumberAndSetLimit(100)}
                                        />
                                    </div>
                                    </div>
                                    <div className=" col-md-4">
                                    <div className="form-group">
                                        <label>Web Service Key</label>
                                        <Field
                                            name="WebServiceKey"
                                            component={Common.renderInput}
                                            type="text"
                                            onChange={this.onChangeValue.bind(this)}
                                            onBlur={this.props.handleChange.bind(this, 'company_details')}
                                            id="WebServiceKey"
                                            className="form-control hsmall"
                                            normalize={normalizeNumberAndSetLimit(100)}
                                        />
                                    </div>
                                    </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="">
                            <div className="pdform_column">
                                <div className="pdform-body">
                                    <h5><strong>Physical Address</strong></h5>
                                    <div className="form-group ">
                                        <label>Address 1 </label>
                                        <Field
                                            //name="BuildingName" 
                                            name="AddressLine1"
                                            component={Common.renderInput}
                                            type="text"
                                            id="AddressLine1"
                                            className="form-control hsmall"
                                            normalize={normalizeMaxLength(30)}

                                        />
                                        <label>Address 2 </label>
                                        <Field 
                                            name="AddressLine2"
                                            component={Common.renderInput}
                                            type="text"
                                            id="AddressLine2"
                                            className="form-control hsmall"
                                            normalize={normalizeMaxLength(30)}
                                        />

                                    </div>
                                  
                                   

                                <div className="row m-0">
                                         <div className="col-md-6">
                                            <div className="form-group ">
                                                <label>City Name</label>
                                                <Field name="CityName" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'CityName')} id="CityName" className="form-control hsmall" normalize={normalizeMaxLength(40)} />
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label>Postal Code</label>
                                                <Field name="PostalCode" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'PostalCode')} id="PostalCode" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(20)} />
                                            </div>
                                        </div>
                                 </div>

                                        <div className="form-group">
                                            <label>Country</label>
                                            <Field name="Country" component={Common.renderSelect} type="select" onBlur={this.props.handleChange.bind(this, 'ParentCompany')} id="ParentCompany" options={this.state.country_list} className="form-control hsmall" />
                                        </div>
                                    
                                <div className="row m-0">        
                                <div className="col-md-6">
                                    <div className="form-group ">
                                    <label for="gm">IsCompliant</label>
                                        <div class="checkbox-tick">
                                            
                                            <input name="IsCompliant" id="IsCompliant" type="checkbox" value="false" />
                                        </div>
                                    </div>
                                    </div>
                                    <div className="col-md-6">
                                    <div className="form-group ">
                                        <label>% Compliant</label>
                                        <Field name="CompliantPercentage" component={Common.renderInput} type="text" id="CompliantPercentage" className="form-control hsmall" normalize={normalizeNumber} />
                                    </div>
                                    </div>
                                </div>

                                <div className="row m-0">        
                                    <div className="col-md-6">
                                     <div className="form-group ">
                                        <label for="gm">cancel</label>
                                            
                                        </div>
                                        </div>
                                        <div className="col-md-6">
                                        <div className="form-group ">
                                        <span className="btn btn-primary btn-flat save-btn" 
                                           type="submit"
                                           id="user_save_option" 
                                           value="Save"
                                          >
                                            Create company
                                        </span>
                                        
                                        </div>
                                 </div>
                                </div>


                                </div>
                            </div>
                        </div>


                    </div>

                    <br />

                    {/* <div className="row hide">
                        <div className="col-xs-12 col-sm-9 col-md-9">
                            <div className="pdform_column">
                                <div className="pdform-body">
                                    <div className="user-info-details">
                                        <Table
                                            {...this.props}
                                            user_type={this.props.user_type}
                                            column={tableColumn}
                                            name="quality_control"
                                            classname="table table-hover"
                                        />
                                         <button 
                                              class="btn btn-primary btn-block" 
                                              type="submit"
                                              id="user_save_option" 
                                              value="Save"
                                              
                                              ><b>
                                               Save
                                        </b></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                     
                    </div> */}
                </div>
          
        );
    }
}


export default InsertCompanyDetails;

