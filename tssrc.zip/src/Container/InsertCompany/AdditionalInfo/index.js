import React, { Component } from 'react';
import { Tabs, Tab} from 'react-bootstrap';
import { Field } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';

import { normalizeMaxLength, normalizeNumber, validateEmail, normalizeNumberAndSetLimit } from '../../../Validations';

class AdditionalInfo extends Component {

	constructor(props) {
        super(props);
        this.nextTab = this.nextTab.bind(this);
        this.state = {
            tabkey: 3,
        }
    }
    
    nextTab() {
     
          this.props.onChange(this.state.tabkey+1,"AdditionalInfo");
  
      }

	render() {
		return (
			<div className="cunitform">
                <div className="row">

                    <div className="col-xs-12 col-sm-5 col-md-5">
						<div className="pdform_column second_coumn">
                            <h5><strong>BEE Compliance</strong></h5>
                            <div className="form-group ">
                                <label>Is Compliant</label>
								<Field name="IsCompliant" component={Common.renderInput} type="text" id="IsCompliant" className="form-control hsmall" normalize={normalizeNumber}/>
                            </div>

							<div className="form-group ">
                                <label>% Compliant</label>
                                <Field name="CompliantPercentage" component={Common.renderInput} type="text" id="CompliantPercentage" className="form-control hsmall"  normalize={normalizeNumber} />
                            </div>

                            <div className="form-group ">
                                <label>Contact Name</label>
                                <Field name="AdditionalContactName" component={Common.renderInput} type="text" id="AdditionalContactName" className="form-control hsmall"  normalize={normalizeMaxLength(100)} />
                            </div>

                            <div className="form-group ">
                                <label>Contact Email</label>
                                <Field name="AdditionalContactEmail" component={Common.renderInput} type="email" id="Contac Email" className="form-control hsmall"  normalize={normalizeMaxLength(100)}/>
                            </div>

                            <div className="form-group">
                                <label>Contact Tel</label>
                                <Field name="AdditionalContactTel" component={Common.renderInput} type="text" id="ContactTel" className="form-control hsmall"  normalize={normalizeNumberAndSetLimit(15)}/>
                            </div>
                        </div>
                    </div>
					
					

                     <div className="col-xs-12 col-sm-5 col-md-5">
                        <div className="pdform_column first_coumn">
                            <h5><strong>Account Information</strong></h5>

							<div className="form-group">
								<div className="inline-checkbox tick">
									<Field name="ApplyVat" id="ApplyVat" component="input" type="checkbox" value="1" />
									<label htmlFor="ApplyVat">Apply VAT?</label>
								</div>
                            </div>

							<div className="form-group ">
                                <label>Account Balance</label>
                                <label className="AccountBalance"> 0.00</label>
                            </div>

						</div>
                    </div>					
                   
					<div className="col-xs-12 col-sm-2 col-md-2">
                        <div className="saveform">
                            <div className="next_btn">
                                <Button type="button" onClick={this.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
					 

				</div>
			</div>
		);
	}
}

export default AdditionalInfo;