import React, { Component } from 'react';
import { Tabs, Tab} from 'react-bootstrap';
import { reduxForm, change, Field } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';
import Select from 'react-select';
import { connect } from 'react-redux';
import {normalizeMaxLength, normalizeNumberAndSetLimit } from '../../../Validations';



class AddressInfo extends Component {

	constructor(props) {
        super(props);
        this.nextTab = this.nextTab.bind(this);
        this.handleChange = this.handleChange.bind(this);
        
        this.state = {
            tabkey: 2,
            select_options: [
                {label: 'test', value: 'test'},
                {label: 'test', value: 'test'},
                {label: 'test', value: 'test'},
                {label: 'test', value: 'test'},
                {label: 'test', value: 'test'},
            ],
            country_list: [
                {label: 'South Africa', value: '1'},
            ],
            checkBoxSelected: true
        }
    }


    handleSelect(tabkey) {
		this.setState({ tabkey });
	}
    
    nextTab() {
       // this.setState({ tabkey: this.state.tabkey+1});
        // console.log(this.state.tabkey)
        this.props.onChange(this.state.tabkey+1,"AddressInfo");

    }
    handleChange(e){
        
        this.setState({checkBoxSelected: !this.state.checkBoxSelected})

        

        if(this.state.checkBoxSelected ){
            
            this.props.dispatch(change('CompanyForm', 'PostalPoBox', this.props.StreetNumberName));
            this.props.dispatch(change('CompanyForm', 'PostalSubrubName',this.props.SubrubName));
            this.props.dispatch(change('CompanyForm', 'PostalCityName', this.props.CityName));
            this.props.dispatch(change('CompanyForm', 'PostalPostalCode', this.props.PostalCode));
            this.props.dispatch(change('CompanyForm', 'PostalCountry', this.props.ParentCompany));
            this.props.dispatch(change('CompanyForm', 'PostalProvince', this.props.Province));
        } else{

            this.props.dispatch(change('CompanyForm', 'PostalPoBox', ''));
            this.props.dispatch(change('CompanyForm', 'PostalSubrubName',''));
            this.props.dispatch(change('CompanyForm', 'PostalCityName', ''));
            this.props.dispatch(change('CompanyForm', 'PostalPostalCode', ''));
            this.props.dispatch(change('CompanyForm', 'PostalCountry', ''));
            this.props.dispatch(change('CompanyForm', 'PostalProvince', ''  ));

        }

    }

	render() {
		return (
			<div className="cunitform">
                <div className="row">
                    <div className="col-xs-12 col-sm-5 col-md-5">
                        <div className="pdform_column first_coumn">
                            <h5><strong>Physical Address</strong></h5>
							<div className="form-group ">
                                <label>Building/Block/Section Name</label>
                                <Field name="BuildingName" component={Common.renderInput} type="text" id="address_info[BuildingName]"
                                 className="form-control hsmall"
                                 normalize = {normalizeMaxLength(30)}
                                  />
      
                            </div>
							<div className="form-group ">
                                <label>Street Number & Name</label>
                                <Field name="StreetNumberName" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'StreetNumberName')}  id="StreetNumberName" className="form-control hsmall" normalize = {normalizeMaxLength(40)} />
                            </div>

							<div className="form-group ">
                                <label>Subrub Name</label>
								<Field name="SubrubName" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'SubrubName')} id="SubrubName" className="form-control hsmall" onBlur={this.props.handleChange.bind(this, 'SubrubName')} normalize= {normalizeMaxLength(40)}/>
                            </div>

							<div className="form-group ">
                                <label>City Name</label>
                                <Field name="CityName" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'CityName')} id="CityName" className="form-control hsmall" normalize = {normalizeMaxLength(40)}/>
                            </div>

                            <div className="form-group ">
                                <label>Postal Code</label>
                                <Field name="PostalCode" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'PostalCode')} id="PostalCode" className="form-control hsmall" normalize = {normalizeNumberAndSetLimit(20)}/>
                            </div>

                            <div className="form-group ">
                                <label>Country</label>                                
                                <Field name="Country" component={Common.renderSelect} type="select" onBlur={this.props.handleChange.bind(this, 'ParentCompany')} id="ParentCompany" options={this.state.country_list} className="form-control hsmall" />
                            </div>

                            <div className="form-group ">
                                <label>Province</label>
                                <Field name="Province" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'Province')}  id="Province" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(20)}/>
                            </div>	

							

						</div>
                    </div>

					
					<div className="col-xs-12 col-sm-5 col-md-5">
						<div className="pdform_column second_coumn">
                            <h5><strong>Postal Address</strong></h5>
                            <div className="form-group">
								<div className="inline-checkbox tick">
									<Field name="SameAsPhysical" id="SameAsPhysical" onClick={this.handleChange } component="input" type="checkbox" value="1" />
									<label htmlFor="gm">Same As Physical</label>
								</div>
                            </div>

							<div className="form-group ">
                                <label>(PO. Box / Private Bag)</label>
                                <Field name="PostalPoBox"  component={Common.renderInput} type="text" id="PostalPoBox" className="form-control hsmall" normalize={normalizeMaxLength(40)}/>
                            </div>

							<div className="form-group ">
                                <label>Subrub Name</label>
                                <Field name="PostalSubrubName" component={Common.renderInput} type="text"  id="PostalSubrubName" className="form-control hsmall" normalize= {normalizeMaxLength(40)} />
                            </div>


							<div className="form-group ">
                                <label>City Name</label>
                                <Field name="PostalCityName" component={Common.renderInput} type="text"  id="PostalCityName" className="form-control hsmall"  normalize = {normalizeMaxLength(40)}/>
                            </div>
                            
                            <div className="form-group ">
                                <label>Postal Code</label>
                                <Field name="PostalPostalCode" component={Common.renderInput} type="text"  id="PostalPostalCode" className="form-control hsmall" normalize = {normalizeNumberAndSetLimit(20)}/>
                            </div>

                            <div className="form-group ">
                                <label>Country</label>
                                <Field name="PostalCountry" component={Common.renderSelect} type="select" id="ParentCompany" options={this.state.country_list} className="form-control hsmall" />
                            </div>

                            <div className="form-group ">
                                <label>Province</label>
                                <Field name="PostalProvince" component={Common.renderInput} type="text" id="PostalProvince" className="form-control hsmall"  normalize={normalizeNumberAndSetLimit(20)}/>
                            </div>	
						
						</div>
					</div>
                    
					<div className="col-xs-12 col-sm-2 col-md-2">
                        <div className="saveform move_bottom">
                            
                            <div className="next_btn">
                                <Button type="button" onClick={this.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>

				</div>
			</div>
		);
	}
}

// const Form= reduxForm({
// })(AddressInfo);


const mapStateToProps = (state) => {

    return {
       state
    }
  }


// export default connect (mapDispatchToProps)(Form);

export default connect(state => ({ 
    initialValues: {
        PostalPoBox: 'hello address'
    } 
  }), mapStateToProps)(AddressInfo);