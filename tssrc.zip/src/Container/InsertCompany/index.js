import React, { Component } from 'react';
import Config from '../../Config';
import {Provider, connect} from 'react-redux';

import InsertForm from './InsertCompany';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';


const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    token:state.auth.token,
    user_type:state.auth.user_type, 
    insertcode:state.insertcompany.insertcode
})

 
const mapDispatchToProps = (dispatch) => ({
    InsertCompany: (values) => dispatch(ActionCreators.InsertCompany(values)),
    CompanyTypeList:() => dispatch(ActionCreators.CompanyTypeList()),
    insertCodeOff: (values) => dispatch(ActionCreators.insertCodeOff(values))
})
  


const InsertCompanyComponent  = connect(mapStateToProps, mapDispatchToProps)(InsertForm);


class InsertCompany extends Component {

    componentDidMount(){
        document.title=Config.name+' Insert Company';
        
    }
    render(){
        return  <Provider store={AppStore}><InsertCompanyComponent/></Provider>
    }
}

export default InsertCompany;


