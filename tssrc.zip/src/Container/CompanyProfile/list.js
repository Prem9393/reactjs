import React, { Component } from 'react';
import { Field } from 'redux-form';
import ListView from './ListView';
import Loader from '../../Components/Loader';


class CompanyList extends Component {
    constructor(props) {
        super(props)
        this.state ={
            isLoading: true
        }
    }

    componentDidMount() {
        this.props.CompanyListing();        
    }

    componentWillReceiveProps(nextProps) {
        console.log('componentWillReceiveProps company', nextProps);
        if(nextProps.companylistingmessage !==''){
             this.setState({isLoading:false});
         }
    }
      
    render(){

        return (
            <div className="container-fluid">
                <Loader showloader={this.state.isLoading}/>
                <div className="row no-gutter">
                    <div className="col-sm-12 col-xs-12">
                        <div className="setp_2maintable custom"> 
                            <div className="table-responsive company_listing custom_table">                           
                                <ListView  {...this.props } />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default CompanyList;