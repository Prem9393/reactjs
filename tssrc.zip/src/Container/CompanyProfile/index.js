import React, { Component } from 'react';
import Config from '../../Config';
import { Provider, connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import './companyprofile.css';

import ListingMain from './list';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators'

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    user_company_id : state.auth.user_company_id,
    userLanguage :state.auth.userLanguage != '' ? state.auth.userLanguage : 'EN',
    companylisting:state.companylist.companylisting,
    companylistingmessage:state.companylist.companylistingmessage, 
    updatecompany: state.updatecompany,
    insertcompany: state.insertcompany
})


const mapDispatchToProps = (dispatch) => ({
    CompanyListing: (values) => dispatch(ActionCreators.CompanyListing(values)),
    DeleteCompany: (values) => dispatch(ActionCreators.DeleteCompany(values)),
    updateCodeOff: (values) => dispatch(ActionCreators.updateCodeOff(values)),
    insertCodeOff:(values) => dispatch(ActionCreators.insertCodeOff(values))

})

const CompanyListComponent = connect(mapStateToProps, mapDispatchToProps)(ListingMain);

class CompanyProfile extends Component {

    componentDidMount() {
        document.title = Config.name + ' Company Profile ';
    }
    render() {
        return <Provider store={AppStore}><CompanyListComponent {...this.props} /></Provider>
    }
}

export default reduxForm({
    form: 'CompanyFilters',
})(CompanyProfile);


