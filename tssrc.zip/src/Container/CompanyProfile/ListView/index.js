import React, { Component } from 'react';
import ActionCreators from '../../../Actions/ActionCreators';
import Table from '../../../Components/Table/table';
import TablePagination from '../../../Components/TablePagination';
import Config from '../../../Config';

import { Redirect } from 'react-router-dom';


    const tableColumn = [       
        {key: 'CompanyLogo', label: 'Company Name', isSort: true},
        {key: 'CompanyName', label: '', isSort: true, type: 'callback', callback_function: 'CompanyEditLink' },
        {key: 'CompanyGLN', label: 'Company GLN', isSort: true},
        {key: 'CompanyType', label: 'Users', isSort: true},
        {key: 'ContactName', label: 'Contact Name', isSort: true},
        {key: 'ContactEmail', label: 'Contact Email', isSort: true},
        {key: 'Edit', label: '', isSort: true, type:"EditBtn",  callback_function: 'CompanyEditBtnLink'}
    ];

    // {key: 'ContactName', label: 'Contact Name', isSort: true},
    // {key: 'ContactEmail', label: 'Contact Email', isSort: true},
    // {key: 'ContactTel', label: 'Contact Tel', isSort: true},
    // {key: 'ContactFax', label: 'Contact Fax', isSort: true},
    
class ListView extends Component {
constructor(props){
 super(props);

 this.state= {
    pageOfItems: [],
    search:'',
    filteredCompanyList:[],
    pageSize:10
 }

 this.handlechange= this.handlechange.bind(this);
 this.onChangePage = this.onChangePage.bind(this);
 this.DeleteCompany = this.DeleteCompany.bind(this);
}

handlechange(e){
    let searchValue =e.target.value;

    this.setState({
        search: searchValue.toString().substr(0,20),
      })

let filteredCompanyList = this.props.companylisting.filter((company) => { 
  return ( company.CompanyName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1 ||
  company.CompanyGLN.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1 )
    })

    this.setState({ filteredCompanyList})
}


onChangePage(pageOfItems){
   this.setState({ pageOfItems: pageOfItems});
}


componentWillUnmount(){
    
    this.props.dispatch(ActionCreators.updateCodeOff(0))
    this.props.dispatch(ActionCreators.insertCodeOff(0))
}

DeleteCompany(field) {
   
    console.log(field);
    this.props.DeleteCompany( field )

}

    
    render() {
        
        if(this.props.user_company_id && this.props.user_type != 3 && this.props.user_company_id && this.props.user_type != 4 ) {
            return <Redirect to={Config.userPath[this.props.user_type] + 'editcompany/'+ this.props.user_company_id} /> 
        }
               
        
        return (

             <div className="company-profile">
                <div className="top_search">
                <input type="text" id="search_companyname" className="form-control" name="search_companyname" onChange={this.handlechange} placeholder="Search Company Name / Company GLN" />
               </div>
               {/* <div className="button-group">
                <a className="btn btn-primary btn-flat" href={Config.baseUrl+Config.userPath[this.props.user_type]+'insertcompany'}>Add New</a>
               </div> */}
                   {
                      this.props.insertcompany.insertcode ==1 ?
                         <div class="alert alert-success" role="alert">
                           Company Inserted successfully...!
                        </div>: ""
                    }
               
                    {
                      this.props.updatecompany.updatecode ==1 ?
                         <div class="alert alert-success" role="alert">
                           Company updated successfully...!
                        </div>: ""
                    }

                <section className="content">
                    <div className="box">
                        <div class="box-header"><h3 class="box-title">Company</h3>
                        <div class="box-tools">
                            <a className="btn btn-primary btn-flat" href={Config.baseUrl+Config.userPath[this.props.user_type]+'insertcompany'}>Add New</a>
                        </div>
                        </div>
                        <div className="box-body table-responsive no-padding"> 
                            <Table {...this.props} {...this.state} DeleteCompany={this.DeleteCompany} user_type={this.props.user_type} column={tableColumn} rows={this.state.pageOfItems } name="company_profile" classname="table table-hover company-profile"/> 
                        </div>
                    </div>
                </section> 
                 <TablePagination  pageSize={this.state.pageSize} items={this.state.search ==="" ? this.props.companylisting : this.state.filteredCompanyList }  onChangePage={this.onChangePage} />
            </div>
        )
    }
}

export default ListView;





// "table table-bordered table-striped table-hover"