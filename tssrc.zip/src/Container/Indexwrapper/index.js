import React, {Component, Fragment} from 'react';
import {Grid, Row } from 'react-bootstrap'; 
import LoginImage from './desk.jpg';
import LoginHeader from '../../Components/LoginHeader'
import {Redirect}  from 'react-router-dom';
import Config from '../../Config';
import { connect } from 'react-redux';


class Indexwrapper extends Component{
    
    constructor(props){ 
        super(props);
        console.log("index props",this.props)
        this.state = {
            message: '',
            auth:this.props.auth,
            user_type:this.props.user_type,
            user_company_id:this.props.user_company_id,
            userLanguage : this.props.userLanguage != '' ? this.props.userLanguage : 'EN',
            user_id:this.props.user_id,
              is_view:this.props.is_view,
              is_modify:this.props.is_modify,
              is_user_view:this.props.is_user_view,
              is_user_modify:this.props.is_user_modify,
              is_product_view:this.props.is_product_view,
              is_product_edit:this.props.is_product_edit,
              is_product_upload:this.props.is_product_upload,
      };

      
    }

    static getDerivedStateFromProps(props){
       console.log("index props",props)
       return { 
           message : props.message,
           user_type:props.user_type,
           user_company_id: props.user_company_id,
           userLanguage : props.userLanguage != '' ? props.userLanguage : 'EN',
           user_id: props.user_id,
           auth:props.auth,
           is_view:props.is_view,
          is_modify:props.is_modify,
          is_user_view:props.is_user_view,
          is_user_modify:props.is_user_modify,
          is_product_view:props.is_product_view,
          is_product_edit:props.is_product_edit,
          is_product_upload:props.is_product_upload,
      };
    }

    componentDidMount(){
        
    }

    render(){
        if(this.state.auth===true){
            
            if(this.props.user_type === Config.userTypes.Supplier){
                return <Redirect to="/supplier/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.Retailer){
                return <Redirect to="/retailer/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TrustedSource){
                return <Redirect to="/trustedsource/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TSSupplier){
                return <Redirect to="/tssupplier/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TSRetailer){
                return <Redirect to="/tsretailer/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TSDataPublisher){
                return <Redirect to="/tsdatapublisher/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TSDataRecipient){
                return <Redirect to="/tsdatarecipient/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.TSVendor){
                return <Redirect to="/tsvendor/dashboard" />
            }
            else if(this.props.user_type === Config.userTypes.GS1User){
                // window.location = 'https://trustedsourcepilot.azurewebsites.net/dashboard/index.html'
                // window.location = 'http://172.16.14.175:81/ts/dashboard/index.html'
                return <Redirect to="/gs1/dashboard" />
            }
            else{
                return false;
            }
        }else{
            let notfound = [];
            notfound = this.props.children.map((list,key) => {
                if(list.props.path === this.props.location.pathname){
                    return 'found';
                }else{
                    return 'notfound';
                }
            });
            if(notfound.indexOf('found') === -1){
                return <Redirect to="/" />
            }
        }
        return <Fragment>
                    <LoginHeader/>
                    <Grid fluid={true}>
                        <Row>
                        <div className="col-xs-12 col-sm-4 pull-right">
                                <div className="login-wrapperright">
                                    <div className="login_form">                                         
                                            {this.props.children}                                          
                                    </div>
                                </div>
                            </div>
                            <div className="col-xs-12 col-sm-8">
                                <div className="login-wrapperleft">
                                    <div className="login_wrpcontent text-center">
                                            <h3>TrustedSource is a cloud based digital product content portal, providing verified data and digital assets to serve the connected world.</h3>
                                            <img src={LoginImage} alt="Desktop" />
                                    </div>
                                </div>
                            </div>
                        </Row>
                    </Grid>
              </Fragment>;
    }
}




export default Indexwrapper;



