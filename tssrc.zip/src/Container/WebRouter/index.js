import React,{Component} from 'react';
import {HashRouter as Router, Route, Switch}  from 'react-router-dom';
import Login from '../Login'
import Register from '../Register'
import Indexwrapper from '../Indexwrapper';
import AdminDashboard from '../AdminDashboard';
import Dashboard from '../Dashboard';
import Gs1Dashboard from '../Gs1Dashboard';
import SupplierDashboard from '../SupplierDashboard';
import InsertProduct from '../InsertProduct';
import ProductBrowser from '../ProductBrowser';
import CompanyProfile from '../CompanyProfile';
import InsertCompany from '../InsertCompany';
import PrefixManagement from '../PrefixManagement';
import InsertPrefix from '../InsertPrefix';
import UserManagement from '../UserManagement';
import InsertUser from '../InsertUser';
import EditUser from '../EditUser';
import UploadExcel from '../Upload/UploadExcel';
import UploadAsset from '../Upload/UploadAsset';
import UploadXML from '../Upload/UploadXML';
import UploadDataNetXML from '../Upload/UploadDataNetXML';
import ForgetPassword from '../ForgetPassword';
import ResetPassword from '../ResetPassword';
import Config from '../../Config';
import EditProduct from '../EditProduct';
import EditCompany from '../EditCompany';
import QualityControl from '../QualityControl';
import AutoQc from '../AutoQc';
import ManualQc from '../ManualQc';
import EditAutoQc from '../EditAutoQc';



class WebRouter extends Component{
	constructor(props) {
		super(props);
		this.state = {
			 username: this.props.name ,
			 userimage: Config.assetspath+this.props.image, 
			 user_type: this.props.user_type, 
			 user_company_id: this.props.user_company_id,
			 information_provider_gln : this.props.information_provider_gln,
			 is_view:this.props.IsView,
			 is_modify:this.props.IsModify,
			 is_user_view:this.props.IsUserView,
			 is_user_modify:this.props.IsUserModify,
			 is_product_view:this.props.IsProductView,
			 is_product_edit:this.props.IsProductEdit,
			 is_product_upload:this.props.IsProductUpload,
			 userLanguage : this.props.userLanguage ? this.props.userLanguage : 'EN',
		};

	}

	static getDerivedStateFromProps(props){
		return { 
			username : props.name,
			userimage: Config.assetspath+props.image, 
			user_type: props.user_type, 
			user_company_id: props.user_company_id, 
			information_provider_gln : props.information_provider_gln,
			is_view:props.IsView,
			is_modify:props.IsModify,
			is_user_view:props.IsUserView,
			is_user_modify:props.IsUserModify,
			is_product_view:props.IsProductView,
			is_product_edit:props.IsProductEdit,
			is_product_upload:props.IsProductUpload,
			userLanguage : props.userLanguage ? props.userLanguage : 'EN',
		};
    }


	render(){

		return <Router>
					<Switch>
					{(this.props.auth) ? (this.props.user_type === Config.userTypes.Retailer
						? <AdminDashboard menu={Config.retailermenu} {...this.props} {...Config} userdetails={this.state} path="/retailer">
						<Route exact path="/retailer"  component={Dashboard} />
						<Route  path="/retailer/dashboard" component={Dashboard}/>
						{/* <Route path="/retailer/productbrowser"   component={ProductBrowser} /> */}
						<Route path="/retailer/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/retailer/editproduct/:gtin"   component={EditProduct} />
						<Route path="/retailer/usermanagement"   component={UserManagement} />
						<Route path="/retailer/insertuser"   component={InsertUser} />
						<Route path="/retailer/edituser/:id"   component={EditUser} />
						<Route path="/retailer/editcompany/:id"   component={EditCompany} />	
						<Route path="/retailer/companyprofile"   component={CompanyProfile} />
						
					</AdminDashboard> : 
					((this.props.user_type === Config.userTypes.Supplier) ?  
					<AdminDashboard menu={Config.suppliermenu} {...this.props} {...Config} userdetails={this.state} path="/supplier">
						<Route exact path="/supplier"  component={Dashboard} />
						<Route  path="/supplier/dashboard" component={SupplierDashboard}/>
						<Route path="/supplier/insertproduct"   component={InsertProduct} />
						{/* <Route path="/supplier/productbrowser"   component={ProductBrowser} /> */}
						<Route path="/supplier/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/supplier/editproduct/:gtin"   component={EditProduct} />
						<Route path="/supplier/importexcelfile"  component={UploadExcel} />
						<Route path="/supplier/assetview"  component={UploadAsset} />
						<Route path="/supplier/xmldata"  component={UploadXML} />
						<Route path="/supplier/datanetxml"  component={UploadDataNetXML} />
						<Route path="/supplier/usermanagement"   component={UserManagement} />
						<Route path="/supplier/insertuser"   component={InsertUser} />
						<Route path="/supplier/edituser/:id"   component={EditUser} />
						<Route path="/supplier/companyprofile"   component={CompanyProfile} />
						<Route path="/supplier/editcompany/:id"   component={EditCompany} />						
					</AdminDashboard>
					: 
					((this.props.user_type === Config.userTypes.TrustedSource) ?  
					<AdminDashboard menu={Config.tsadminmenu} {...this.props} {...Config} userdetails={this.state} path="/trustedsource">
						<Route exact path="/trustedsource"  component={Dashboard} />
						<Route path="/trustedsource/dashboard" component={Dashboard}/>
						<Route path="/trustedsource/insertproduct"   component={InsertProduct} />
						<Route path="/trustedsource/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/trustedsource/editproduct/:gtin"   component={EditProduct} />
						<Route path="/trustedsource/importexcelfile"  component={UploadExcel} />
						<Route path="/trustedsource/assetview"  component={UploadAsset} />
						<Route path="/trustedsource/xmldata"  component={UploadXML} />
						<Route path="/trustedsource/datanetxml"  component={UploadDataNetXML} />
						<Route path="/trustedsource/usermanagement"   component={UserManagement} />
						<Route path="/trustedsource/insertuser"   component={InsertUser} />
						<Route path="/trustedsource/edituser/:id"   component={EditUser} />
						<Route path="/trustedsource/companyprofile"   component={CompanyProfile} />
						<Route path="/trustedsource/insertcompany"   component={InsertCompany} />
						<Route path="/trustedsource/editcompany/:id"   component={EditCompany} />
						<Route path="/trustedsource/insertprefix"   component={InsertPrefix} />						
					</AdminDashboard>
					: 
					((this.props.user_type === Config.userTypes.TSSupplier) ?  
					<AdminDashboard menu={Config.tssuppliermenu} {...this.props} {...Config} userdetails={this.state} path="/tssupplier">
						<Route exact path="/tssupplier"  component={Dashboard} />
						<Route path="/tssupplier/dashboard" component={SupplierDashboard}/>
						<Route path="/tssupplier/insertproduct"   component={InsertProduct} />
						<Route path="/tssupplier/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/tssupplier/editproduct/:gtin"   component={EditProduct} />
						<Route path="/tssupplier/importexcelfile"  component={UploadExcel} />
						<Route path="/tssupplier/assetview"  component={UploadAsset} />
						<Route path="/tssupplier/xmldata"  component={UploadXML} />
						<Route path="/tssupplier/datanetxml"  component={UploadDataNetXML} />
						<Route path="/tssupplier/usermanagement"   component={UserManagement} />
						<Route path="/tssupplier/insertuser"   component={InsertUser} />
						<Route path="/tssupplier/edituser/:id"   component={EditUser} />
						<Route path="/tssupplier/companyprofile"   component={CompanyProfile} />
						<Route path="/tssupplier/insertcompany"   component={InsertCompany} />
						<Route path="/tssupplier/editcompany/:id"   component={EditCompany} />
						<Route path="/tssupplier/insertprefix"   component={InsertPrefix} />	
					</AdminDashboard>

					: 
					((this.props.user_type === Config.userTypes.TSRetailer) ?  
					<AdminDashboard menu={Config.tsretailermenu} {...this.props} {...Config} userdetails={this.state} path="/tsretailer">
						<Route exact path="/tsretailer"  component={Dashboard} />
						<Route path="/tsretailer/dashboard" component={Dashboard}/>
						<Route path="/tsretailer/insertproduct"   component={InsertProduct} />
						<Route path="/tsretailer/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/tsretailer/editproduct/:gtin"   component={EditProduct} />
						<Route path="/tsretailer/importexcelfile"  component={UploadExcel} />
						<Route path="/tsretailer/assetview"  component={UploadAsset} />
						<Route path="/tsretailer/xmldata"  component={UploadXML} />
						<Route path="/tsretailer/datanetxml"  component={UploadDataNetXML} />
						<Route path="/tsretailer/usermanagement"   component={UserManagement} />
						<Route path="/tsretailer/insertuser"   component={InsertUser} />
						<Route path="/tsretailer/edituser/:id"   component={EditUser} />
						<Route path="/tsretailer/companyprofile"   component={CompanyProfile} />
						<Route path="/tsretailer/insertcompany"   component={InsertCompany} />
						<Route path="/tsretailer/editcompany/:id"   component={EditCompany} />
						<Route path="/tsretailer/insertprefix"   component={InsertPrefix} />
					</AdminDashboard>
					: 
					(this.props.user_type === Config.userTypes.TSDataPublisher) ?  
					<AdminDashboard menu={Config.TSDataPublishermenu} {...this.props} {...Config} userdetails={this.state} path="/tsdatapublisher">
						<Route exact path="/tsdatapublisher"  component={Dashboard} />
						<Route path="/tsdatapublisher/dashboard" component={Dashboard}/>
						<Route path="/tsdatapublisher/insertproduct"   component={InsertProduct} />
						<Route path="/tsdatapublisher/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/tsdatapublisher/editproduct/:gtin"   component={EditProduct} />
						<Route path="/tsdatapublisher/importexcelfile"  component={UploadExcel} />
						<Route path="/tsdatapublisher/assetview"  component={UploadAsset} />
						<Route path="/tsdatapublisher/xmldata"  component={UploadXML} />
						<Route path="/tsdatapublisher/datanetxml"  component={UploadDataNetXML} />
						<Route path="/tsdatapublisher/usermanagement"   component={UserManagement} />
						<Route path="/tsdatapublisher/insertuser"   component={InsertUser} />
						<Route path="/tsdatapublisher/edituser/:id"   component={EditUser} />
						<Route path="/tsdatapublisher/companyprofile"   component={CompanyProfile} />
						<Route path="/tsdatapublisher/insertcompany"   component={InsertCompany} />
						<Route path="/tsdatapublisher/editcompany/:id"   component={EditCompany} />
						<Route path="/tsdatapublisher/insertprefix"   component={InsertPrefix} />
					</AdminDashboard>
					: 
					(this.props.user_type === Config.userTypes.TSDataRecipient) ?  
					<AdminDashboard menu={Config.TSDataRecipientmenu} {...this.props} {...Config} userdetails={this.state} path="/tsdatarecipient">
						<Route exact path="/tsdatarecipient"  component={Dashboard} />
						<Route path="/tsdatarecipient/dashboard" component={Dashboard}/>
						<Route path="/tsdatarecipient/insertproduct"   component={InsertProduct} />
						<Route path="/tsdatarecipient/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/tsdatarecipient/editproduct/:gtin"   component={EditProduct} />
						<Route path="/tsdatarecipient/importexcelfile"  component={UploadExcel} />
						<Route path="/tsdatarecipient/assetview"  component={UploadAsset} />
						<Route path="/tsdatarecipient/xmldata"  component={UploadXML} />
						<Route path="/tsdatarecipient/datanetxml"  component={UploadDataNetXML} />
						<Route path="/tsdatarecipient/usermanagement"   component={UserManagement} />
						<Route path="/tsdatarecipient/insertuser"   component={InsertUser} />
						<Route path="/tsdatarecipient/edituser/:id"   component={EditUser} />
						<Route path="/tsdatarecipient/companyprofile"   component={CompanyProfile} />
						<Route path="/tsdatarecipient/insertcompany"   component={InsertCompany} />
						<Route path="/tsdatarecipient/editcompany/:id"   component={EditCompany} />
						<Route path="/tsdatarecipient/insertprefix"   component={InsertPrefix} />
					</AdminDashboard>
					: 
					(this.props.user_type === Config.userTypes.TSVendor) ?  
					<AdminDashboard menu={Config.TSVendormenu} {...this.props} {...Config} userdetails={this.state} path="/tsvendor">
						<Route exact path="/tsvendor"  component={Dashboard} />
						<Route path="/tsvendor/dashboard" component={Dashboard}/>
						<Route path="/tsvendor/insertproduct"   component={InsertProduct} />
						<Route path="/tsvendor/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/tsvendor/editproduct/:gtin"   component={EditProduct} />
						<Route path="/tsvendor/importexcelfile"  component={UploadExcel} />
						<Route path="/tsvendor/assetview"  component={UploadAsset} />
						<Route path="/tsvendor/xmldata"  component={UploadXML} />
						<Route path="/tsvendor/datanetxml"  component={UploadDataNetXML} />
						<Route path="/tsvendor/usermanagement"   component={UserManagement} />
						<Route path="/tsvendor/insertuser"   component={InsertUser} />
						<Route path="/tsvendor/edituser/:id"   component={EditUser} />
						<Route path="/tsvendor/companyprofile"   component={CompanyProfile} />
						<Route path="/tsvendor/insertcompany"   component={InsertCompany} />
						<Route path="/tsvendor/editcompany/:id"   component={EditCompany} />
						<Route path="/tsvendor/insertprefix"   component={InsertPrefix} />
					</AdminDashboard>
					:				
					<AdminDashboard menu={Config.gs1menu} {...this.props} {...Config} userdetails={this.state} path="/gs1">
					<Route exact path="/gs1"  component={Dashboard} />
					{/* <Route path="/gs1/dashboard"  component={() => 
					     // window.location = 'http://172.16.14.175:81/ts/api/' }
					//	window.location = 'https://trustedsourcepilot.azurewebsites.net/dashboard/index.html'}
						window.location = 'http://172.16.14.175:81/ts/dashboard/index.html'}
						/>
					<Route path="/gs1/userlogout"  component={() => {
						localStorage.removeItem('trustedsource');
					//	window.location = 'https://trustedsourcepilot.azurewebsites.net/dashboard/index.html';
						//window.location = 'http://172.16.14.175:81/ts/api/'
						window.location = 'http://172.16.14.175:81/ts/dashboard/index.html'
					}}/> */}
					{/* <Route path="/gs1/dashboard" component={Gs1Dashboard}/> */}
					{/* <Route path="/gs1/productbrowser"   component={ProductBrowser} />  */}
					{/* <Route path="/gs1/productbrowser/:status?"   component={ProductBrowser} />
					<Route path="/gs1/editproduct/:gtin"   component={EditProduct} />
					<Route path="/gs1/companyprofile"   component={CompanyProfile} />
					<Route path="/gs1/insertcompany"   component={InsertCompany} />
					<Route path="/gs1/editcompany/:id"   component={EditCompany} />
					<Route path="/gs1/insertprefix"   component={InsertPrefix} /> */}

						<Route path="/gs1/dashboard" component={Gs1Dashboard}/>
						<Route path="/gs1/insertproduct"   component={InsertProduct} />
						<Route path="/gs1/productbrowser/:status?"   component={ProductBrowser} />
						<Route path="/gs1/editproduct/:gtin"   component={EditProduct} />
						<Route path="/gs1/importexcelfile"  component={UploadExcel} />
						<Route path="/gs1/assetview"  component={UploadAsset} />
						<Route path="/gs1/xmldata"  component={UploadXML} />
						<Route path="/gs1/datanetxml"  component={UploadDataNetXML} />
						<Route path="/gs1/usermanagement"   component={UserManagement} />
						<Route path="/gs1/insertuser"   component={InsertUser} />
						<Route path="/gs1/edituser/:id"   component={EditUser} />
						<Route path="/gs1/companyprofile"   component={CompanyProfile} />
						<Route path="/gs1/insertcompany"   component={InsertCompany} />
						<Route path="/gs1/editcompany/:id"   component={EditCompany} />
						<Route path="/gs1/insertprefix"   component={InsertPrefix} />
						<Route path="/gs1/qualitycontrol"   component={QualityControl} />
						<Route path="/gs1/autoqc"   component={AutoQc} />
						<Route path="/gs1/manualqc"   component={ManualQc} />
						<Route path="/gs1/editautoqcproduct/:id/:gtin"   component={EditAutoQc} />
					
					
					</AdminDashboard> )
						
					 )
					) ) ): ''}
				
					<Indexwrapper  {...this.props} >
						<Route exact path="/"   render = {(props)=> <Login {...props}  {...this.props}/>} />
						<Route  path="/login"   render = {(props)=> <Login {...props}  {...this.props}/>} />
						<Route  path="/register"   render = {(props)=> <Register {...props}  {...this.props}/>} />
						<Route  path="/reset/:id"   render = {(props)=> <ResetPassword {...props}  {...this.props}/>} />
						<Route  path="/forgetpassword"   render = {(props)=> <ForgetPassword {...props}  {...this.props}/>} />
					</Indexwrapper>
					</Switch>
			  </Router>
	}
}


export default WebRouter;