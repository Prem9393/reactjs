import React,{Component} from 'react';
import {Provider, connect} from 'react-redux';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators'
import Dashbaord from './dashbaord'

const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    user_type:state.auth.user_type,
    user_id:state.auth.user_id,
    user_company_id : state.auth.user_company_id,
    userLanguage : state.auth.userLanguage != '' ? state.auth.userLanguage : 'EN',
      is_view:state.auth.is_view,
      is_modify:state.auth.is_modify,
      is_user_view:state.auth.is_user_view,
      is_user_modify:state.auth.is_user_modify,
      is_product_view:state.auth.is_product_view,
      is_product_edit:state.auth.is_product_edit,
      is_product_upload:state.auth.is_product_upload,
    token:state.auth.token,
    dashboard:state.dashboard.dashboardlisting,
    dahsboardmessage:state.dashboard.dahsboardmessage,
})

const mapDispatchToProps = (dispatch) => ({
    ResetStateMessage: (values) => dispatch(ActionCreators.ResetStateMessage(values)),
    DashbaordListing: (values) => dispatch(ActionCreators.userDashboard(values)),
})

const DashbaordComponent  = connect(mapStateToProps, mapDispatchToProps)(Dashbaord);

class DashbaordHolder extends Component{
  render() {
    return <Provider store={AppStore}><DashbaordComponent/></Provider>
  }
}

export default DashbaordHolder;