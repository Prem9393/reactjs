import React, { Component } from 'react';
import { Tabs, Tab} from 'react-bootstrap';
import ConsumerUnit from './TabView/ConsumerUnit';
import Shrink from './TabView/Shrink';
import Case from './TabView/Case';
import Pallet from './TabView/Pallet';

class BasicData extends Component {

	constructor(props) {
	
		super(props);
		this.handleSelect = this.handleSelect.bind(this);
		this.nextTab = this.nextTab.bind(this);
		this.updategitin = this.updategitin.bind(this);
		this.state = {
			tabkey: 1,
			gtins:[],
			published_executed:false,
		}
	}


	handleSelect(tabkey) {
		this.setState({ tabkey });
		if(this.state.gtins[tabkey-1]){
			this.props.loadPublishData({
				gtin:this.state.gtins[tabkey-1],
				token:this.props.token
			});
		}
	}

	nextTab() {
		this.setState({ tabkey: this.state.tabkey+1});
	}

	updategitin(_gitin){
		let _object_keys = Object.keys(_gitin);
		let gtins = this.state.gtins;
		if(_object_keys==="consumerunit"){
			gtins[0] = (_gitin[_object_keys]) ? _gitin[_object_keys] : 0;
		}
		else if(_object_keys==="shrink"){

			gtins[1] = (_gitin[_object_keys]) ? _gitin[_object_keys] : 0;
		}
		else if(_object_keys==="case"){
			gtins[2] = (_gitin[_object_keys]) ? _gitin[_object_keys] : 0;
		}
		else if(_object_keys==="pallet"){
			gtins[3] = (_gitin[_object_keys]) ? _gitin[_object_keys] : 0;
		}
		else{

		}
		this.setState({gtins})
	}

	componentDidUpdate(){
		if(this.state.gtins[0] && this.state.published_executed===false){
			this.props.loadPublishData({
				gtin:this.state.gtins[0],
				token:this.props.token
			});
			this.props.loadProductTotal({
				gtin:this.state.gtins[0],
				token:this.props.token
			});
			this.setState({published_executed:true})
		}
	}


	render() {
		return (
			<div id="s3_tab1">
				<div className="pdetails_btform">
					<div className="container-fluid">
						<div className="row">
							<div className="col-xs-12 col-sm-12">
								<div className="bdata_cunit">
									<Tabs id="step3_innertab" activeKey={this.state.tabkey} onSelect={this.handleSelect}>
										<Tab eventKey={1} title="Consumer Unit">
											<ConsumerUnit handleSelectCategory={this.handleSelectCategory} {...this.state} {...this.props} nextTab={this.nextTab} updategitin={this.updategitin}/>
										</Tab>
										<Tab eventKey={2} title="Shrink">
											<Shrink {...this.state} {...this.props} nextTab={this.nextTab} updategitin={this.updategitin}/>
										</Tab>
										<Tab eventKey={3} title="Case">
											<Case {...this.state} {...this.props} nextTab={this.nextTab} updategitin={this.updategitin}/>
										</Tab>
										<Tab eventKey={4} title="Pallet">
											<Pallet {...this.state} {...this.props} nextTab={this.nextTab} updategitin={this.updategitin} />
										</Tab>
									</Tabs>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default BasicData;