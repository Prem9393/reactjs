import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Button } from 'react-bootstrap';
import Common from '../../../../Common';
import RenderSelect from '../../../../Components/SelectField';
import Modal from '../../../../Components/Modal';
import Config from '../../../../Config';

import { normalizeMaxLength, normalizeNumberAndSetLimit} from '../../../../Validations';
let PREFIX = 'case_';

export default class Case extends Component {
    constructor(props) {
        super(props);
        this.handleSelectCategory = this.handleSelectCategory.bind(this);
        this.handleSelectSubCategory = this.handleSelectSubCategory.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.updateOptions = this.updateOptions.bind(this);
        this.updateValue = this.updateValue.bind(this);
        this.languageSet = this.languageSet.bind(this);
        this.handleChangeValue =  this.handleChangeValue.bind(this);
        this.state = {
            show_modal: false,
            modal_title: '',
            modal_label: '',
            tabkey: 1,
            modal_for: '',
            modal_value: '',     
            case_NetContent:'',       
            case_languageSpecificBrandName_en: '',
            case_languageSpecificBrandName_nl:'',
            case_languageSpecificBrandName_xu: '',            
            case_Subbrand_en: '',
            case_Subbrand_nl: '',
            case_Subbrand_xu: '',
            case_FunctionalName_en: '',
            case_FunctionalName_nl: '',
            case_FunctionalName_xu: '',
            case_Variant_en: '',
            case_Variant_nl: '',
            case_Variant_xu: '',
            select_dateandpacking: [
                {label: 'Select Package', value: ''},
                {label: 'BAKED_FOR_DATE', value: 'BAKED_FOR_DATE'},
                {label: 'BAKED_ON_DATE', value: 'BAKED_ON_DATE'},
                {label: 'BEST_BEFORE_DATE', value: 'BEST_BEFORE_DATE'},
                {label: 'DISPLAY_UNTIL_DATE', value: 'DISPLAY_UNTIL_DATE'},
                {label: 'EXPIRATION_DATE', value: 'EXPIRATION_DATE'},
                {label: 'FREEZE_BY', value: 'FREEZE_BY'},
                {label: 'LAST_SALE_DATE', value: 'LAST_SALE_DATE'},
                {label: 'NO_DATE_MARKED', value: 'NO_DATE_MARKED3'},
                {label: 'PACKAGING_DATE', value: 'PACKAGING_DATE'},
                {label: 'PRODUCTION_DATE', value: 'PRODUCTION_DATE'},
            ],
            categorylist: this.props.case_categorylist,
            cat_selected: '',
            subcategorylist: this.props.case_subcategorylist,
            subcat_selected: '',
            marketlist: this.props.case_marketlist,
            market_selected: ''
        }
    }
    static getDerivedStateFromProps(props, state) {
        if (props.form_data.hasOwnProperty('case_GTIN') && !state.selections_loaded) {
            if (props.form_data.case_Category !== '') {
                var sub_category_values = {
                    token: props.token,
                    parent_category: props.form_data.case_Category
                }
                props.SubCategoryList(sub_category_values, 'case');
            }
            if (props.form_data.case_subCategory !== '') {
                var market_values = {
                    token: props.token,
                    sub_category_name: props.form_data.case_SubCategory
                }
                props.MarketList(market_values, 'case');
            }

            var select_category = [];
            props.case_categorylist.forEach((category, index) => {
                select_category.push({
                        'label' : category.label.trim(),
                        'value' : category.value.trim(),
                });
            });

            var select_sub_category = [];
            props.case_subcategorylist.forEach((sub_category, index) => {
                select_sub_category.push({
                        'label' : sub_category.label.trim(),
                        'value' : sub_category.value.trim(),
                });
            });

            var grossweightuom = (props.form_data.case_grossWeightUOM  ?  props.form_data.case_grossWeightUOM.trim() : '');
            var case_NetContent = (props.form_data.case_NetContent != null ? props.form_data.case_NetContent.trim() : '' );
            var depthuom = (props.form_data.case_depthUom != null  ?  props.form_data.case_depthUom.trim() : '');
            var widthuom = (props.form_data.case_widthUom  != null  ?  props.form_data.case_widthUom.trim() : '');
            var heightuom = (props.form_data.case_heightUom  != null  ?  props.form_data.case_heightUom.trim() : '');
            var netweightuom = (props.form_data.case_NetWeightUOM  != null  ?  props.form_data.case_NetWeightUOM.trim() : '');
            var packagingweightuom = (props.form_data.case_packagingWeightUOM  != null  ?  props.form_data.case_packagingWeightUOM.trim() : '');

            var packagingweightuom = (props.form_data.case_packagingWeightUOM  != null  ?  props.form_data.case_packagingWeightUOM.trim() : '');
            var category = (props.form_data.case_Category  != null  ?  props.form_data.case_Category.trim() : '');
            var subCategory = (props.form_data.case_SubCategory  != null  ?  props.form_data.case_SubCategory.trim() : '');
            var NetContentUoM =  (props.form_data.case_NetContentUoM != null  ? props.form_data.case_NetContentUoM.trim() : '')

            return {
                selections_loaded: true,
                cat_selected: category,
                subcat_selected: subCategory,
                uom_selected:NetContentUoM,
                country_selected: (props.form_data.case_TargetMarketCountryCode != null  ? props.form_data.case_TargetMarketCountryCode.trim() : ''),
                packingtype_selected: (props.form_data.case_packagingType != null  ? props.form_data.case_packagingType.trim() : ''),
                datepackingtype_selected: (props.form_data.case_TradeItemDateOnPackagingTypeCode != null  ? props.form_data.case_TradeItemDateOnPackagingTypeCode.trim() : ''),
                heightuom_selected: heightuom,
                widthuom_selected: widthuom,
                depthuom_selected: depthuom,
                grossweightuom_selected: grossweightuom,
                packingweight_selected: packagingweightuom,
                weightuom_selected: netweightuom,
                market_selected: props.form_data.case_market_name,
                categorylist: select_category,
                subcategorylist: select_sub_category,
                marketlist: props.case_marketlist,
                case_NetContent: case_NetContent,
                case_languageSpecificBrandName_en:(props.form_data.case_languageSpecificBrandName_en  != null  ?  props.form_data.case_languageSpecificBrandName_en.trim() : ''),
                case_languageSpecificBrandName_nl:(props.form_data.case_languageSpecificBrandName_nl  != null  ?  props.form_data.case_languageSpecificBrandName_nl.trim() : ''), 
                case_languageSpecificBrandName_xu:(props.form_data.case_languageSpecificBrandName_xu   != null ?  props.form_data.case_languageSpecificBrandName_xu.trim() : ''), 
                case_Subbrand_en: (props.form_data.case_Subbrand_en  != null  ?  props.form_data.case_Subbrand_en.trim() : ''),
                case_Subbrand_nl: (props.form_data.case_Subbrand_nl  != null  ?  props.form_data.case_Subbrand_nl.trim() : ''),
                case_Subbrand_xu: (props.form_data.case_Subbrand_xu  != null  ?  props.form_data.case_Subbrand_xu.trim() : ''),
                case_FunctionalName_en: (props.form_data.case_FunctionalName_en  != null  ?  props.form_data.case_FunctionalName_en.trim() : ''),
                case_FunctionalName_nl: (props.form_data.case_FunctionalName_nl  != null  ?  props.form_data.case_FunctionalName_nl.trim() : ''),
                case_FunctionalName_xu: (props.form_data.case_FunctionalName_xu  != null  ?  props.form_data.case_FunctionalName_xu.trim() : ''),
                case_Variant_en:(props.form_data.case_Variant_en  != null  ?  props.form_data.case_Variant_en.trim() : ''),
                case_Variant_nl:(props.form_data.case_Variant_nl  != null  ?  props.form_data.case_Variant_nl.trim() : ''),
                case_Variant_xu:(props.form_data.case_Variant_xu  != null  ?  props.form_data.case_Variant_xu.trim() : '')
            }
        } else {
            var select_category = [];
            props.case_categorylist.forEach((category, index) => {
                select_category.push({
                        'label' : category.label.trim(),
                        'value' : category.value.trim(),
                });
            });
            var select_sub_category = [];
            props.case_subcategorylist.forEach((sub_category, index) => {
                select_sub_category.push({
                        'label' : sub_category.label.trim(),
                        'value' : sub_category.value.trim(),
                });
            });
            return {
                categorylist: select_category,
                subcategorylist: select_sub_category,
                marketlist: props.case_marketlist,
            }
        }
    }

    handleChangeValue(e){
        this.setState({[e.target.id]: e.target.value})
    }

    handleSelectCategory(type, event) {
        let selected_value = '';
        selected_value = event.target.value;
        if (event.target.value === 'other') {
            this.setState({
                show_modal: true,
                modal_title: 'Main Category',
                modal_label: 'Enter New Category',
                modal_for: 'category',
                modal_value: '',
                modal_error: ''
            });
        } else {
            var sub_category_values = {
                token: this.props.token,
                parent_category: event.target.value
            }
            this.props.SubCategoryList(sub_category_values, type);
            var market_values = {
                token: this.props.token,
                sub_category_name: ''
            }
            this.props.MarketList(market_values, type);
        }

        if (selected_value === '') {
            this.setState({
                cat_selected: selected_value,
                subcategorylist: [],
                subcat_selected: '',
                marketlist: [],
                market_selected: ''
            });
        } else {
            this.setState({
                cat_selected: selected_value,
            });
        }
    }


    handleSelectSubCategory(type, event) {
        let selected_value = '';
        let category_name = '';
        selected_value = event.target.value;
        if (event.target.value === 'other') {
            category_name = document.getElementById('case_category_main').value;
            if (category_name !== '') {
                this.setState({
                    show_modal: true,
                    modal_title: 'Sub Category',
                    modal_label: 'Enter Sub Category',
                    modal_for: 'subcategory',
                    modal_value: '',
                    modal_error: ''
                });
            } else {
                selected_value = '';
                alert('Category name cannot be blank');
            }
        } else {
            var market_values = {
                token: this.props.token,
                sub_category_name: event.target.value
            }
            this.props.MarketList(market_values, type);
        }

        if (selected_value === '') {
            this.setState({
                subcat_selected: selected_value,
                marketlist: [],
                market_selected: ''
            });
        } else {
            this.setState({
                subcat_selected: selected_value,
            });
        }
    }


    handleSelectMarket(type, event) {
        let selected_value = '';
        let category_name = '';
        if (event.target.value !== '') {
            selected_value = event.target.value;
            if (event.target.value === 'other') {
                category_name = document.getElementById('case_SubCategory').value;
                if (category_name !== '') {
                    this.setState({
                        show_modal: true,
                        modal_title: 'Market',
                        modal_label: 'Enter New Market',
                        modal_for: 'market',
                        modal_value: '',
                        modal_error: ''
                    });
                } else {
                    selected_value = '';
                    alert('Subcategory name cannot be blank');
                }
            }
        }
        this.setState({
            market_selected: selected_value
        });

    }

    updateValue(event) {
        this.setState({
            modal_value: event.target.value
        });
    }

    handleClose() {
        let modal_for = this.state.modal_for;
        if (modal_for === 'category') {
            this.setState({
                cat_selected: '',
                show_modal: false
            });
        } else if (modal_for === 'subcategory') {
            this.setState({
                subcat_selected: '',
                show_modal: false
            });
        } else if (modal_for === 'market') {
            this.setState({
                market_selected: '',
                show_modal: false
            });
        }
    }

    languageSet(event){
        //    console.log("event",event.target.id);
            let field = event.target.id;
            this.setState({[event.target.id]:event.target.value});
            
        }

    updateOptions() {
        let modal_for = this.state.modal_for;
        let selected_value = document.getElementById('product_options_modal_case').value;
        if (modal_for !== '') {
            if (selected_value !== '') {
                if (modal_for === 'category') {
                    let obj = this.state.categorylist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        categorylist: obj,
                        cat_selected: selected_value
                    });
                } else if (modal_for === 'subcategory') {
                    let obj = this.state.subcategorylist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        subcategorylist: obj,
                        subcat_selected: selected_value
                    });
                } else if (modal_for === 'market') {
                    let obj = this.state.marketlist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        marketlist: obj,
                        market_selected: selected_value
                    });
                }
                this.setState({ show_modal: false });
            } else {
                this.setState({ modal_error: 'Value cannot be blank' });
            }
        }
    }
    
    componentDidUpdate(prevProps){
		if(prevProps.form_data.case_gtin_code && this.state.gtin !== prevProps.form_data.case_gtin_code){
            this.setState({ gtin : prevProps.form_data.case_gtin_code });
            this.props.updategitin({case:prevProps.form_data.case_gtin_code})
		}
    }
    
    render() {


        // const { userSelectedLanguage } = this.props;

        const userSelectedLanguage  = 'EN';

        console.log("this.props.languagelist ", this.props.languagelist );

        return (

            <div className="cunitform">
                <div className="row">
                    <div className="col-xs-12 col-sm-6 col-md-5">
                        <div className="pdform_column first_coumn">
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Category</label>
                                        <Field selected_value={this.state.cat_selected} custom_options_start={[{ 'label': 'Select Category', 'value': '' }]} custom_options_end={[{ 'label': 'Add New', 'value': 'other' }]} options={this.state.categorylist} onChange={this.handleSelectCategory.bind(this, 'case')} className="form-control hsmall arrow" label="Category"  id="case_category_main" component={Common.renderSelect}  disabled={this.state.cat_selected != ''} name={this.state.cat_selected != ''  ? "case_CategorySelect" : "case_Category" }>
                                        </Field>
                                        {this.state.cat_selected != ''  ? <Field component="input" type="hidden" id={PREFIX+"Category"} name={PREFIX+"Category"} className="form-control hsmall" /> :  '' }
                                        {this.state.subcat_selected != ''  ? <Field component="input" type="hidden" id={PREFIX+"SubCategory"} name={PREFIX+"SubCategory"} className="form-control hsmall" /> : ''}
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Sub-Category</label>
                                        <Field selected_value={this.state.subcat_selected} custom_options_start={[{ 'label': 'Select Sub Category', 'value': '' }]} custom_options_end={[{ 'label': 'Add New', 'value': 'other' }]} options={this.state.subcategorylist} onChange={this.handleSelectSubCategory.bind(this, 'case')} className="form-control hsmall arrow"  id="case_sub_category" component={Common.renderSelect} disabled={this.state.subcat_selected != ''} name={this.state.subcat_selected != ''  ? "case_SubCategorySelect" : "case_SubCategory" }>
                                        </Field>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group hide">
                                <label>New Category</label>
                                <Field name={PREFIX+"main_category_other"} component="input" type="text" id="case_other_main_Category" className="form-control hsmall" />
                            </div>
                            <div className="form-group hide">
                                <label>New Sub Category</label>
                                <Field name={PREFIX+"sub_category_other"} component="input" type="text" id="case_other_sub_Category" className="form-control hsmall" />
                            </div>


                            <div className="form-group lang_div">
                                <label>Brand Name</label>
                                <div className="input-group">                                
                                {/* <span className="input-group-addon hide">{userSelectedLanguage}</span>  */}


                                {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                key={index}
                                                type="text"
                                                name={PREFIX+'languageSpecificBrandName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"Brand Name "+lang.LanguageCode.trim()}
                                                ref={"case_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                id={"case_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'case')}
                                                status={this.props.readonly_status} 
                                                value={this.state["case_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["case_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }
                                
                                </div>
                            </div>
                    
                            <div className="form-group lang_div">
                                <label>Sub Name</label>
                                <div className="input-group">      

                                {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}

                                {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                key={index}
                                                type="text"
                                                name={PREFIX+'Subbrand['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"Sub Brand "+lang.LanguageCode.trim()}
                                                ref={"case_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                
                                                id={"case_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'case')}
                                                status={this.props.readonly_status} 
                                                value={this.state["case_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["case_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }

                                </div>
                            </div>

                         
                         


                            <div className="form-group lang_div">
                                <label>Functional Name</label>
                                <div className="input-group">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}
                                {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                    key={index}
                                                    id={"case_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hidden': 'form-control' } 
                                                    type="text"
                                                    name={PREFIX+'FunctionalName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                    placeholder={"Functional Name "+lang.LanguageCode.trim()}
                                                    ref={"case_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                    onChange={this.languageSet} 
                                                    onBlur={this.props.handleChange.bind(this, 'case')}
                                                    status={this.props.readonly_status} 
                                                    value={this.state["case_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["case_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }
                                </div>
                            </div>


            
                            <div className="form-group lang_div">
                                <label>Variant</label>
                                <div className="input-group">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}

                                {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                    key={index}
                                                    type="text"
                                                    name={PREFIX+'Variant['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                    placeholder={"Variant "+lang.LanguageCode.trim()}
                                                    ref={"case_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                    type="text"
                                                    id={"case_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                    onChange={this.languageSet} 
                                                    onBlur={this.props.handleChange.bind(this, 'case')}
                                                    status={this.props.readonly_status} 
                                                    value={this.state["case_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["case_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }

                        
                                </div>
                            </div>


        

                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4">
                        <div className="pdform_column second_coumn">
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Net Content</label>
                                        <Field 
                                            onChange={ (e)=> this.handleChangeValue(e) }
                                            placeholder={"NetContent"+userSelectedLanguage} 
                                            name={PREFIX+"NetContent"}
                                            component={Common.renderInput} 
                                            type="text" 
                                            id="case_netcontent"
                                            className="form-control hsmall" 
                                            onBlur={this.props.handleChange.bind(this, 'case')}
                                           />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"NetContentUoM"} id="case_uom" onChange={this.props.handleChange.bind(this, 'case')} /> */}
                                        <Field 
                                            selected_value={this.state.uom_selected} 
                                            options={this.props.uomlist} 
                                            onChange={this.props.handleChange.bind(this, 'case')} 
                                            status={this.props.readonly_status}
                                            className="form-control hsmall arrow" 
                                            label="UOM"
                                            name={PREFIX+"NetContentUoM"}
                                            id="case_uom" 
                                            component={Common.renderSelect}  
                                            onChange={(event)=> {{this.setState({uom_selected:event.target.value})}}}
                                           >
                                        </Field>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Start Availablity Date</label>
                                        <Field name={PREFIX+"startAvailabilityDate"} component={Common.renderDate} type="text" id="case_start_availability_date" className="form-control hsmall" status={this.props.readonly_status} />

                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>End Availablity Date</label>
                                        <Field name={PREFIX+"endAvailabilityDate"} component={Common.renderDate} type="text" id="case_end_availability_date" className="form-control hsmall" status={this.props.readonly_status} />

                                    </div>
                                </div>
                            </div>
                            {/* <div className="form-group">
                                <label>Product Name</label>
                                <Field name="case_short_description" component="textarea" id="case_productname" className="form-control" disabled />
                                <textarea name={PREFIX+"case_short_description"} component="textarea" id="case_productname" className="form-control" disabled value={this.props.case_details['product_name']} />
                            </div> */}

                            <div className="form-group">
                                <label>Product Name</label>

                                
                                {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                             <textarea 
                                                key={index}
                                                placeholder={"Product Name "+lang.LanguageCode.trim()}
                                                name={PREFIX+'gtinName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                component="textarea" 
                                                id={"case_productname"+lang.LanguageCode.toLocaleLowerCase().trim()} 
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hide': "form-control" } 
                                                readOnly={true}
                                                //value={this.props.case_details['case_gtinName_'+lang.LanguageCode.toLocaleLowerCase().trim()]}
                                                value={ this.state["case_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" "+
                                                this.state["case_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" " +
                                                this.state["case_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" " +
                                                this.state["case_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" "+ 
                                                this.state.case_NetContent.trim() +" "+ this.state.uom_selected 
                                               }
                                            />
                                               ) 
                                                }
                                                ) : ''
                                            }

                            </div>
                         
                         

                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Shelf Life in Days</label>
                                        <Field placeholder="Shelf Life in Day" name={PREFIX+"minimumTradeItemLifespanFromProduction"} component="input" type="text" id="case_shelf_line_days" className="form-control hsmall" readOnly={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Date on Packaging</label>
                                        {/* <Field className="form-control hsmall arrow" name={PREFIX+"TradeItemDateOnPackagingTypeCode"} id="case_date_of_packaging" component="select" disabled={this.props.readonly_status}>
                                            <option value="">Select Package</option>
                                            <option value="BAKED_FOR_DATE">BAKED_FOR_DATE</option>
                                            <option value="BAKED_ON_DATE">BAKED_ON_DATE</option>
                                            <option value="BEST_BEFORE_DATE">BEST_BEFORE_DATE</option>
                                            <option value="DISPLAY_UNTIL_DATE">DISPLAY_UNTIL_DATE</option>
                                            <option value="EXPIRATION_DATE">EXPIRATION_DATE</option>
                                            <option value="FREEZE_BY">FREEZE_BY</option>
                                            <option value="LAST_SALE_DATE">LAST_SALE_DATE</option>
                                            <option value="NO_DATE_MARKED">NO_DATE_MARKED</option>
                                            <option value="PACKAGING_DATE">PACKAGING_DATE</option>
                                            <option value="PRODUCTION_DATE">PRODUCTION_DATE</option> */}
                                            <Field selected_value={this.state.datepackingtype_selected} options={this.state.select_dateandpacking} 
                                         className="form-control hsmall arrow" name={PREFIX+'TradeItemDateOnPackagingTypeCode'} id="case_date_of_packaging" component={Common.renderSelect} disabled={this.props.readonly_status} onChange={(event)=> {{this.setState({datepackingtype_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <label>Country of Origin</label>
                                {/* <RenderSelect custom_options_start={[{ 'label': 'Select Country', 'value': '' }]} options={this.props.countrylist} className="form-control hsmall arrow" name={PREFIX+"TargetMarketCountryCode"} id="case_country_origin" status={this.props.readonly_status} /> */}
                                {/* <Field className="form-control hsmall arrow" name="case_country_origin" id="case_country_origin" component="select">
                                 <option value="">Select Country</option>
                             </Field> */}

                                    <Field  custom_options_start={[{ 'label': 'Select Country', 'value': '' }]} options={this.props.countrylist} className="form-control hsmall arrow" name={PREFIX+'CountryOfOrigin'} id="case_country_origin" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({country_selected:event.target.value})}}} selected_value={this.state.country_selected}>
                                        </Field>
                            </div>
                        </div>
                    </div>

                    <div className="col-xs-12  col-md-3">
                        <div className="pdform_column last_coumn preview_product_image">
                            <div className="preview_title">
                                <p>Preview</p>
                            </div>
                            <div className="preview_img">

                                <img src={(this.props.form_data.hasOwnProperty('case_image_name') && this.props.form_data.case_image_name !== '' && this.props.form_data.case_image_name != null && this.props.form_data.case_image_name !== 'undefined' && this.props.form_data.case_image_name.length >= 1) ? Config.detail_img_path + this.props.form_data.case_image_name : Config.assetspath + 'default.png'} alt="" />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-xs-12 col-sm-6 col-md-5">
                        <div className="pdform_column">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>GTIN</label> 
                                        {/* <Field name="case_gtin_code" component="input" type="text" id="case_gtin_code" className="form-control" onBlur={this.props.handleChange.bind(this,'case')}/> */}
                                        {(this.props.form_data.hasOwnProperty('case_gtin_code') && this.props.form_data.case_gtin_code) ?
                                            <Field 
                                            name={PREFIX+"GTIN"} 
                                            component="input"
                                             readOnly 
                                             type="text" 
                                             id="case_gtin_code"
                                              className="form-control"
                                               onBlur={this.props.handleChange.bind(this, 'case')} 
                                               normalize={normalizeMaxLength(14)}/>
                                            :
                                            <Field name={PREFIX+"GTIN"} component={Common.renderInput} type="text" id="case_gtin_code" className="form-control" onBlur={this.props.handleChange.bind(this, 'case')} status={this.props.readonly_status} 
                                            normalize={normalizeMaxLength(14)}/>
                                        }
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>SKU#</label>
                                        <Field placeholder="SKU" name={PREFIX+"alternateItemIdentification"} component="input" type="text" id="case_sku" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeMaxLength(20)}/>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>Quantity of next level</label>
                                        <Field placeholder="Quantity of next level" name={PREFIX+"quantityOfTradeItemsContainedInACompleteLayer"} component="input" type="text" id="case_quantityof_level" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeNumberAndSetLimit(10)}/>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>Packaging type</label>
                                        {/* <RenderSelect custom_options_start={[{ 'label': 'Select Packaging Type', 'value': '' }]} options={this.props.packagingtypelist} className="form-control hsmall arrow" name={PREFIX+"packagingType"} id="case_packaging_type" status={this.props.readonly_status} /> */}
                                        {/* <Field name="case_packaging_type" component="select" id="case_packaging_type" className="form-control hsmall arrow" >
                                     <option value="">Select Packaging Type</option>
                                 </Field> */}
                                 <Field  custom_options_start={[{ 'label': 'Select Packaging Type', 'value': '' }]} options={this.props.packagingtypelist} className="form-control hsmall arrow" name={PREFIX+"packagingType"} id="case_packaging_type" status={this.props.readonly_status}  component={Common.renderSelect} onChange={(event)=> {{this.setState({packingtype_selected:event.target.value})}}} selected_value={this.state.packingtype_selected}></Field>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                {/* <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Height</label>
                                        <Field name={PREFIX+"height"} component="input" type="text" id="case_height" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"heightUom"} id="case_height_uom" status={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Width</label>
                                        <Field name={PREFIX+"width"} component="input" type="text" id="case_width" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name="case_width_uom" id="case_width_uom" status={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Length</label>
                                        <Field name={PREFIX+"depth"} component="input" type="text" id="case_length" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"depthUom"} id="case_productatt_uom" status={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Gross Weight</label>
                                        <Field name={PREFIX+"grossWeight"} component="input" type="text" id="case_gross_weight" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"grossWeightUOM"} id="case_gross_weight_uom" status={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Packaging Weight</label>
                                        <Field name={PREFIX+"packagingWeight"} component="input" type="text" id="case_packaging_weight" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"packagingWeightUOM"} id="case_packaging_weight_uom" status={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Net Weight</label>
                                        <Field name={PREFIX+"netWeight"} component="input" type="text" id="case_net_weight" className="form-control" readOnly={this.props.readonly_status} />
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"NetWeightUOM"} id="case_weighting_uom" status={this.props.readonly_status} />
                                    </div>
                                </div> */}
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Height</label>
                                        <Field name={PREFIX+'height'} component="input" type="text" id="case_height" className="form-control" readOnly={this.props.readonly_status} normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'heightUom'} id="case_height_uom" status={this.props.readonly_status} /> */}
                                        
                                        <Field selected_value={this.state.heightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'heightUom'} id="case_height_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({heightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Width</label>
                                        <Field name={PREFIX+'width'} component="input" type="text" id="case_width" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'widthUom'} id="case_width_uom" status={this.props.readonly_status} /> */}
                                        
                                        <Field selected_value={this.state.widthuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'widthUom'} id="case_width_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({widthuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Length</label>
                                        <Field name={PREFIX+'depth'} component="input" type="text" id="case_length" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"depthUom"} id="case_productatt_uom" status={this.props.readonly_status} /> */}
                                        
                                        <Field selected_value={this.state.depthuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"depthUom"} id="case_productatt_uom" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({depthuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Gross Weight</label>
                                        <Field name={PREFIX+"grossWeight"} component="input" type="text" id="case_gross_weight" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"grossWeightUOM"} id="case_gross_weight_uom" status={this.props.readonly_status} /> */}
                                        
                                        <Field selected_value={this.state.grossweightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"grossWeightUOM"} id="case_gross_weight_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({grossweightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Packaging Weight</label>
                                        <Field name={PREFIX+"packagingWeight"} value="" component="input" type="text" id="case_packaging_weight" className="form-control" readOnly={this.props.readonly_status}  normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name="case_packaging_weight_uom" id="case_packaging_weight_uom" status={this.props.readonly_status} /> */}
                                        
                                        <Field selected_value={this.state.packingweight_selected} options={this.props.uomlist} className="form-control hsmall arrow" name="case_packagingWeightUOM" id="case_packaging_weight_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({packingweight_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Net Weight</label>
                                        <Field name={PREFIX+"netWeight"} component="input" type="text" id="case_net_weight" className="form-control" readOnly={this.props.readonly_status} 
                                         normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        {/* <RenderSelect options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"NetWeightUOM"} id="case_weighting_uom" status={this.props.readonly_status} /> */}
                                       
                                        <Field selected_value={this.state.weightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"NetWeightUOM"} id="case_weighting_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({weightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                          
                            </div>
                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-6">
                        <div className="pdform_column">
                            <div className="taxlist lightgray list-background">
                            <div className="row">
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isDispatchUnit"} id="case_dunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="dunit">Dispatch Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isConsumerUnit"} id="case_cunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="cunit">Consumer Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isInvoiceUnit"} id="case_inunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="inunit">Invoice Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isOrderableUnit"} id="case_ounit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="ounit">Order Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"packagingMarkedReturnable"} id="case_pmr" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="pmr">Packaging Marked Returnable</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"hasbatchnumber"} id="case_has_batch_number" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="case_has_batch_number">Has Batch Number</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"is_net_content_declared"} id="case_is_net_content_declared" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="case_is_net_content_declared">Is Net Content Declared</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"is_variable_weight_item"} id="case_is_variable_weight_item" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="case_is_variable_weight_item">Is Variable Weight Item</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"market_with_ingredients"} id="case_market_with_ingredients" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="case_market_with_ingredients">Market With Ingredients</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isTradeItemAService"} id="case_iti" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="iti">Is Trade Item</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="row">
                                                <div className="col-xs-8">
                                                    <div className="inline-checkbox tick">
                                                        <Field name={PREFIX+"vat_excempt"} id="case_vatexempt" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                        <label htmlFor="vatexempt">VAT Exempt</label>
                                                    </div>
                                                </div>
                                                <div className="col-xs-4">
                                                    <Field placeholder="%" name={PREFIX+"vat_exempt_percentage"} id="case_vat_exemp_percentage" component="input" type="text" className="form-control" readOnly={this.props.readonly_status} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isTradeItemGeneticallyModified"} id="case_gm" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="gm">Genetically Modified</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"dangerous_goods"} id="case_dgoods" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="dgoods">Dangerous Goods</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"handlingInstructionCode"} id="case_handlingins" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="handlingins">Handling Instructions</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {(this.props.user_type !== Config.userTypes.Retailer) ?
                    <div className="col-xs-12 col-sm-12 col-md-1">
                        <div className="saveform">
                            <Field name={PREFIX+'GUID'} component={Common.renderInput} type="hidden" id="case_GUID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'case')} status={this.props.readonly_status} ref="case_GUID" />
                            <input name={PREFIX+'pID'} type="hidden" id="case_pID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'case')} status={this.props.readonly_status} ref="case_pID" value={this.props.form_data.cu_pID}/>
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button type="submit" id="case_status_save_option" className="btn-save" value="Save">Save</Button>
                            </div>
                            <div className="next_btn">
                                <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
                    :''}
                </div>
                <Modal id="product_options_modal_case" {...this.state} updateValue={this.updateValue} handleClose={this.handleClose} updateOptions={this.updateOptions} />
            </div>
        )
    }
}