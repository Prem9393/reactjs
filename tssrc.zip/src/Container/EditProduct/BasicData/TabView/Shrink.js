import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Button } from 'react-bootstrap';
import Common from '../../../../Common';
import RenderSelect from '../../../../Components/SelectField';
import Modal from '../../../../Components/Modal';
import Config from '../../../../Config';

import { normalizeMaxLength, normalizeNumberAndSetLimit, requiredNumberAndSetLimit} from '../../../../Validations';

let PREFIX ='shr_';




export default class ShrinkView extends Component {
    constructor(props) {
        super(props);
        this.handleSelectCategory = this.handleSelectCategory.bind(this);
        this.handleSelectSubCategory = this.handleSelectSubCategory.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.updateOptions = this.updateOptions.bind(this);
        this.updateValue = this.updateValue.bind(this);
        this.languageSet = this.languageSet.bind(this);
        this.handleChangeValue =  this.handleChangeValue.bind(this);
        this.state = {
            show_modal: false,
            modal_title: '',
            modal_label: '',
            tabkey: 1,
            modal_for: '',
            modal_value: '',

            select_dateandpacking: [
                {label: 'Select Package', value: ''},
                {label: 'BAKED_FOR_DATE', value: 'BAKED_FOR_DATE'},
                {label: 'BAKED_ON_DATE', value: 'BAKED_ON_DATE'},
                {label: 'BEST_BEFORE_DATE', value: 'BEST_BEFORE_DATE'},
                {label: 'DISPLAY_UNTIL_DATE', value: 'DISPLAY_UNTIL_DATE'},
                {label: 'EXPIRATION_DATE', value: 'EXPIRATION_DATE'},
                {label: 'FREEZE_BY', value: 'FREEZE_BY'},
                {label: 'LAST_SALE_DATE', value: 'LAST_SALE_DATE'},
                {label: 'NO_DATE_MARKED', value: 'NO_DATE_MARKED3'},
                {label: 'PACKAGING_DATE', value: 'PACKAGING_DATE'},
                {label: 'PRODUCTION_DATE', value: 'PRODUCTION_DATE'},
            ],
            shr_NetContent:'',
            shr_languageSpecificBrandName_en: '',
            shr_languageSpecificBrandName_nl:'',
            shr_languageSpecificBrandName_xu: '',            
            shr_Subbrand_en: '',
            shr_Subbrand_nl: '',
            shr_Subbrand_xu: '',
            shr_FunctionalName_en: '',
            shr_FunctionalName_nl: '',
            shr_FunctionalName_xu: '',
            shr_Variant_en: '',
            shr_Variant_nl: '',
            shr_Variant_xu: '',
            categorylist: this.props.shr_categorylist,
            cat_selected: '',
            subcategorylist: this.props.shr_subcategorylist,
            subcat_selected: '',
            marketlist: this.props.shr_marketlist,
            market_selected: '',
            gtin:'',
        }
      
    }

    
    static getDerivedStateFromProps(props, state) {
        if (props.form_data.hasOwnProperty('shr_GTIN') && !state.selections_loaded) {
            if (props.form_data.shr_Category !== '') {
                var sub_category_values = {
                    token: props.token,
                    parent_category: props.form_data.shr_Category
                }
                props.SubCategoryList(sub_category_values, 'shr');
            }
            if (props.form_data.shr_SubCategory !== '') {
                var market_values = {
                    token: props.token,
                    sub_category_name: props.form_data.shr_SubsCategory
                }
                props.MarketList(market_values, 'shr');
            }
            var select_category = [];
            props.shr_categorylist.forEach((category, index) => {
                select_category.push({
                        'label' : category.label.trim(),
                        'value' : category.value.trim(),
                });
            });

            var select_sub_category = [];
            props.shr_subcategorylist.forEach((sub_category, index) => {
                select_sub_category.push({
                        'label' : sub_category.label.trim(),
                        'value' : sub_category.value.trim(),
                });
            });

            var grossweightuom = (props.form_data.shr_grossWeightUOM != null  ?  props.form_data.shr_grossWeightUOM.trim() : '');

            var depthuom = (props.form_data.shr_depthUom != null ?  props.form_data.shr_depthUom.trim() : '');
            var widthuom = (props.form_data.shr_widthUom != null  ?  props.form_data.shr_widthUom.trim() : '');
            var heightuom = (props.form_data.shr_heightUom  != null ?  props.form_data.shr_heightUom.trim() : '');
            var netweightuom = (props.form_data.shr_NetWeightUOM != null  ?  props.form_data.shr_NetWeightUOM.trim() : '');
            var packagingweightuom = (props.form_data.shr_packagingWeightUOM != null  ?  props.form_data.shr_packagingWeightUOM.trim() : '');
            var shr_NetContent = (props.form_data.shr_NetContent != null ? props.form_data.shr_NetContent.trim() : '' );
            var packagingweightuom = (props.form_data.shr_packagingWeightUOM != null  ?  props.form_data.shr_packagingWeightUOM.trim() : '');
            var category = (props.form_data.shr_Category != null  ?  props.form_data.shr_Category.trim() : '');
            var subCategory = (props.form_data.shr_SubCategory != null  ?  props.form_data.shr_SubCategory.trim() : '');

            return {
                selections_loaded: true,
                cat_selected: category,
                subcat_selected: subCategory,
                uom_selected: (props.form_data.shr_NetContentUoM != null ?  props.form_data.shr_NetContentUoM.trim() : ''),
                country_selected: (props.form_data.shr_TargetMarketCountryCode != null ?  props.form_data.shr_TargetMarketCountryCode.trim() : ''),
                packingtype_selected: (props.form_data.shr_packagingType != null ?  props.form_data.shr_packagingType.trim() : ''),
                datepackingtype_selected: (props.form_data.shr_TradeItemDateOnPackagingTypeCode != null ?  props.form_data.shr_TradeItemDateOnPackagingTypeCode.trim() : ''),
                heightuom_selected: heightuom,
                widthuom_selected: widthuom,
                depthuom_selected: depthuom,
                grossweightuom_selected: grossweightuom,
                packingweight_selected: packagingweightuom,
                weightuom_selected: netweightuom,
                market_selected: props.form_data.shr_market_name,
                categorylist: select_category,
                subcategorylist: select_sub_category,
                marketlist: props.shr_marketlist, 
                shr_NetContent: shr_NetContent,               
                shr_languageSpecificBrandName_en:(props.form_data.shr_languageSpecificBrandName_en  != null ?  props.form_data.shr_languageSpecificBrandName_en.trim() : ''),
                shr_languageSpecificBrandName_nl:(props.form_data.shr_languageSpecificBrandName_nl  != null ?  props.form_data.shr_languageSpecificBrandName_nl.trim() : ''), 
                shr_languageSpecificBrandName_xu:(props.form_data.shr_languageSpecificBrandName_xu  != null ?  props.form_data.shr_languageSpecificBrandName_xu.trim() : ''), 
                shr_Subbrand_en: (props.form_data.shr_Subbrand_en  != null ?  props.form_data.shr_Subbrand_en.trim() : ''),
                shr_Subbrand_nl: (props.form_data.shr_Subbrand_nl  != null ?  props.form_data.shr_Subbrand_nl.trim() : ''),
                shr_Subbrand_xu: (props.form_data.shr_Subbrand_xu  != null ?  props.form_data.shr_Subbrand_xu.trim() : ''),
                shr_FunctionalName_en: (props.form_data.shr_FunctionalName_en  != null ?  props.form_data.shr_FunctionalName_en.trim() : ''),
                shr_FunctionalName_nl: (props.form_data.shr_FunctionalName_nl  != null ?  props.form_data.shr_FunctionalName_nl.trim() : ''),
                shr_FunctionalName_xu: (props.form_data.shr_FunctionalName_xu  != null ?  props.form_data.shr_FunctionalName_xu.trim() : ''),
                shr_Variant_en:(props.form_data.shr_Variant_en  != null ?  props.form_data.shr_Variant_en.trim() : ''),
                shr_Variant_nl:(props.form_data.shr_Variant_nl  != null ?  props.form_data.shr_Variant_nl.trim() : ''),
                shr_Variant_xu:(props.form_data.shr_Variant_xu  != null ?  props.form_data.shr_Variant_xu.trim() : '')
            }
        } else {
            var select_category = [];
            props.shr_categorylist.forEach((category, index) => {
                select_category.push({
                        'label' : category.label.trim(),
                        'value' : category.value.trim(),
                });
            });
            var select_sub_category = [];
            props.shr_subcategorylist.forEach((sub_category, index) => {
                select_sub_category.push({
                        'label' : sub_category.label.trim(),
                        'value' : sub_category.value.trim(),
                });
            });
            return {
                categorylist: select_category,
                subcategorylist: select_sub_category,
                marketlist: props.shr_marketlist,
            }
        }
    }
    handleChangeValue(e){
        this.setState({[e.target.id]: e.target.value})
    }

    languageSet(event){
        let field = event.target.id;
        this.setState({[event.target.id]:event.target.value});
        
    }

    /*componentDidUpdate(prevProps) {
        // console.log('11::',prevProps.form_data.shr_gtin_code)
        // console.log('22::',this.props.form_data.shr_gtin_code)
        if(this.props.form_data.hasOwnProperty('shr_gtin_code') && prevProps.form_data.hasOwnProperty('shr_gtin_code')){
           
                // console.log('prevProps ShrinkView', prevProps.form_data.shr_gtin_code)
           
            
        }

    }*/
    handleSelectCategory(type, event) {
        let selected_value = '';
        selected_value = event.target.value;
        if (event.target.value === 'other') {
            this.setState({
                show_modal: true,
                modal_title: 'Main Category',
                modal_label: 'Enter New Category',
                modal_for: 'category',
                modal_value: '',
                modal_error: ''
            });
        } else {
            var sub_category_values = {
                token: this.props.token,
                parent_category: event.target.value
            }
            this.props.SubCategoryList(sub_category_values, type);
            var market_values = {
                token: this.props.token,
                sub_category_name: ''
            }
            this.props.MarketList(market_values, type);
        }

        if (selected_value === '') {
            this.setState({
                cat_selected: selected_value,
                subcategorylist: [],
                subcat_selected: '',
                marketlist: [],
                market_selected: ''
            });
        } else {
            this.setState({
                cat_selected: selected_value,
            });
        }
    }


    handleSelectSubCategory(type, event) {

        let selected_value = '';
        let category_name = '';
        selected_value = event.target.value;
        if (event.target.value === 'other') {
            category_name = document.getElementById('shr_Category').value;
            if (category_name !== '') {
                this.setState({
                    show_modal: true,
                    modal_title: 'Sub Category',
                    modal_label: 'Enter Sub Category',
                    modal_for: 'subcategory',
                    modal_value: '',
                    modal_error: ''
                });
            } else {
                selected_value = '';
                alert('Category name cannot be blank');
            }
        } else {
            var market_values = {
                token: this.props.token,
                sub_category_name: event.target.value
            }
            this.props.MarketList(market_values, type);
        }

        if (selected_value === '') {
            this.setState({
                subcat_selected: selected_value,
                marketlist: [],
                market_selected: ''
            });
        } else {
            this.setState({
                subcat_selected: selected_value,
            });
        }
        // alert(document.getElementById('shr_sub_category').value);
        // document.getElementById('shr_SubCategory').value = document.getElementById('shr_sub_category').value
    }


    handleSelectMarket(type, event) {
        let selected_value = '';
        let category_name = '';
        if (event.target.value !== '') {
            selected_value = event.target.value;
            if (event.target.value === 'other') {
                category_name = document.getElementById('shr_SubCategory').value;
                if (category_name !== '') {
                    this.setState({
                        show_modal: true,
                        modal_title: 'Market',
                        modal_label: 'Enter New Market',
                        modal_for: 'market',
                        modal_value: '',
                        modal_error: ''
                    });
                } else {
                    selected_value = '';
                    alert('Subcategory name cannot be blank');
                }
            }
        }
        
        this.setState({
            market_selected: selected_value
        });

    }

    updateValue(event) {
        this.setState({
            modal_value: event.target.value
        });
    }

    handleClose() {
        let modal_for = this.state.modal_for;
        if (modal_for === 'category') {
            this.setState({
                cat_selected: '',
                show_modal: false
            });
        } else if (modal_for === 'subcategory') {
            this.setState({
                subcat_selected: '',
                show_modal: false
            });
        } else if (modal_for === 'market') {
            this.setState({
                market_selected: '',
                show_modal: false
            });
        }
    }

    updateOptions() {
        let modal_for = this.state.modal_for;
        let selected_value = document.getElementById('product_options_modal_shr').value;
        if (modal_for !== '') {
            if (selected_value !== '') {
                if (modal_for === 'category') {
                    let obj = this.state.categorylist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        categorylist: obj,
                        cat_selected: selected_value
                    });
                } else if (modal_for === 'subcategory') {
                    let obj = this.state.subcategorylist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        subcategorylist: obj,
                        subcat_selected: selected_value
                    });
                } else if (modal_for === 'market') {
                    let obj = this.state.marketlist;
                    obj.push({ 'label': selected_value, 'value': selected_value });
                    this.setState({
                        marketlist: obj,
                        market_selected: selected_value
                    });
                }
                this.setState({ show_modal: false });
            } else {
                this.setState({ modal_error: 'Value cannot be blank' });
            }
        }
    }

    componentDidUpdate(prevProps){
		if(prevProps.form_data.shr_GTIN && this.state.gtin !== prevProps.form_data.shr_GTIN){
            this.setState({ gtin : prevProps.form_data.shr_GTIN });
            this.props.updategitin({shrink:prevProps.form_data.shr_GTIN})
		}
    }
     
    render() {

        // const { userSelectedLanguage } = this.props;

        const userSelectedLanguage  = 'EN';
        
        return (
            <div className="cunitform">
                <div className="row">
                    <div className="col-xs-12 col-sm-6 col-md-5">
                        <div className="pdform_column first_coumn">
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Category</label>
                                        <Field selected_value={this.state.cat_selected} custom_options_start={[{ 'label': 'Select Category', 'value': '' }]} custom_options_end={[{ 'label': 'Add New', 'value': 'other' }]} options={this.state.categorylist} onChange={this.handleSelectCategory.bind(this, 'shr')} className="form-control hsmall arrow" label="Category" id="shr_category_main" component={Common.renderSelect} disabled={this.state.cat_selected != ''} name={this.state.cat_selected != ''  ? "shr_CategorySelect" : "shr_Category" }>
                                        </Field>
                                        {this.state.cat_selected != ''  ? <Field component="input" type="hidden" id={PREFIX+"Category"} name={PREFIX+"Category"} className="form-control hsmall" /> :  '' }
                                        {this.state.subcat_selected != ''  ? <Field component="input" type="hidden" id={PREFIX+"SubCategory"} name={PREFIX+"SubCategory"} className="form-control hsmall" /> : ''}
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Sub-Category</label>
                                        <Field selected_value={this.state.subcat_selected} custom_options_start={[{ 'label': 'Select Sub Category', 'value': '' }]} custom_options_end={[{ 'label': 'Add New', 'value': 'other' }]} options={this.state.subcategorylist} onChange={this.handleSelectSubCategory.bind(this, 'shr')} className="form-control hsmall arrow" id="shr_sub_category" component={Common.renderSelect} disabled={this.state.subcat_selected != ''} name={this.state.subcat_selected != ''  ? "shr_SubCategorySelect" : "shr_SubCategory" }>
                                        </Field>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group hide">
                                <label>New Category</label>
                                <Field name={PREFIX+"main_category_other"} component="input" type="text" id="shr_other_main_Category" className="form-control hsmall" />
                            </div>
                            <div className="form-group hide">
                                <label>New Sub Category</label>
                                <Field name={PREFIX+"sub_category_other"} component="input" type="text" id="shr_other_sub_Category" className="form-control hsmall" />
                            </div>
                            {/* <div className="form-group">
                                <label>Market</label>
                                <Field selected_value={this.state.market_selected} custom_options_start={[{ 'label': 'Select Market', 'value': '' }]} custom_options_end={[{ 'label': 'Add New', 'value': 'other' }]} options={this.state.marketlist} onChange={this.handleSelectMarket.bind(this, 'shr')} className="form-control hsmall arrow" name="shr_market_name" id="shr_target_market" component={Common.renderSelect}>
                                </Field>
                            </div>
                            <div className="form-group hide">
                                <label>New Market</label>
                                <Field name="shr_other_target_market" component="input" type="text" id="shr_target_market_other" className="form-control hsmall" />
                            </div> */}
                           
                            <div className="form-group">
                                <label>Brand Names</label>
                                <div className="input-group lang_div">                                
                                    {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                    {  this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                type="text"
                                                key={index}
                                                name={PREFIX+'languageSpecificBrandName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"Brand Name "+lang.LanguageCode.trim()}
                                                ref={"shr_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                id={"shr_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'shr')}
                                                status={this.props.readonly_status} 
                                                value={this.state["shr_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["shr_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                 }
                                    
                                </div>
                            </div>

               
               

                    <div className="form-group">
                        <label>Sub Name</label>
                        <div className="input-group lang_div">                                
                            {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}

                            {  this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                type="text"
                                                key={index}
                                                name={PREFIX+'Subbrand['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"SubBrand "+lang.LanguageCode.trim()}
                                                ref={"shr_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                id={"shr_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'shr')}
                                                status={this.props.readonly_status} 
                                                value={this.state["shr_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["shr_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                   }
                                   

                        </div>
                    </div>

                          
                          
                            <div className="form-group">
                                <label>Functional Name</label>
                                <div className="input-group lang_div">                                
                                    {/* <span className="input-group-addon">{userSelectedLanguage}</span>                                     */}

                                    {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                key={index}
                                                type="text"
                                                name={PREFIX+'FunctionalName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"FunctionalName "+lang.LanguageCode.trim()}
                                                ref={"shr_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                
                                                id={"shr_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'shr')}
                                                status={this.props.readonly_status} 
                                                value={this.state["shr_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["shr_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }
                                    
                                    
                                </div>
                            </div>
                          

                            <div className="form-group">
                                <label>Variant</label>
                                <div className="input-group lang_div">                                
                                    {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}

                                    {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                                <input 
                                                key={index}
                                                type="text"
                                                name={PREFIX+'Variant['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                placeholder={"Variant "+lang.LanguageCode.trim()}
                                                ref={"shr_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                type="text"
                                                id={"shr_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()}  
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                                onChange={this.languageSet} 
                                                onBlur={this.props.handleChange.bind(this, 'shr')}
                                                status={this.props.readonly_status} 
                                                value={this.state["shr_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()]  ? this.state["shr_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()] : ''} 
                                            />
                                                ) 
                                                }
                                                ) : ''
                                       }

                                </div>
                            </div>

                    

                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4">
                        <div className="pdform_column second_coumn">
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Net Content</label>
                                        <Field 
                                        name={PREFIX+"NetContent"} 
                                        placeholder="NetContent"  
                                        component={Common.renderInput}
                                         type="text" 
                                         id="shr_netcontent" 
                                         className="form-control hsmall" 
                                         onChange={ (e)=> this.handleChangeValue(e) }
                                         onFocus={this.props.handleChange.bind(this, 'shr')} />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.uom_selected} options={this.props.uomlist}  onChange={(event)=> {{this.setState({uom_selected:event.target.value})}}}  status={this.props.readonly_status} className="form-control hsmall arrow" label="UOM" name={PREFIX+"NetContentUoM"} id="shr_uom" component={Common.renderSelect}>
                                        </Field>

                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Start Availablity Date</label>
                                        <Field name={PREFIX+"startAvailabilityDate"} component={Common.renderDate} type="text" id="shr_start_availability_date" className="form-control hsmall" status={this.props.readonly_status} />

                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>End Availablity Date</label>
                                        <Field name={PREFIX+"endAvailabilityDate"} component={Common.renderDate} type="text" id="shr_end_availability_date" className="form-control hsmall" status={this.props.readonly_status} />

                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <label>Product Name</label>

                                    {  
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                            this.props.languagelist.map( (lang, index)=>{
                                            return ( 
                                             <textarea 
                                                key={index}
                                                placeholder={"Product Name "+lang.LanguageCode.trim()}
                                                name={PREFIX+'gtinName['+lang.LanguageCode.toLowerCase().trim()+']'} 
                                                component="textarea" 
                                                id={PREFIX+'productname'+lang.LanguageCode.toLocaleLowerCase().trim()} 
                                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hide': "form-control" } 
                                                readOnly={true}
                                                //value={this.props.shr_details['gtinName_'+lang.LanguageCode.toLocaleLowerCase().trim()]}
                                                value={ this.state["shr_languageSpecificBrandName_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" "+
                                                this.state["shr_Subbrand_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" " +
                                                this.state["shr_FunctionalName_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" " +
                                                this.state["shr_Variant_"+lang.LanguageCode.toLocaleLowerCase().trim()] +" "+
                                                this.state.shr_NetContent.trim() +" "+ this.state.uom_selected 
                                               }
                                            />
                                               ) 
                                                }
                                                ) : ''
                                            }
                            </div>

                    
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Shelf Life in Days</label>
                                        <Field placeholder="Shelf Life in Days" name={PREFIX+"minimumTradeItemLifespanFromProduction"} component="input" type="text" id="shr_shelf_line_days" className="form-control hsmall" readOnly={this.props.readonly_status} />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Date on Packaging</label>
                                        <Field selected_value={this.state.datepackingtype_selected} options={this.state.select_dateandpacking} 
                                         className="form-control hsmall arrow" name={PREFIX+'TradeItemDateOnPackagingTypeCode'} id="shr_date_of_packaging" component={Common.renderSelect} disabled={this.props.readonly_status}  onChange={(event)=> {{this.setState({datepackingtype_selected:event.target.value})}}} >
                                        </Field>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <label>Country of Origin</label>
                                <Field selected_value={this.state.country_selected} options={this.props.countrylist}  className="form-control hsmall arrow" label="CountryOfOrigin" name={PREFIX+'CountryOfOrigin'} id={PREFIX+'CountryOfOrigin'} component={Common.renderSelect} onChange={(event)=> {{this.setState({country_selected:event.target.value})}}} custom_options_start={[{ 'label': 'Select Country', 'value': '' }]}></Field>

                            </div>
                        </div>
                    </div>
                    <div className="col-xs-12 col-md-3">
                        <div className="pdform_column last_coumn preview_product_image">
                            <div className="preview_title">
                                <p>Preview</p>
                            </div>
                            <div className="preview_img">
                            <img src={(this.props.form_data.hasOwnProperty('shr_image_name') && this.props.form_data.shr_image_name !== '' && this.props.form_data.shr_image_name !== undefined && this.props.form_data.shr_image_name != null && this.props.form_data.shr_image_name.length >= 1) ? Config.detail_img_path + this.props.form_data.shr_image_name : Config.assetspath + 'default.png'} alt="" />                               
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-xs-12 col-sm-6 col-md-5">
                        <div className="pdform_column">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>GTIN</label>
                                        {(this.props.form_data.hasOwnProperty('shr_GTIN') && this.props.form_data.shr_GTIN) ?
                                            <Field placeholder="GTIN" name={PREFIX+"GTIN"} component="input" readOnly type="text" id="shr_GTIN" className="form-control" onBlur={this.props.handleChange.bind(this, 'shr')} 
                                              normalize={ normalizeMaxLength(14) }
                                            />
                                            :
                                            <Field placeholder="GTIN" name={PREFIX+"GTIN"} component={Common.renderInput} type="text" id="shr_GTIN" className="form-control" onBlur={this.props.handleChange.bind(this, 'shr')} status={this.props.readonly_status} 
                                             normalize={ normalizeMaxLength(14) }
                                            />
                                        }
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>SKU#</label>
                                        <Field placeholder="SKU" name={PREFIX+"alternateItemIdentification"} component="input" type="text" id="shr_sku" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeMaxLength(20)}/>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>Quantity of next level</label>
                                        <Field placeholder="Quantity of next level" name={PREFIX+"quantityOfTradeItemsContainedInACompleteLayer"} component="input" type="text" id="shr_quantityof_level" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(10)}/>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6">
                                    <div className="form-group">
                                        <label>Packaging type</label>
                                        <Field selected_value={this.state.packingtype_selected} custom_options_start={[{ 'label': 'Select Packaging Type', 'value': '' }]} options={this.props.packagingtypelist} className="form-control hsmall arrow" name={PREFIX+'packagingType'} id="shr_packaging_type" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({packingtype_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>

                            </div>
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Height</label>
                                        <Field name={PREFIX+"height"} component="input" type="text" id="shr_height" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.heightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'heightUom'} id="shr_height_uom" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({heightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Width</label>
                                        <Field name={PREFIX+"width"} component="input" type="text" id="shr_width" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.widthuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+'widthUom'} id="shr_width_uom" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({widthuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Length</label>
                                        <Field name={PREFIX+"depth"} component="input" type="text" id="shr_length" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.depthuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"depthUom"} id="shr_productatt_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({depthuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Gross Weight</label>
                                        <Field name={PREFIX+"grossWeight"} component="input" type="text" id="shr_gross_weight" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.grossweightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"grossWeightUOM"} id="shr_gross_weight_uom" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({grossweightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 light-color">
                                    <div className="form-group">
                                        <label>Packaging Weight</label>
                                        <Field name={PREFIX+"packagingWeight"} value="" component="input" type="text" id="shr_packaging_weight" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.packingweight_selected} options={this.props.uomlist} className="form-control hsmall arrow" name="shr_packagingWeightUOM" id="shr_packaging_weight_uom" status={this.props.readonly_status} component={Common.renderSelect}  onChange={(event)=> {{this.setState({packingweight_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-2 dark-color">
                                    <div className="form-group">
                                        <label>Net Weight</label>
                                        <Field name={PREFIX+"netWeight"} component="input" type="text" id="shr_net_weight" className="form-control" readOnly={this.props.readonly_status} 
                                        normalize={normalizeNumberAndSetLimit(5)}/>
                                    </div>
                                    <div className="form-group">
                                        <label>UOM</label>
                                        <Field selected_value={this.state.weightuom_selected} options={this.props.uomlist} className="form-control hsmall arrow" name={PREFIX+"NetWeightUOM"} id="shr_weighting_uom" status={this.props.readonly_status} component={Common.renderSelect} onChange={(event)=> {{this.setState({weightuom_selected:event.target.value})}}}>
                                        </Field>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-6">
                        <div className="pdform_column">
                            <div className="taxlist lightgray list-background">
                            <div className="row">
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isDispatchUnit"} id="shr_dunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="dunit">Dispatch Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isConsumerUnit"} id="shr_cunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="cunit">Consumer Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isInvoiceUnit"} id="shr_inunit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="inunit">Invoice Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isOrderableUnit"} id="shr_ounit" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="ounit">Order Unit</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"packagingMarkedReturnable"} id="shr_pmr" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="pmr">Packaging Marked Returnable</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"hasbatchnumber"} id="shr_has_batch_number" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="shr_has_batch_number">Has Batch Number</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"is_net_content_declared"} id="shr_is_net_content_declared" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="shr_is_net_content_declared">Is Net Content Declared</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isTradeItemAVariableUnit"} id="shr_is_variable_weight_item" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="shr_is_variable_weight_item">Is Variable Weight Item</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"market_with_ingredients"} id="shr_market_with_ingredients" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="shr_market_with_ingredients">Market With Ingredients</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isTradeItemAService"} id="shr_iti" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="iti">Is Trade Item</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12 col-sm-6 col-md-4">
                                        <div className="form-group">
                                            <div className="row">
                                                <div className="col-xs-8">
                                                    <div className="inline-checkbox tick">
                                                        <Field name={PREFIX+"vat_excempt"} id="shr_vatexempt" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                        <label htmlFor="vatexempt">VAT Exempt</label>
                                                    </div>
                                                </div>
                                                <div className="col-xs-4">
                                                    <Field placeholder="%" name={PREFIX+"vat_exempt_percentage"} id="shr_vat_exemp_percentage" component="input" type="text" className="form-control" readOnly={this.props.readonly_status} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"isTradeItemGeneticallyModified"} id="shr_gm" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="gm">Genetically Modified</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"dangerous_goods"} id="shr_dgoods" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="dgoods">Dangerous Goods</label>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="inline-checkbox tick">
                                                <Field name={PREFIX+"handlingInstructionCode"} id="shr_handlingins" component="input" type="checkbox" value="1" disabled={this.props.readonly_status} />
                                                <label htmlFor="handlingins">Handling Instructions</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {(this.props.user_type !== Config.userTypes.Retailer) ?
                    <div className="col-xs-12 col-sm-12 col-md-1">
                        <div className="saveform">
                        <Field name={PREFIX+'GUID'} component={Common.renderInput} type="hidden" id="shr_GUID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'shr')} status={this.props.readonly_status} ref="shr_GUID" />
                            <input name={PREFIX+'pID'} type="hidden" id="shr_pID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'shr')} status={this.props.readonly_status} ref="shr_pID" value={this.props.form_data.cu_pID}/>
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button type="submit" id="shr_status_save_option" className="btn-save" value="Save">Save</Button>
                            </div>
                            <div className="next_btn">
                                <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
                      :''}
                </div>
                <Modal id="product_options_modal_shr" {...this.state} updateValue={this.updateValue} handleClose={this.handleClose} updateOptions={this.updateOptions} />
            </div>
        )
    }
}