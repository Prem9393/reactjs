import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Button } from 'react-bootstrap';
import {Link} from 'react-router-dom'
import NutritionalInformation from '../../../../Components/NutritionalInformation'
import Config from '../../../../Config';
import Common from '../../../../Common';

let PREFIX ='shr_';

export default class Shrink extends Component {
    constructor(props) {
        super(props);
        this.languageSet = this.languageSet.bind(this);
        this.state ={
            shownut :false,
            selections_loaded: false,      
            shr_longProductDescription_en:'',
            shr_tradeItemFeatureBenefit1_en:'',
            shr_tradeItemFeatureBenefit2_en:'',
            shr_tradeItemFeatureBenefit3_en:'',
            shr_tradeItemFeatureBenefit4_en:'',
            shr_tradeItemFeatureBenefit5_en:'',
            shr_tradeItemFeatureBenefit6_en:'',
            shr_ConsumerUsageInstructions_en:'',
            shr_StorageUsageInstructions_en:'',
            shr_safetyWarnings_en: '',
            
            shr_longProductDescription_nl:'',
            shr_tradeItemFeatureBenefit1_nl:'',
            shr_tradeItemFeatureBenefit2_nl:'',
            shr_tradeItemFeatureBenefit3_nl:'',
            shr_tradeItemFeatureBenefit4_nl:'',
            shr_tradeItemFeatureBenefit5_nl:'',
            shr_tradeItemFeatureBenefit6_nl:'',
            shr_ConsumerUsageInstructions_nl:'',
            shr_StorageUsageInstructions_nl:'',
            shr_safetyWarnings_nl: '',
            
            shr_longProductDescription_xu:'',
            shr_tradeItemFeatureBenefit1_xu:'',
            shr_tradeItemFeatureBenefit2_xu:'',
            shr_tradeItemFeatureBenefit3_xu:'',
            shr_tradeItemFeatureBenefit4_xu:'',
            shr_tradeItemFeatureBenefit5_xu:'',
            shr_tradeItemFeatureBenefit6_xu:'',
            shr_ConsumerUsageInstructions_xu:'',
            shr_StorageUsageInstructions_xu:'',
            shr_safetyWarnings_xu: '',            
        }
    }

    static getDerivedStateFromProps(props, state) {
        if (props.form_data.hasOwnProperty('shr_GTIN')) {
 
             return {
                 selections_loaded: true,
                 shr_longProductDescription_en:(props.form_data.shr_longProductDescription_en ? props.form_data.shr_longProductDescription_en : '' ),
                 shr_tradeItemFeatureBenefit1_en:(props.form_data.shr_tradeItemFeatureBenefit1_en ? props.form_data.shr_tradeItemFeatureBenefit1_en : ''),
                 shr_tradeItemFeatureBenefit2_en:(props.form_data.shr_tradeItemFeatureBenefit2_en ? props.form_data.shr_tradeItemFeatureBenefit2_en : ''),
                 shr_tradeItemFeatureBenefit3_en:(props.form_data.shr_tradeItemFeatureBenefit3_en ? props.form_data.shr_tradeItemFeatureBenefit3_en : ''),
                 shr_tradeItemFeatureBenefit4_en:(props.form_data.shr_tradeItemFeatureBenefit4_en ? props.form_data.shr_tradeItemFeatureBenefit4_en : ''),
                 shr_tradeItemFeatureBenefit5_en:(props.form_data.shr_tradeItemFeatureBenefit5_en ? props.form_data.shr_tradeItemFeatureBenefit5_en : ''),
                 shr_tradeItemFeatureBenefit6_en:(props.form_data.shr_tradeItemFeatureBenefit6_en ? props.form_data.shr_tradeItemFeatureBenefit6_en : ''),
                 shr_ConsumerUsageInstructions_en:(props.form_data.shr_ConsumerUsageInstructions_en ? props.form_data.shr_ConsumerUsageInstructions_en : ''),
                 shr_StorageUsageInstructions_en:(props.form_data.shr_StorageUsageInstructions_en ? props.form_data.shr_StorageUsageInstructions_en : ''),
                 shr_safetyWarnings_en:(props.form_data.shr_safetyWarnings_en ? props.form_data.shr_safetyWarnings_en : ''),
                 
                 shr_longProductDescription_nl:(props.form_data.shr_longProductDescription_nl ? props.form_data.shr_longProductDescription_nl : '' ),
                 shr_tradeItemFeatureBenefit1_nl:(props.form_data.shr_tradeItemFeatureBenefit1_nl ? props.form_data.shr_tradeItemFeatureBenefit1_nl : ''),
                 shr_tradeItemFeatureBenefit2_nl:(props.form_data.shr_tradeItemFeatureBenefit2_nl ? props.form_data.shr_tradeItemFeatureBenefit2_nl : ''),
                 shr_tradeItemFeatureBenefit3_nl:(props.form_data.shr_tradeItemFeatureBenefit3_nl ? props.form_data.shr_tradeItemFeatureBenefit3_nl : ''),
                 shr_tradeItemFeatureBenefit4_nl:(props.form_data.shr_tradeItemFeatureBenefit4_nl ? props.form_data.shr_tradeItemFeatureBenefit4_nl : ''),
                 shr_tradeItemFeatureBenefit5_nl:(props.form_data.shr_tradeItemFeatureBenefit5_nl ? props.form_data.shr_tradeItemFeatureBenefit5_nl : ''),
                 shr_tradeItemFeatureBenefit6_nl:(props.form_data.shr_tradeItemFeatureBenefit6_nl ? props.form_data.shr_tradeItemFeatureBenefit6_nl : ''),
                 shr_ConsumerUsageInstructions_nl:(props.form_data.shr_ConsumerUsageInstructions_nl ? props.form_data.shr_ConsumerUsageInstructions_nl : ''),
                 shr_StorageUsageInstructions_nl:(props.form_data.shr_StorageUsageInstructions_nl ? props.form_data.shr_StorageUsageInstructions_nl : ''),
                 shr_safetyWarnings_nl:(props.form_data.shr_safetyWarnings_nl ? props.form_data.shr_safetyWarnings_nl : ''),
                 
                 shr_longProductDescription_xu:(props.form_data.shr_longProductDescription_xu ? props.form_data.shr_longProductDescription_xu : '' ),
                 shr_tradeItemFeatureBenefit1_xu:(props.form_data.shr_tradeItemFeatureBenefit1_xu ? props.form_data.shr_tradeItemFeatureBenefit1_xu : ''),
                 shr_tradeItemFeatureBenefit2_xu:(props.form_data.shr_tradeItemFeatureBenefit2_xu ? props.form_data.shr_tradeItemFeatureBenefit2_xu : ''),
                 shr_tradeItemFeatureBenefit3_xu:(props.form_data.shr_tradeItemFeatureBenefit3_xu ? props.form_data.shr_tradeItemFeatureBenefit3_xu : ''),
                 shr_tradeItemFeatureBenefit4_xu:(props.form_data.shr_tradeItemFeatureBenefit4_xu ? props.form_data.shr_tradeItemFeatureBenefit4_xu : ''),
                 shr_tradeItemFeatureBenefit5_xu:(props.form_data.shr_tradeItemFeatureBenefit5_xu ? props.form_data.shr_tradeItemFeatureBenefit5_xu : ''),
                 shr_tradeItemFeatureBenefit6_xu:(props.form_data.shr_tradeItemFeatureBenefit6_xu ? props.form_data.shr_tradeItemFeatureBenefit6_xu : ''),
                 shr_ConsumerUsageInstructions_xu:(props.form_data.shr_ConsumerUsageInstructions_xu ? props.form_data.shr_ConsumerUsageInstructions_xu : ''),
                 shr_StorageUsageInstructions_xu:(props.form_data.shr_StorageUsageInstructions_xu ? props.form_data.shr_StorageUsageInstructions_xu : ''),
                 shr_safetyWarnings_xu:(props.form_data.shr_safetyWarnings_xu ? props.form_data.shr_safetyWarnings_xu : ''),
             }
         } else {
             return true;
         }
     }

     languageSet(event){
        console.log("event",event);

        this.setState({[event.target.id]:event.target.value});
        
    }

    handleclicks = (e)  =>{
        e.preventDefault();
        let tabs = this.state.shownut
        this.setState({ shownut : (tabs) ? false :true  });
    }
    render() {

        
        // const { userSelectedLanguage } = this.props;
        const userSelectedLanguage  = 'EN';

        return (
            <div className="row">
                <div className="col-xs-12 col-md-3">
                    <div className="preview_div">
                        <div className="pdform_column last_coumn">
                            <div className="preview_title">
                                <p>Preview</p>
                            </div>
                            <div className="preview_img">
                            <img src={(this.props.form_data.hasOwnProperty('shr_image_name') && this.props.form_data.shr_image_name !== '' && this.props.form_data.shr_image_name != null && this.props.form_data.shr_image_name !== undefined && this.props.form_data.shr_image_name.length >= 1) ? Config.detail_img_path + this.props.form_data.shr_image_name : Config.assetspath + 'default.png'} alt="" />
                            </div>
                        </div>
                    </div>
                    <div className="selected_list_prew">
                        <div className="row">
                        <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Brand:</p>
                                    <p className="det preview_brand">{this.props.shr_details['shr_languageSpecificBrandName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Sub Brand</p>
                                    <p className="det preview_sub_brand">{this.props.shr_details['shr_Subbrand_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                        <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Functional Name:</p>
                                    <p className="det preview_functional">{this.props.shr_details['shr_FunctionalName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Variant:</p>
                                    <p className="det preview_variant">{this.props.shr_details['shr_Variant_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                        <div className="col-xs-12">
                                <div className="prwrow">
                                    <p className="title">Product Name:</p>
                                    <p className="det preview_product_name">{this.props.shr_details['shr_gtinName_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                        <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">GTIN:</p>
                                    <p className="det preview_gtin">{this.props.shr_details['shr_GTIN']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Size:</p>
                                    <p className="det preview_net">{this.props.shr_details['shr_NetContent']}</p>
                                </div>
                            </div>
                        </div>
                        {/* {this.props.form_data.shr_category_name==='Food' ?  <div className="prwrow">  <p className={ (this.state.shownut) ? this.state.shownut+'det hidden' : 'det ' } ><Link onClick={this.handleclicks} to="#" id="food_category">Nutritional Information</Link></p>
                            <p  className={ (this.state.shownut) ? this.state.shownut+'det ' : 'det hidden ' }><Link onClick={this.handleclicks} to="#" id="enrich_food">Enrich Content</Link></p> </div> : ''} */}
                        {this.props.form_data.shr_Category==='Food' ?  <div className="prwrow">  <p className={ (this.state.shownut) ? this.state.shownut+'det hidden' : 'det ' } ><Link onClick={this.handleclicks} to="#" id="food_category">Nutritional Information</Link></p>
                            <p  className={ (this.state.shownut) ? this.state.shownut+'det ' : 'det hidden ' }><Link onClick={this.handleclicks} to="#" id="enrich_food">Enrich Content</Link></p> </div> : ''}
                    </div>
                </div>
                <div className={ (this.state.shownut) ? this.state.shownut+'col-xs-12 col-sm-6 col-md-4 hidden' : 'col-xs-12 col-sm-6 col-md-4 ' }>
                    <div className="enrcih_des_fea lightgray">
                        <h4 className="ftitle">Long Product Description</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                
                                this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                <textarea 
                                key={index} 
                                    name={PREFIX+"longProductDescription["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    onChange={this.languageSet} 
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"shr_longProductDescription_"+lang.LanguageCode.toLowerCase().trim()} 
                                    placeholder={"Long Product Description "+lang.LanguageCode.trim()}
                                    component="textarea"
                                    value={this.state["shr_longProductDescription_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["shr_longProductDescription_"+lang.LanguageCode.toLowerCase().trim()] : ''}/>
                               
                                ) 
                            }
                            ) : ''
                         }

                            </div>
                        </div>
        
                        <h4 className="ftitle">Features & Benefits</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                    key={index} 
                                        name={PREFIX+"tradeItemFeatureBenefit1["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 1 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }
                            </div>
                        </div>


                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                    key={index} 
                                        name={PREFIX+"tradeItemFeatureBenefit2["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 2 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }

                            
                        </div>
                        </div>

                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input
                                    key={index}  
                                        name={PREFIX+"tradeItemFeatureBenefit3["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 3 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }
                            
                        </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                    key={index} 
                                        name={PREFIX+"tradeItemFeatureBenefit4["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 4 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }

                            
                        </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                    key={index} 
                                        name={PREFIX+"tradeItemFeatureBenefit5["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 5 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }
                            
                        </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                    key={index} 
                                        name={PREFIX+"tradeItemFeatureBenefit6["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"shr_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features 6 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["shr_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["shr_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }
                            
                            </div>
                        </div>
						
                        <h4 className="ftitle">Safety Warnings</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                {
                                this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                    <textarea 
                                    key={index} 
                                name={PREFIX+"safetyWarnings["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                onChange={this.languageSet} 
                                className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                id={"shr_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()}  
                                placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                component="textarea" 
                                value={this.state["shr_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["shr_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                               />

                                        ) 
                                    }
                                    ) : ''
                                }
                            
                        </div>
                        </div>

						
				
                    </div>
                </div>
                <div className={ (this.state.shownut) ? this.state.shownut+'col-xs-12 col-sm-6 col-md-4 hidden' : 'col-xs-12 col-sm-6 col-md-4 ' }>
                    <div className="enrcih_des_fea lightgray">
                        <h4 className="ftitle">Goes well with</h4>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith1"} className="form-control segwllw" id="shr_goes_well_with1" placeholder="Product 1" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith2"} className="form-control segwllw" id="shr_goes_well_with2" placeholder="Product 2" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith3"} className="form-control segwllw" id="shr_goes_well_with3" placeholder="Product 3" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith4"} className="form-control segwllw" id="shr_goes_well_with4" placeholder="Product 4" component="input" type="text" />
                        </div>
                        <h4 className="ftitle">Search Terms</h4><p>Separate by comma</p>
                        <div className="form-group">
                            <Field name={PREFIX+"search_terms"} className="form-control" id="shr_search_terms" placeholder="Keywords (Seperated by Commas)" component="input" type="text" />
                        </div>
                        <h4 className="ftitle">Consumer User Instructions</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}

                                {
                                this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                    <textarea
                                    key={index}  
                                        name={PREFIX+"ConsumerUsageInstrutions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                        id={"shr_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()} 
                                        placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                        component="textarea"  
                                        value={this.state["shr_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["shr_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] : ''} />
                                        ) 
                                    }
                                    ) : ''
                                }

                            
                        </div>
                        </div>
					
                        <h4 className="ftitle">Consumer Storage Instructions</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                { 
                                this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                    <textarea 
                                    key={index} 
                                    name={PREFIX+"StorageUsageInstructions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                    onChange={this.languageSet} 
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                    id= {"shr_StorageUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()} 
                                    placeholder={"Insert description here ("+userSelectedLanguage.trim()+")..." }
                                    component="textarea" 
                                    value={this.state["shr_StorageUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["shr_StorageUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] : ''}
                                     />
                                        ) 
                                    }
                                    ) : ''
                                }
                        </div>
                        </div>

                    </div>
                </div>
                {(this.state.shownut) ? <NutritionalInformation/> : ''}
                {(this.props.user_type !== Config.userTypes.Retailer) ?
                <div className="col-xs-12 col-md-1">
                    <div className="adv_column"  id="adv_column" style={{height: '900px'}}>
                        <div className="adv_section">
                            <img src="assets/images/google_adwrd.jpg" alt="" />
                        </div>
                        <div className="saveform">
                        {/* <Field name={PREFIX+'GUID'} component={Common.renderInput} type="text" id="shr_GUID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'shr')} status={this.props.readonly_status} ref="shr_GUID" />
                            <Field name={PREFIX+'pID'} component={Common.renderInput} type="text" id="shr_GUID" className="form-control hsmall hide" onBlur={this.props.handleChange.bind(this, 'shr')} status={this.props.readonly_status} ref="shr_pID" /> */}
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button type="submit" className="btn-save" value="Save">Save</Button>
                            </div>
                            <div className="next_btn">
                                <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
                </div>
                : ''}
            </div>
        )
    }
}