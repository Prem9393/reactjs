import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import NutritionalInformation from '../../../../Components/NutritionalInformation';
import Config from '../../../../Config';
import Television from '../../../../Components/Television';
import Refrigerator from '../../../../Components/Refrigerator';
import Computers from '../../../../Components/Computers';
import Common from '../../../../Common';
let PREFIX ='cu_';

export default class ConsumerUnit extends Component {
    constructor(props) {
        super(props);
        this.handleNutritionValue = this.handleNutritionValue.bind(this);
        this.languageSet = this.languageSet.bind(this);
        this.state = {
            shownut: false,
            showtelevision: false,
            showcomputers: false,
            showrefrigerator: false,
            showcontent: true,
            nutrition:[],                  
            selections_loaded: false,      
            cu_longProductDescription_en:'',
            cu_tradeItemFeatureBenefit1_en:'',
            cu_tradeItemFeatureBenefit2_en:'',
            cu_tradeItemFeatureBenefit3_en:'',
            cu_tradeItemFeatureBenefit4_en:'',
            cu_tradeItemFeatureBenefit5_en:'',
            cu_tradeItemFeatureBenefit6_en:'',
            cu_ConsumerUsageInstructions_en:'',
            cu_StorageUsageInstructions_en:'',
            cu_safetyWarnings_en: '',
            
            cu_longProductDescription_nl:'',
            cu_tradeItemFeatureBenefit1_nl:'',
            cu_tradeItemFeatureBenefit2_nl:'',
            cu_tradeItemFeatureBenefit3_nl:'',
            cu_tradeItemFeatureBenefit4_nl:'',
            cu_tradeItemFeatureBenefit5_nl:'',
            cu_tradeItemFeatureBenefit6_nl:'',
            cu_ConsumerUsageInstructions_nl:'',
            cu_StorageUsageInstructions_nl:'',
            cu_safetyWarnings_nl: '',

            cu_longProductDescription_xu:'',
            cu_tradeItemFeatureBenefit1_xu:'',
            cu_tradeItemFeatureBenefit2_xu:'',
            cu_tradeItemFeatureBenefit3_xu:'',
            cu_tradeItemFeatureBenefit4_xu:'',
            cu_tradeItemFeatureBenefit5_xu:'',
            cu_tradeItemFeatureBenefit6_xu:'',
            cu_ConsumerUsageInstructions_xu:'',
            cu_StorageUsageInstructions_xu:'',
            cu_safetyWarnings_xu: '',
        }

      

    }

    
    handleNutritionValue(_datas){
        var _nutrition_details ={
            token:_datas.token,
            gtin:_datas.gtin,
        }
        if(_datas.serving_size) {
            _nutrition_details.serving_size = _datas.serving_size;
        }
        this.props.loadNutritionData(_nutrition_details);
    }

    componentDidMount(){
        var _nutrition_details ={
            token:this.props.token,
            gtin:this.props.match.params.gtin,
        }
       this.handleNutritionValue(_nutrition_details);
     }
    
     languageSet(event){
    
        this.setState({[event.target.id]:event.target.value});
        
    }

    static getDerivedStateFromProps(props, state) {
        if (props.form_data.hasOwnProperty('cu_GTIN') && !state.selections_loaded) {

            return {
                selections_loaded: true,
                cu_longProductDescription_en:(props.form_data.cu_longProductDescription_en ? props.form_data.cu_longProductDescription_en : '' ),
                cu_tradeItemFeatureBenefit1_en:(props.form_data.cu_tradeItemFeatureBenefit1_en ? props.form_data.cu_tradeItemFeatureBenefit1_en : ''),
                cu_tradeItemFeatureBenefit2_en:(props.form_data.cu_tradeItemFeatureBenefit2_en ? props.form_data.cu_tradeItemFeatureBenefit2_en : ''),
                cu_tradeItemFeatureBenefit3_en:(props.form_data.cu_tradeItemFeatureBenefit3_en ? props.form_data.cu_tradeItemFeatureBenefit3_en : ''),
                cu_tradeItemFeatureBenefit4_en:(props.form_data.cu_tradeItemFeatureBenefit4_en ? props.form_data.cu_tradeItemFeatureBenefit4_en : ''),
                cu_tradeItemFeatureBenefit5_en:(props.form_data.cu_tradeItemFeatureBenefit5_en ? props.form_data.cu_tradeItemFeatureBenefit5_en : ''),
                cu_tradeItemFeatureBenefit6_en:(props.form_data.cu_tradeItemFeatureBenefit6_en ? props.form_data.cu_tradeItemFeatureBenefit6_en : ''),
                cu_ConsumerUsageInstructions_en:(props.form_data.cu_ConsumerUsageInstructions_en ? props.form_data.cu_ConsumerUsageInstructions_en : ''),
                cu_StorageUsageInstructions_en:(props.form_data.cu_StorageUsageInstructions_en ? props.form_data.cu_StorageUsageInstructions_en : ''),
                cu_safetyWarnings_en:(props.form_data.cu_safetyWarnings_en ? props.form_data.cu_safetyWarnings_en : ''),
                
                cu_longProductDescription_nl:(props.form_data.cu_longProductDescription_nl ? props.form_data.cu_longProductDescription_nl : '' ),
                cu_tradeItemFeatureBenefit1_nl:(props.form_data.cu_tradeItemFeatureBenefit1_nl ? props.form_data.cu_tradeItemFeatureBenefit1_nl : ''),
                cu_tradeItemFeatureBenefit2_nl:(props.form_data.cu_tradeItemFeatureBenefit2_nl ? props.form_data.cu_tradeItemFeatureBenefit2_nl : ''),
                cu_tradeItemFeatureBenefit3_nl:(props.form_data.cu_tradeItemFeatureBenefit3_nl ? props.form_data.cu_tradeItemFeatureBenefit3_nl : ''),
                cu_tradeItemFeatureBenefit4_nl:(props.form_data.cu_tradeItemFeatureBenefit4_nl ? props.form_data.cu_tradeItemFeatureBenefit4_nl : ''),
                cu_tradeItemFeatureBenefit5_nl:(props.form_data.cu_tradeItemFeatureBenefit5_nl ? props.form_data.cu_tradeItemFeatureBenefit5_nl : ''),
                cu_tradeItemFeatureBenefit6_nl:(props.form_data.cu_tradeItemFeatureBenefit6_nl ? props.form_data.cu_tradeItemFeatureBenefit6_nl : ''),
                cu_ConsumerUsageInstructions_nl:(props.form_data.cu_ConsumerUsageInstructions_nl ? props.form_data.cu_ConsumerUsageInstructions_nl : ''),
                cu_StorageUsageInstructions_nl:(props.form_data.cu_StorageUsageInstructions_nl ? props.form_data.cu_StorageUsageInstructions_nl : ''),
                cu_safetyWarnings_nl:(props.form_data.cu_safetyWarnings_nl ? props.form_data.cu_safetyWarnings_nl : ''),
                
                cu_longProductDescription_xu:(props.form_data.cu_longProductDescription_xu ? props.form_data.cu_longProductDescription_xu : '' ),
                cu_tradeItemFeatureBenefit1_xu:(props.form_data.cu_tradeItemFeatureBenefit1_xu ? props.form_data.cu_tradeItemFeatureBenefit1_xu : ''),
                cu_tradeItemFeatureBenefit2_xu:(props.form_data.cu_tradeItemFeatureBenefit2_xu ? props.form_data.cu_tradeItemFeatureBenefit2_xu : ''),
                cu_tradeItemFeatureBenefit3_xu:(props.form_data.cu_tradeItemFeatureBenefit3_xu ? props.form_data.cu_tradeItemFeatureBenefit3_xu : ''),
                cu_tradeItemFeatureBenefit4_xu:(props.form_data.cu_tradeItemFeatureBenefit4_xu ? props.form_data.cu_tradeItemFeatureBenefit4_xu : ''),
                cu_tradeItemFeatureBenefit5_xu:(props.form_data.cu_tradeItemFeatureBenefit5_xu ? props.form_data.cu_tradeItemFeatureBenefit5_xu : ''),
                cu_tradeItemFeatureBenefit6_xu:(props.form_data.cu_tradeItemFeatureBenefit6_xu ? props.form_data.cu_tradeItemFeatureBenefit6_xu : ''),
                cu_ConsumerUsageInstructions_xu:(props.form_data.cu_ConsumerUsageInstructions_xu ? props.form_data.cu_ConsumerUsageInstructions_xu : ''),
                cu_StorageUsageInstructions_xu:(props.form_data.cu_StorageUsageInstructions_xu ? props.form_data.cu_StorageUsageInstructions_xu : ''),
                cu_safetyWarnings_xu:(props.form_data.cu_safetyWarnings_xu ? props.form_data.cu_safetyWarnings_xu : ''),
            }
        } else {
            return true;
        }
    }

    // handleclicks = (e) => {
    //     e.preventDefault();
    //     let tabs = this.state.shownut
    //     this.setState({ shownut: (tabs) ? false : true });
    // }
    handleViews = (view, e) => {
        e.preventDefault();
        if (view === 'television') {
            this.setState({
                showcontent: !this.state.showcontent,
                showtelevision: !this.state.showtelevision
            });
        } else if (view === 'computers') {
            this.setState({
                showcontent: !this.state.showcontent,
                showcomputers: !this.state.showcomputers
            });
        } else if (view === 'refrigerator') {
            this.setState({
                showcontent: !this.state.showcontent,
                showrefrigerator: !this.state.showrefrigerator
            });
        }else if (view === 'nutrition') {
            this.setState({
                showcontent: !this.state.showcontent,
                shownut: !this.state.shownut
            });
        } else {
            this.setState({
                shownut: false,
                showtelevision: false,
                showcomputers: false,
                showrefrigerator: false,
                showcontent: true
            });
        }
    }
    render() {

        // const { userSelectedLanguage } = this.props;
        const userSelectedLanguage  = 'EN';

        return (
            <div className="row">
                <div className="col-xs-12 col-md-3">
                    <div className="preview_div">
                        <div className="pdform_column last_coumn">
                            <div className="preview_title">
                                <p>Preview</p>
                            </div>
                            <div className="preview_img">
                                <img src={(this.props.form_data.hasOwnProperty('cu_image_name') && this.props.form_data.cu_image_name !== '' && this.props.form_data.cu_image_name !== undefined && this.props.form_data.cu_image_name != null && this.props.form_data.cu_image_name.length >= 1) ? Config.detail_img_path + this.props.form_data.cu_image_name : Config.assetspath + 'default.png'} alt="" />
                            </div>
                        </div>
                    </div>
                    <div className="selected_list_prew">
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Brand:</p>
                                    <p className="det preview_brand">{this.props.cu_details['cu_languageSpecificBrandName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Sub Brand</p>
                                    <p className="det preview_sub_brand">{this.props.cu_details['cu_Subbrand_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Functional Name:</p>
                                    <p className="det preview_functional">{this.props.cu_details['cu_FunctionalName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Variant:</p>
                                    <p className="det preview_variant">{this.props.cu_details['cu_Variant_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-12">
                                <div className="prwrow">
                                    <p className="title">Product Name:</p>
                                    <p className="det preview_product_name">{this.props.cu_details['cu_gtinName_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">GTIN:</p>
                                    <p className="det preview_gtin">{this.props.cu_details['cu_GTIN']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Size:</p>
                                    <p className="det preview_net">{this.props.cu_details['cu_NetContent']} {this.props.cu_details['cu_NetContentUOM']}</p>
                                </div>
                            </div>
                           
                        </div>
                        
                        {(this.props.form_data.hasOwnProperty('cu_Category') && this.props.form_data.cu_Category != null && this.props.form_data.cu_Category === '50000000') 
                            ? <div className="prwrow">  
                                <p className={(this.state.shownut) ? this.state.shownut + 'det hidden' : 'det '} ><Link onClick={this.handleViews.bind(this, 'nutrition')} to="#">Nutritional Information</Link></p>
                                <p className={(this.state.shownut) ? this.state.shownut + 'det ' : 'det hidden '}><Link onClick={this.handleViews.bind(this, 'nutrition')} to="#">Enrich Content</Link></p> </div> : ''}
                        
                        {(this.props.form_data.hasOwnProperty('cu_gpc_cat_code') && this.props.form_data.cu_gpc_cat_code === '100014')
                            ? <div className="prwrow">
                                <p className={(this.state.showtelevision) ? this.state.showtelevision + 'det hidden' : 'det '} ><Link onClick={this.handleViews.bind(this, 'television')} to="#" id="gmd_television_category"> Television Attributes</Link></p>
                                <p className={(this.state.showtelevision) ? this.state.showtelevision + 'det ' : 'det hidden '}><Link onClick={this.handleViews.bind(this, 'television')} to="#"> Television Enrich Content</Link></p> </div> : ''}
 
                        
                        {(this.props.form_data.cu_Category!= null && this.props.form_data.hasOwnProperty('cu_Category') && this.props.form_data.hasOwnProperty('cu_SubCategory') && this.props.form_data.cu_Category.toLowerCase() === 'general merchandise' && this.props.form_data.cu_SubCategory.toLowerCase() === 'television')
                            ? <div className="prwrow">
                                <p className={(this.state.showtelevision) ? this.state.showtelevision + 'det hidden' : 'det '} ><Link onClick={this.handleViews.bind(this, 'television')} to="#" id="gmd_television_category">GMD Television Attributes</Link></p>
                                <p className={(this.state.showtelevision) ? this.state.showtelevision + 'det ' : 'det hidden '}><Link onClick={this.handleViews.bind(this, 'television')} to="#">GMD Television Enrich Content</Link></p> </div> : ''}

                        {(this.props.form_data.cu_Category!= null && this.props.form_data.hasOwnProperty('cu_Category') && this.props.form_data.hasOwnProperty('cu_SubCategory') && this.props.form_data.cu_Category.toLowerCase() === 'general merchandise' && this.props.form_data.cu_SubCategory.toLowerCase() === 'computers')
                            ? <div className="prwrow">
                                <p className={(this.state.showcomputers) ? this.state.showcomputers + 'det hidden' : 'det '} ><Link onClick={this.handleViews.bind(this, 'computers')} to="#" id="gmd_computer_category">GMD Television Attributes</Link></p>
                                <p className={(this.state.showcomputers) ? this.state.showcomputers + 'det ' : 'det hidden '}><Link onClick={this.handleViews.bind(this, 'computers')} to="#">GMD Television Enrich Content</Link></p> </div> : ''}


                        {(this.props.form_data.cu_Category!= null && this.props.form_data.hasOwnProperty('cu_Category') && this.props.form_data.hasOwnProperty('cu_SubCategory') && this.props.form_data.cu_Category.toLowerCase() === 'general merchandise' && this.props.form_data.cu_SubCategory.toLowerCase() === 'refrigerator')
                            ? <div className="prwrow">
                                <p className={(this.state.showrefrigerator) ? this.state.showrefrigerator + 'det hidden' : 'det '} ><Link onClick={this.handleViews.bind(this, 'refrigerator')} to="#" id="gmd_computer_category">GMD Refrigerator Attributes</Link></p>
                                <p className={(this.state.showrefrigerator) ? this.state.showrefrigerator + 'det ' : 'det hidden '}><Link onClick={this.handleViews.bind(this, 'refrigerator')} to="#">GMD Refrigerator Enrich Content</Link></p> </div> : ''}
                    </div>
                </div>
                <div className={(!this.state.showcontent) ? 'col-xs-12 col-sm-6 col-md-4 hidden' : 'col-xs-12 col-sm-6 col-md-4 '}>

                    <div className="enrcih_des_fea lightgray">

                        <h4 className="ftitle">Long Product Description</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}

                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                <textarea 
                                     key={index} 
                                    name={PREFIX+"longProductDescription["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    onChange={this.languageSet} 
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"cu_longProductDescription_"+lang.LanguageCode.toLowerCase().trim()} 
                                    placeholder={"Long Product Description "+lang.LanguageCode.trim()}
                                    component="textarea"
                                    value={this.state["cu_longProductDescription_"+"_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["cu_longProductDescription_"+"_"+lang.LanguageCode.toLowerCase().trim()] : ''}/>
                               
                                ) 
                            }
                            ) : ''
                         }
                            </div>
                        </div>
                        

                    
                        <h4 className="ftitle">Features & Benefits</h4>
                     <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                    { 
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 

                                    <input 
                                        key={index}  
                                        name={PREFIX+"tradeItemFeatureBenefit1["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                        id={"cu_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()}  
                                        placeholder={"Features1 "+lang.LanguageCode.trim()}
                                        component="input"
                                        type="text" 
                                        value={this.state["cu_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                        this.state["cu_tradeItemFeatureBenefit1_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                    />
                                    ) 
                                  }
                                ) : ''
                             }
                            </div>
                        </div>

                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                 {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}

                                 {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                        <input 
                                        key={index} 
                                            name={PREFIX+"tradeItemFeatureBenefit2["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                            onChange={this.languageSet} 
                                            className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 
                                            'form-control hide': "form-control" }
                                            id={"cu_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()} 
                                            placeholder={"Features 2 "+lang.LanguageCode.trim()}
                                            component="input" 
                                            type="text" 
                                            value={this.state["cu_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                            this.state["cu_tradeItemFeatureBenefit2_"+lang.LanguageCode.toLowerCase().trim()]: ''} 
                                         />
                                    
                                        ) 
                                    }
                                    ) : ''
                                }

      
                            </div>
                        </div>

                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                        <input key={index} 
                                            name={PREFIX+"tradeItemFeatureBenefit3["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                            onChange={this.languageSet} 
                                            className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 
                                            'form-control hide': "form-control" }
                                            id={"cu_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()} 
                                            placeholder={"Features 3 "+lang.LanguageCode.trim()}
                                            component="input" 
                                            type="text" 
                                            value={this.state["cu_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                            this.state["cu_tradeItemFeatureBenefit3_"+lang.LanguageCode.toLowerCase().trim()]: ''} 
                                         />
                                    
                                        ) 
                                    }
                                    ) : ''
                                }
                             
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                        <input  key={index} 
                                            name={PREFIX+"tradeItemFeatureBenefit4["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                            onChange={this.languageSet} 
                                            className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 
                                            'form-control hide': "form-control" }
                                            id={"cu_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()} 
                                            placeholder={"Features 4 "+lang.LanguageCode.trim()}
                                            component="input" 
                                            type="text" 
                                            value={this.state["cu_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                            this.state["cu_tradeItemFeatureBenefit4_"+lang.LanguageCode.toLowerCase().trim()]: ''} 
                                         />
                                    
                                        ) 
                                    }
                                    ) : ''
                                }
                                
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                        <input key={index} 
                                            name={PREFIX+"tradeItemFeatureBenefit5["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                            onChange={this.languageSet} 
                                            className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 
                                            'form-control hide': "form-control" }
                                            id={"cu_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()} 
                                            placeholder={"Features 5 "+lang.LanguageCode.trim()}
                                            component="input" 
                                            type="text" 
                                            value={this.state["cu_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                            this.state["cu_tradeItemFeatureBenefit5_"+lang.LanguageCode.toLowerCase().trim()]: ''} 
                                         />
                                    
                                        ) 
                                    }
                                    ) : ''
                                }

                                
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                        <input key={index} 
                                            name={PREFIX+"tradeItemFeatureBenefit6["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                            onChange={this.languageSet} 
                                            className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 
                                            'form-control hide': "form-control" }
                                            id={"cu_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()} 
                                            placeholder={"Features 6 "+lang.LanguageCode.trim()}
                                            component="input" 
                                            type="text" 
                                            value={this.state["cu_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()] ? 
                                            this.state["cu_tradeItemFeatureBenefit6_"+lang.LanguageCode.toLowerCase().trim()]: ''} 
                                         />
                                    
                                        ) 
                                    }
                                    ) : ''
                                }
                                
                            </div>
                        </div>  
						
				    
						
                        <h4 className="ftitle">Safety Warnings</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}

                                {
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                    this.props.languagelist.map( (lang, index)=>{
                                    return ( 
                                        <textarea 
                                        key={index} 
                                    name={PREFIX+"safetyWarnings["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                    onChange={this.languageSet} 
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                    id={"cu_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()}  
                                    placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                    component="textarea" 
                                    value={this.state["cu_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["cu_safetyWarnings_"+lang.LanguageCode.toLowerCase().trim()] : ''} 
                                   />

                                            ) 
                                        }
                                        ) : ''
                                }

                                
                            </div>
                        </div>
						
                    </div>
                </div>

                <div className={(!this.state.showcontent) ? 'col-xs-12 col-sm-6 col-md-4 hidden' : 'col-xs-12 col-sm-6 col-md-4 '}>
                    <div className="enrcih_des_fea lightgray">
                        <h4 className="ftitle">Goes well with</h4>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith1"} className="form-control segwllw" id="cu_goes_well_with1" placeholder="Product 1" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith2"} className="form-control segwllw" id="cu_goes_well_with2" placeholder="Product 2" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith3"} className="form-control segwllw" id="cu_goes_well_with3" placeholder="Product 3" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith4"} className="form-control segwllw" id="cu_goes_well_with4" placeholder="Product 4" component="input" type="text" />
                        </div>
                        <h4 className="ftitle">Search Terms</h4><p>Separate by comma</p>
                        <div className="form-group">
                            <Field name={PREFIX+"search_terms"} className="form-control" id="cu_search_terms" placeholder="Keywords (Seperated by Commas)" component="input" type="text" />
                        </div>

                        <h4 className="ftitle">Consumer User Instructions</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span>  */}

                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                this.props.languagelist.map( (lang, index)=>{
                                return ( 
                                    <textarea 
                                    key={index} 
                                        name={PREFIX+"ConsumerUsageInstructions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                        id={"cu_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()} 
                                        placeholder={"Consumer User Instructions ("+lang.LanguageCode.trim()+")" }
                                        component="textarea"  
                                        value={this.state["cu_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["cu_ConsumerUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()] : ''} />
                                        ) 
                                    }
                                    ) : ''
                                }

                              
                            </div>
                        </div>
				
                        <h4 className="ftitle">Consumer Storage Instructions</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">                                
                                {/* <span className="input-group-addon">{userSelectedLanguage}</span> */}

                                {
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                    this.props.languagelist.map( (lang, index)=>{
                                    return ( 
                                        <textarea 
                                        key={index} 
                                        name={PREFIX+"StorageUsageInstructions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        onChange={this.languageSet} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" } 
                                        id= {"cu_StorageUsageInstructions_"+lang.LanguageCode.toLowerCase().trim()} 
                                        placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                        component="textarea" 
                                        value={this.state["cu_StorageUsageInstructions_"+"_"+lang.LanguageCode.toLowerCase().trim()] ? this.state["cu_StorageUsageInstructions_"+"_"+lang.LanguageCode.toLowerCase().trim()] : ''}
                                        />
                                            ) 
                                        }
                                        ) : ''
                                 }
                            </div>
                        </div>
					
                    </div>
                </div>
                {(this.state.shownut) ? <NutritionalInformation handleNutritionValue={this.handleNutritionValue} nutritions={this.props.nutritions} {...this.props} /> : ''}
                {(this.state.showtelevision) ? <Television /> : ''}
                {(this.state.showcomputers) ? <Computers /> : ''}
                {(this.state.showrefrigerator) ? <Refrigerator /> : ''}
                {(this.props.user_type !== Config.userTypes.Retailer) ?
                <div className="col-xs-12 col-md-1">
                    <div className="adv_column" id="adv_column" style={{ height: '900px' }}>
                        <div className="adv_section">
                            <img src="assets/images/google_adwrd.jpg" alt="" />
                        </div>
                        <div className="saveform">
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button type="submit" className="btn-save" value="Save">Save</Button>
                            </div>
                            <div className="next_btn">
                                <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
                </div>
                : ''}
            </div>
        )
    }
}