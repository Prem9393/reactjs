import React, { Component } from 'react';
import { Button, Panel } from 'react-bootstrap';
import CarouselComponent from '../../../../Components/Carousel';

const FeatureBenifits = (props) => {
    let details_main = '';
    
    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit1_en') && (props.details['pallet_tradeItemFeatureBenefit1_en']) !== ''  && (props.details['pallet_tradeItemFeatureBenefit1_en']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit1_en']+'</li>';
    }

    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit2_en') && (props.details['pallet_tradeItemFeatureBenefit2_en']) !== ''  && (props.details['pallet_features2']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit2_en']+'</li>';
    }


    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit3_en') && (props.details['pallet_tradeItemFeatureBenefit2_en']) !== ''  && (props.details['pallet_tradeItemFeatureBenefit3_en']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit3_en']+'</li>';
    }

    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit4_en') && (props.details['pallet_tradeItemFeatureBenefit4_en']) !== ''  && (props.details['pallet_tradeItemFeatureBenefit4_en']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit4_en']+'</li>';
    }

    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit5_en') && (props.details['pallet_tradeItemFeatureBenefit5_en']) !== ''  && (props.details['pallet_tradeItemFeatureBenefit5_en']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit5_en']+'</li>';
    }

    if(props.details.hasOwnProperty('pallet_tradeItemFeatureBenefit6_en') && (props.details['pallet_tradeItemFeatureBenefit6_en']) !== ''  && (props.details['pallet_tradeItemFeatureBenefit6_en']) !== null){
        details_main = details_main + '<li>'+props.details['pallet_tradeItemFeatureBenefit6_en']+'</li>';
    }
    return <ul dangerouslySetInnerHTML={{__html:  details_main}} />;
}

export default class Pallet extends Component {
    render() {
        return (
            <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-4">
                    <div className="product_reviewslider">
                    <CarouselComponent images={(this.props.product_details.hasOwnProperty('pallet_image') && this.props.product_details.pallet_image) ? this.props.product_details.pallet_image : this.props.images} />
                    </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-7">
                    <div className="previewacc darkgryhead" id="pallet_previewacc">
                        <Panel id="pallet_collapsible-panel-1" defaultExpanded>
                            <Panel.Heading>
                                <Panel.Title toggle>Product Information</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>
                                    <div className="prwrow">
                                        <p className="title">Brand:</p>
                                        <p className="det preview_brand">{this.props.pallet_details['pallet_languageSpecificBrandName_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Product Name:</p>
                                        <p className="det preview_product_name">{this.props.pallet_details['pallet_gtinName_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Long Product Description</p>
                                        <p className="det_des preview_long_desc">{this.props.pallet_details['pallet_longProductDescription_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Features & Benefits</p>
                                        <div className="product_review feature_benefits">
                                            <FeatureBenifits details={this.props.pallet_details} />
                                        </div>
                                    </div>
                                </Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="pallet_collapsible-panel-2">
                            <Panel.Heading>
                                <Panel.Title toggle>Logistical Information</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="pallet_collapsible-panel-3">
                            <Panel.Heading>
                                <Panel.Title toggle>Product Label</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="pallet_collapsible-panel-4">
                            <Panel.Heading>
                                <Panel.Title toggle>Supplier Details</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>
                    </div>
                </div>
                <div className="col-xs-12 col-md-1">
                    <div className="adv_column">
                        <div className="saveform">
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button className="btn btn-save" name="pallet_save_status" value="Save" type="submit">Save</Button>
                            </div>
                            <div className="submit_btn">
                                <Button className="btn btn-submit" name="pallet_submit_status" value="Submit / Approve" type="submit">Submit / Approve</Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}