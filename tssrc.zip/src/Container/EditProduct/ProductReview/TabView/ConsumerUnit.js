import React, { Component } from 'react';
import { Button, Panel } from 'react-bootstrap';
import CarouselComponent from '../../../../Components/Carousel';
import Config from '../../../../Config';

const FeatureBenifits = (props) => {
    let details_main = '';
    
    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit1_en') && (props.details['cu_tradeItemFeatureBenefit1_en']) !== ''  && (props.details['cu_tradeItemFeatureBenefit1_en']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit1_en']+'</li>';
    }

    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit2_en') && (props.details['cu_tradeItemFeatureBenefit2_en']) !== ''  && (props.details['cu_features2']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit2_en']+'</li>';
    }


    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit3_en') && (props.details['cu_tradeItemFeatureBenefit2_en']) !== ''  && (props.details['cu_tradeItemFeatureBenefit3_en']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit3_en']+'</li>';
    }

    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit4_en') && (props.details['cu_tradeItemFeatureBenefit4_en']) !== ''  && (props.details['cu_tradeItemFeatureBenefit4_en']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit4_en']+'</li>';
    }

    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit5_en') && (props.details['cu_tradeItemFeatureBenefit5_en']) !== ''  && (props.details['cu_tradeItemFeatureBenefit5_en']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit5_en']+'</li>';
    }

    if(props.details.hasOwnProperty('cu_tradeItemFeatureBenefit6_en') && (props.details['cu_tradeItemFeatureBenefit6_en']) !== ''  && (props.details['cu_tradeItemFeatureBenefit6_en']) !== null){
        details_main = details_main + '<li>'+props.details['cu_tradeItemFeatureBenefit6_en']+'</li>';
    }
    return <ul dangerouslySetInnerHTML={{__html:  details_main}} />;
}

export default class ConsumerUnit extends Component {
    render() {
        return (
            <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-4">
                    <div className="product_reviewslider">
                        <CarouselComponent images={(this.props.product_details.hasOwnProperty('cu_image') && this.props.product_details.cu_image.length) ? this.props.product_details.cu_image : this.props.images} />
                    </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-7">
                    <div className="previewacc darkgryhead" id="cu_previewacc">
                        <Panel id="cu_collapsible-panel-1" defaultExpanded>
                            <Panel.Heading>
                                <Panel.Title toggle>Product Information</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>
                                <div className="prwrow">
                                        <p className="title">Brand:</p>
                                        <p className="det preview_brand">{this.props.cu_details['cu_languageSpecificBrandName_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Product Name:</p>
                                        <p className="det preview_product_name">{this.props.cu_details['cu_gtinName_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Long Product Description</p>
                                        <p className="det_des preview_long_desc">{this.props.cu_details['cu_longProductDescription_en']}</p>
                                    </div>
                                    <div className="prwrow">
                                        <p className="title">Features & Benefits</p>
                                        <div className="product_review feature_benefits">
                                                <FeatureBenifits details={this.props.cu_details} />
                                        </div>
                                    </div>
                                </Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="cu_collapsible-panel-2">
                            <Panel.Heading>
                                <Panel.Title toggle>Logistical Information</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="cu_collapsible-panel-3">
                            <Panel.Heading>
                                <Panel.Title toggle>Product Label</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>

                        <Panel id="cu_collapsible-panel-4">
                            <Panel.Heading>
                                <Panel.Title toggle>Supplier Details</Panel.Title>
                            </Panel.Heading>
                            <Panel.Collapse>
                                <Panel.Body>-</Panel.Body>
                            </Panel.Collapse>
                        </Panel>
                    </div>
                </div>
                {(this.props.user_type !== Config.userTypes.Retailer) ?
                <div className="col-xs-12 col-md-1">
                    <div className="adv_column">
                        <div className="saveform">
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button className="btn btn-save" name="cu_save_status" value="Save" type="submit">Save</Button>
                            </div>
                            <div className="submit_btn">
                                <Button className="btn btn-submit" name="cu_submit_status" value="Submit / Approve" type="submit">Submit / Approve</Button>
                                {/* <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button> */}
                            </div>
                        </div>
                    </div>
                </div>
                 : ''}
            </div>
        )
    }
}