import React, { Component } from 'react';
import Config from '../../Config';
import {Provider, connect} from 'react-redux';

import InsertForm from './InsertUser';
import InsertUserCompanyDetails from './InsertUserCompanyDetails';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';

const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    token:state.auth.token,
    user_type:state.auth.user_type,
    id:state.auth.id,
    companylisting:state.companylist.companylisting,
    insertcode:state.insertuser.insertcode,
    insertdisplaystatus: state.insertuser.insertdisplaystatus,
    languagelisting: state.languagelisting.languagelisting
})


const mapDispatchToProps = (dispatch) => ({
    InsertUser: (values) => dispatch(ActionCreators.InsertUser(values)),
    CompanyListing: (values) => dispatch(ActionCreators.CompanyListing(values)),
    getLanguageCode: (values) => dispatch(ActionCreators.getLanguageCode(values)),
})
  
const InsertUserComponent  = connect(mapStateToProps, mapDispatchToProps)(InsertForm);



class InsertUser extends Component {
    
    componentDidMount(){
        document.title=Config.name+' Insert User';
    }
    render(){
        return  <Provider store={AppStore}><InsertUserComponent/></Provider>
    }
}


export default InsertUser;


