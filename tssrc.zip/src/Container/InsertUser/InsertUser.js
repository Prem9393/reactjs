import React, { Component } from 'react';
import { reduxForm, Field, isInvalid, getFormValues } from 'redux-form';
import { Button } from 'react-bootstrap';
import Common from '../../Common';
import Config from '../../Config';
import Validation from '../../Validations';
import {Redirect, Link}  from 'react-router-dom';
import serialize from 'form-serialize';
import Select from 'react-select';
import RenderSelect from '../../Components/SelectField';
import FileBase64 from 'react-file-base64';
import { FormErrors } from '../../FormErrors';
import Loader from '../../Components/Loader';
import ActionCreators from '../../Actions/ActionCreators'
import {connect} from 'react-redux';
import { normalizeNumberAndSetLimit } from '../../Validations';
import { Tabs, Tab } from 'react-bootstrap';


class InsertUser extends Component {
    constructor(props, context) {
        //console.log("insert props",props);
        super(props, context);
        this.handleSelect = this.handleSelect.bind(this);
        this.state = {
            actionkey: 1,
            files:'',
            id: props.id,
            select_options: [
                {label: 'Select User Type', value: ''},
                {label: 'Supplier', value: '1'},
                {label: 'Retailer', value: '2'},
                {label: 'GS1User', value: '3'},
                {label: 'TrustedSource', value: '4'},
            ],
            select_company: [],
            first_name: '',
            last_name: '',            
            email: false,
            password: false,
            user_name: false,
            user_telephone: false,
            is_loaded: false,
            insertUserCode: false,
            isLoading: true,
            selectedCompany:""
        };
    }

    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;    
    }

    componentWillMount(){

     this.props.dispatch(ActionCreators.insertdisplaystatusOff());
     this.setState({isLoading: false })
        //this.setState({insertUserCode: true})
        //{ console.log("isLoading", this.state.isLoading)}   
     }

    componentDidMount() {
        
        this.setState({insertUserCode: true, isLoading: false})
        this.props.CompanyListing();
        this.props.getLanguageCode(); 
    }

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    validateForm() {
        this.setState({formValid: this.state.emailValid && this.state.passwordValid});
    }

    errorClass(error) {
        return(error.length === 0 ? '' : 'has-error');
    }

    static getDerivedStateFromProps(props, state) {

    //   if(props.companylisting.length && !state.is_loaded){
    //     var select_cmpany = [
    //             {'label': 'Select Company','value': ''}
    //         ];
    //     props.companylisting.forEach((company, index) => {
    //         select_cmpany.push({
    //                 'label' : company.CompanyName.trim(),
    //                 'value' : company.id,
    //         });
    //     });

    //     //console.log("in condition",  state.isLoading);

    //      var isloading = state.isLoading;

    //      if( props.insertdisplaystatus.message){
    //         isloading = false;
    //      }
        
    //   } else 
    var select_cmpany = [
        {'label': 'Select Company','value': ''}
    ];
    var select_language = [
        {'label': 'Select Language','value': ''}
    ];

      if(props.companylisting.length && !state.is_loaded){

      
           
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                        'label' : company.CompanyName.trim(),
                        'value' : company.id,
                });
            });

            if(props.languagelisting.length > 0 && !state.is_loaded){

                try{

                    props.languagelisting.forEach((language, index) => {
                        select_language.push({
                                'label' : language.LanguageName.trim(),
                                'value' : language.LanguageCode.trim(),
                        });
                    });

                }catch(e){
                    console.log('languagelisting error', e);        
                }
           
                // props.languagelisting.forEach((language, index) => {
                //     select_language.push({
                //             'label' : language.LanguageName.trim(),
                //             'value' : language.LanguageCode.trim(),
                //     });
                // });
            }
            var isloading = state.isLoading;

            if( props.insertdisplaystatus.message){
                isloading = false;
            }
    
              
        }


        return { select_company : select_cmpany, select_language:select_language,is_loaded:isloading};   
      //return true;
        
    }
    

    manageUser() {
        if( !this.props.invalid ){
            this.setState({isLoading: true});
        }

        console.log("email", this.props.formValues.email)
        //this.props.formValues.email

        var form = document.querySelector('#user-form');
        var values = serialize(form,{ hash: true });

        values.token = this.props.token;
        values.user_image = '';
        values.created_role = '';
        values.created_by = '';
        if(this.state.files.base64){
            values.user_image = this.state.files.base64
        }
        
        if(!values.user_type && this.props.user_type == 1){
            values.user_type = 5;
        }
        if(!values.user_type && this.props.user_type == 2){
            values.user_type = 6;
        }

        if(!values.user_type){
            values.user_type = this.props.user_type;
        }
        values.created_role = this.props.user_type;
        values.created_by = this.state.id;
       
        this.props.InsertUser(values);
    }


    getFiles(files){
        this.setState({ files: files })
    }

    onChangeFile = (event)=> {
        console.log('event.target.files[0]', event.target.files[0])
        event.stopPropagation();
        event.preventDefault();
        var file = event.target.files[0];
        console.log('file.....:', file);
      }
      
    
    
    render() {
        // document.getElementById('file').addEventListener('change', this.onChangeFile);
        console.log("am render", this.state.select_language)

        if(this.props.insertcode === 1 && this.state.insertUserCode){
            return <Redirect to={Config.userPath[this.props.user_type]+'usermanagement'}/>
        }
        
        const {  handleSubmit } = this.props;
        

        return ( <div>     
            
                 { 
                    this.props.insertdisplaystatus.message.email ?
                     <div class="alert alert-danger" role="alert">
                         The email has already been taken.
                     </div>: 
                    this.props.insertdisplaystatus.message ? 
                     <div class="alert alert-danger" role="alert">
                       Something went wrong. Please try again
                     </div>:""
                 }

                 { this.props.insertdisplaystatus.message.length == 0 ? <Loader showloader={this.state.isLoading }/>: "" }


                <div className="user-management-create">
                    <form id="user-form" className="form-inlinex" onSubmit={handleSubmit(this.manageUser.bind(this))}>
                        <div className="account_info">
                            <h3>Account Info</h3>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    { this.props.user_type == 4 ? 
                                    <div className="form-group ">
                                        <label className="form-label">User Company</label>                                 
                                        <RenderSelect options={this.state.select_company} className="form-control hsmall arrow" name="user_company" id="user_company" />      
                                    </div>  : null }
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Type</label>
                                        <RenderSelect options={this.state.select_language} className="form-control hsmall arrow" name="userLanguage" id="userLanguage" />  
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Language</label>
                                        <RenderSelect options={this.state.select_language} className="form-control hsmall arrow" name="userLanguage" id="userLanguage" />  
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group">
                                        <label>User Name</label>
                                        <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  />
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group ">
                                        <label>Password</label>
                                        <Field name="password" component={Common.renderInput} type="password" id="password" className="form-control hsmall" />
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                        </div>
                        
                        <div className="account_info">
                            <h3>Personal Info</h3>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div class="form-group">
                                        UPLOAD PROFILE IMAGE
                                        <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group">
                                        <label>First Name</label>
                                        <Field name="first_name" component={Common.renderInput} type="text" id="first_name" className="form-control hsmall" />
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group">
                                        <label>Last Name</label>                                
                                        <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" className="form-control hsmall" />                               
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group" >
                                        <label>Email</label>                                
                                        <Field readOnly name="email" component={Common.renderInput} id="email"  className="form-control hsmall"/>                                
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="form-group">
                                        <label>Telephone</label>
                                        <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                        normalize={ normalizeNumberAndSetLimit(30)  } 
                                        />
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-md-2"></div>
                            <div className="col-md-2">
                                <Link to={'usermanagement'}>CANCEL</Link>
                            </div>
                            <div className="col-md-4"></div>
                            <div className="col-md-2">
                                <Button type="submit" id="cu_status_save_option" className="btn btn-primary btn-block"  value="Save">Save</Button>
                            </div>
                            <div className="col-md-2"></div>
                        </div>

                    </form>
                </div>

            </div>
        );
    }
}

 const InsertUsers = connect(
    state => ({
         formValues: getFormValues('UserForm')(state),
        // submitErrors: getFormSubmitErrors('CompanyForm')(state),    
        invalid: isInvalid('UserForm')(state),
     })

  )(InsertUser)


export default reduxForm({
    form: 'UserForm',
    validate:Validation.ValidateUserForm
})(InsertUsers);




