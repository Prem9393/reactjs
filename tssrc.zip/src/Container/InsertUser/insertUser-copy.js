import React, { Component } from 'react';
import { reduxForm, Field, isInvalid, getFormValues } from 'redux-form';
import { Button } from 'react-bootstrap';
import Common from '../../Common';
import Config from '../../Config';
import Validation from '../../Validations';
import {Redirect, Link}  from 'react-router-dom';
import serialize from 'form-serialize';
import Select from 'react-select';
import RenderSelect from '../../Components/SelectField';
import FileBase64 from 'react-file-base64';
import { FormErrors } from '../../FormErrors';
import Loader from '../../Components/Loader';
import ActionCreators from '../../Actions/ActionCreators'
import {connect} from 'react-redux';
import { normalizeNumberAndSetLimit } from '../../Validations';
import { Tabs, Tab } from 'react-bootstrap';


class InsertUser extends Component {
    constructor(props, context) {
        //console.log("insert props",props);
        super(props, context);
        this.handleSelect = this.handleSelect.bind(this);
        this.state = {
            actionkey: 1,
            files:'',
            id: props.id,
            select_options: [
                {label: 'Select User Type', value: ''},
                {label: 'Supplier', value: '1'},
                {label: 'Retailer', value: '2'},
                {label: 'GS1User', value: '3'},
                {label: 'TrustedSource', value: '4'},
            ],
            select_company: [],
            first_name: '',
            last_name: '',            
            email: false,
            password: false,
            user_name: false,
            user_telephone: false,
            is_loaded: false,
            insertUserCode: false,
            isLoading: true,
            selectedCompany:""
        };
    }

    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;    
    }

    componentWillMount(){

     this.props.dispatch(ActionCreators.insertdisplaystatusOff());
     this.setState({isLoading: false })
        //this.setState({insertUserCode: true})
        //{ console.log("isLoading", this.state.isLoading)}   
     }

    componentDidMount() {
        
        this.setState({insertUserCode: true, isLoading: false})
        this.props.CompanyListing();
        this.props.getLanguageCode(); 
    }

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    validateForm() {
        this.setState({formValid: this.state.emailValid && this.state.passwordValid});
    }

    errorClass(error) {
        return(error.length === 0 ? '' : 'has-error');
    }

    static getDerivedStateFromProps(props, state) {

    //   if(props.companylisting.length && !state.is_loaded){
    //     var select_cmpany = [
    //             {'label': 'Select Company','value': ''}
    //         ];
    //     props.companylisting.forEach((company, index) => {
    //         select_cmpany.push({
    //                 'label' : company.CompanyName.trim(),
    //                 'value' : company.id,
    //         });
    //     });

    //     //console.log("in condition",  state.isLoading);

    //      var isloading = state.isLoading;

    //      if( props.insertdisplaystatus.message){
    //         isloading = false;
    //      }
        
    //   } else 
    var select_cmpany = [
        {'label': 'Select Company','value': ''}
    ];
    var select_language = [
        {'label': 'Select Language','value': ''}
    ];

      if(props.companylisting.length && !state.is_loaded){

      
           
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                        'label' : company.CompanyName.trim(),
                        'value' : company.id,
                });
            });

            if(props.languagelisting.length > 0 && !state.is_loaded){

                try{

                    props.languagelisting.forEach((language, index) => {
                        select_language.push({
                                'label' : language.LanguageName.trim(),
                                'value' : language.LanguageCode.trim(),
                        });
                    });

                }catch(e){
                    console.log('languagelisting error', e);        
                }
           
                // props.languagelisting.forEach((language, index) => {
                //     select_language.push({
                //             'label' : language.LanguageName.trim(),
                //             'value' : language.LanguageCode.trim(),
                //     });
                // });
            }
            var isloading = state.isLoading;

            if( props.insertdisplaystatus.message){
                isloading = false;
            }
    
              
        }


        return { select_company : select_cmpany, select_language:select_language,is_loaded:isloading};   
      //return true;
        
    }
    

    manageUser() {
        if( !this.props.invalid ){
            this.setState({isLoading: true});
        }

        console.log("email", this.props.formValues.email)
        //this.props.formValues.email

        var form = document.querySelector('#user-form');
        var values = serialize(form,{ hash: true });

        values.token = this.props.token;
        values.user_image = '';
        values.created_role = '';
        values.created_by = '';
        if(this.state.files.base64){
            values.user_image = this.state.files.base64
        }
        
        if(!values.user_type && this.props.user_type == 1){
            values.user_type = 5;
        }
        if(!values.user_type && this.props.user_type == 2){
            values.user_type = 6;
        }

        if(!values.user_type){
            values.user_type = this.props.user_type;
        }
        values.created_role = this.props.user_type;
        values.created_by = this.state.id;
       
        this.props.InsertUser(values);
    }


    getFiles(files){
        this.setState({ files: files })
    }

    onChangeFile = (event)=> {
        console.log('event.target.files[0]', event.target.files[0])
        event.stopPropagation();
        event.preventDefault();
        var file = event.target.files[0];
        console.log('file.....:', file);
      }
      
    
    
    render() {
        // document.getElementById('file').addEventListener('change', this.onChangeFile);
        console.log("am render", this.state.select_language)

        if(this.props.insertcode === 1 && this.state.insertUserCode){
            return <Redirect to={Config.userPath[this.props.user_type]+'usermanagement'}/>
        }
        
        const {  handleSubmit } = this.props;
        

        return ( <div>     

            
                 { 
                    this.props.insertdisplaystatus.message.email ?
                     <div class="alert alert-danger" role="alert">
                         The email has already been taken.
                     </div>: 
                    this.props.insertdisplaystatus.message ? 
                     <div class="alert alert-danger" role="alert">
                       Something went wrong. Please try again
                     </div>:""
                 }

                 { this.props.insertdisplaystatus.message.length == 0 ? <Loader showloader={this.state.isLoading }/>: "" }


                <div>
                    <form id="user-form" className="form-inlinex" onSubmit={handleSubmit(this.manageUser.bind(this))}>
                        <span>Account Info</span>
                            { this.props.user_type == 4 ? 
                            <div className="form-group ">
                                <label>User Company</label>                                 
                                <RenderSelect options={this.state.select_company} className="form-control hsmall arrow" name="user_company" id="user_company" />      
                            </div>  : null }
                            <div className="form-group">
                                <label>Language</label>
                                <RenderSelect options={this.state.select_language} className="form-control hsmall arrow" name="userLanguage" id="userLanguage" />  
                            </div>
                            <div className="form-group">
                                <label>User Name</label>
                                <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  />
                            </div>
                            <div className="form-group ">
                                <label>Password</label>
                                <Field name="password" component={Common.renderInput} type="password" id="password" className="form-control hsmall" />
                            </div>
                        <span>Personal Info</span>
                            <div class="form-group">
                                UPLOAD PROFILE IMAGE
                                <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                            </div>
                            <div className="form-group">
                                <label>First Name</label>
                                <Field name="first_name" component={Common.renderInput} type="text" id="first_name" className="form-control hsmall" />
                            </div>
                            <div className="form-group">
                                <label>Last Name</label>                                
                                <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" className="form-control hsmall" />                               
                            </div> 
                            <div className="form-group" >
                                <label>Email</label>                                
                                <Field readOnly name="email" component={Common.renderInput} id="email"  className="form-control hsmall"/>                                
                            </div>
                            <div className="form-group">
                                <label>Telephone</label>
                                <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                normalize={ normalizeNumberAndSetLimit(30)  } 
                                />
                            </div>
                            <Link to={'usermanagement'}>CANCEL</Link>
                            <Button type="submit" id="cu_status_save_option" className="btn btn-primary btn-block"  value="Save">Save</Button>
                    </form>   
                </div>



                <section className="content user_tabs">
                    <div className="step_3main">
                        <div>
                            <div className="cunitform">                                
                                <div className="row">

                                {/* <div className="panel panel-default">
                                    <FormErrors formErrors={this.state.formErrors} />
                                </div> */}
                <form id="user-form" className="form-inlinex" onSubmit={handleSubmit(this.manageUser.bind(this))}>
                    <div class="col-md-3">
                        <div class="box box-primary">
                            <div class="box-body box-profile">                                
                                <div className="img_wrapper"> 
                                <img src={Config.companylogopath + 'default.png'} alt="" width="200" className="profile-user-img img-responsive img-circle"/>
                               
                                <div class="file-field big">
                                    <a class="btn-floating btn-lg pink lighten-1 mt-0 float-left">
                                    <i class="fa fa-fw fa-cloud-upload" aria-hidden="true"></i>
                                    <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                    </a>                                    
                                </div>
                                </div>
                               
                                <h3 class="profile-username text-center"></h3>
                                <p class="text-muted text-center"></p>
                                {/* <ul class="list-group list-group-unbordered">
                                    <li class="list-group-item">
                                        <b>Followers</b> <a class="pull-right">1,322</a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Following</b> <a class="pull-right">543</a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Friends</b> <a class="pull-right">13,287</a>
                                    </li>
                                </ul>                                */}
                                <Button type="submit" id="cu_status_save_option" className="btn btn-primary btn-block"  value="Save">Save</Button>
                            </div>
                        </div>               
                    </div>

                <div className="col-md-9">
                <Tabs defaultActiveKey="user_profile" id="uncontrolled-tab-example">
                    <Tab eventKey="user_profile" title="Home">
                        <div className="form-group">
                                <label>First Name</label>
                                <Field name="first_name" component={Common.renderInput} type="text" id="first_name" className="form-control hsmall" />
                            </div>                                           
                            <div className="form-group">
                                <label>Last Name</label>                                
                                <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" className="form-control hsmall" />                               
                            </div> 
                            <div className="form-group" >
                                <label>Email</label>                                
                                <Field readOnly name="email" component={Common.renderInput} id="email"  className="form-control hsmall"/>                                
                            </div>                              
                            <div className="form-group hide">
                                <label>User Type</label> 
                                <Field options={this.state.select_options}  className="form-control hsmall arrow" label="User Type" name="user_type" id="user_type" component={Common.renderSelect} disabled={true}></Field>
                            </div>

                            <div className="form-group hide">
                            <div className="col-sm-10">
                                <Field name="id" component={Common.renderInput} type="text" id="id" className="form-control hsmall" />
                            </div>
                            </div> 
                            <div className="form-group">
                                <label>Telephone</label>
                                <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                normalize={ normalizeNumberAndSetLimit(30)  } 
                                />
                            </div>                                       
                           
                              
                            {this.props.user_type == 4 ? <div className="form-group ">
                                                        <label>User Company</label>                                 
                                                        <RenderSelect options={this.state.select_company}    className="form-control hsmall arrow" name="user_company" id="user_company" />      
                                                    </div>  : null }
                            <div className="form-group">
                                <label>Language</label>
                                <RenderSelect options={this.state.select_language}    className="form-control hsmall arrow" name="userLanguage" id="userLanguage" />  
                            </div> 

                            <div className="form-group">
                                <label>User Name</label>
                                <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  />
                            </div>
                            
                            <div className="form-group ">
                                <label>Password</label>
                                <Field name="password" component={Common.renderInput} type="password" id="password" className="form-control hsmall" />
                            </div>

                            {/* <div className="form-group">
                                <label>User Image</label>
                                    <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                   
                            </div>  */}
                    </Tab>
                    <Tab eventKey="user_permission" title="Profile">
                    <table className="table">
                            <thead>
                                <tr>
                                    <th>Permission</th>
                                    <th>Access Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Company Management: View</td>
                                    <td><Field name="IsView" id="IsView" component="input" type="checkbox" value="1" /></td>
                                </tr>
                                <tr>
                                    <td>Company Management: Modify</td>
                                    <td><Field name="IsModify" id="IsModify" component="input" type="checkbox" value="1"  /></td>
                                </tr>
                                <tr>
                                    <td>Company Management - User: View</td>
                                    <td><Field name="IsUserView" id="IsUserView" component="input" type="checkbox" value="1"  /></td>
                                </tr>
                                <tr>
                                    <td>Company Management - User: Modify</td>
                                    <td><Field name="IsUserModify" id="IsUserModify" component="input" type="checkbox" value="1"  /></td>
                                </tr>
                                {/* <tr>
                                    <td>Company Management - User: Delete</td>
                                    <td><Field name="IsUserDelete" id="IsUserDelete" component="input" type="checkbox" value="1" /></td>
                                </tr>
                                <tr>
                                    <td>Product Data & Tools: My product Data</td>
                                    <td><Field name="MyProductData" id="MyProductData" component="input" type="checkbox" value="1" /></td>
                                </tr> */}
                                <tr>
                                    <td>Product Data & Tools: Product: View</td>
                                    <td><Field name="IsProductView" id="IsProductView" component="input" type="checkbox" value="1"  /></td>
                                </tr>
                                <tr>
                                    <td>Product Data & Tools: Product: Modify</td>
                                    <td><Field name="IsProductEdit" id="IsProductEdit" component="input" type="checkbox" value="1"  /></td>
                                </tr>
                                <tr>
                                    <td>Product Data & Tools: Product: Uploads</td>
                                    <td><Field name="IsProductUpload" id="IsProductUpload" component="input" type="checkbox" value="1"  /></td>
                                </tr>                                                      
                            </tbody>
                        </table>
                    </Tab>                  
                </Tabs>
               
                </div>
                </form>

                             
                                </div>
                            </div>
                        </div>
                </div>
                </section>
            </div>
        );
    }
}

 const InsertUsers = connect(
    state => ({
         formValues: getFormValues('UserForm')(state),
        // submitErrors: getFormSubmitErrors('CompanyForm')(state),    
        invalid: isInvalid('UserForm')(state),
     })

  )(InsertUser)


export default reduxForm({
    form: 'UserForm',
    validate:Validation.ValidateUserForm
})(InsertUsers);




