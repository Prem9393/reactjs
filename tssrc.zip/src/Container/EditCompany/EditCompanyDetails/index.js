import React, { Component } from 'react';
import { Field, change } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';
import SimpleReactValidator from 'simple-react-validator';
import CustomInput from '../../../Components/CustomInput';
import { connect } from 'react-redux';
import img from '../../../images/128.png';
import Config from '../../../Config';
import FileBase64 from 'react-file-base64';
import Loader from '../../../Components/Loader';

import { normalizeMaxLength, normalizeNumber, validateEmail, normalizeNumberAndSetLimit } from '../../../Validations';


class EditCompanyDetails extends Component {

    constructor(props) {
        super(props);
        console.log("constructor props", props);
        this.validator = new SimpleReactValidator();
        this.nextTab = this.nextTab.bind(this);
        this.state = {

            tabkey: 1,
            select_options: [
                { label: 'Supplier/Manufacturer', value: '1' },
                { label: 'Retailer', value: '2' },
                { label: '3rd Party', value: '7' },
            ],
            parent_company: [
                { label: 'GS1 Southafrica', value: '1' },
            ],
            company_details: [
                CompanyName => "test",
            ],
            country_list: [
                { label: 'South Africa', value: '1' },
            ],
            checkBoxSelected: false,
            files: '',
            isLoading: false


        }


        const Input = (props) => {

            return (
                <div className="form-group">
                    <label htmlFor={props.name} className="form-label">{props.title}</label>
                    <input
                        className="form-input"
                        id={props.name}
                        name={props.name}
                        type={props.type}
                        value={props.value}
                        onChange={props.handleChange}
                        placeholder={props.placeholder}
                    />
                </div>
            )
        }


    }


    componentDidMount() {
        this.state = {
            company_details: [
                CompanyName => "test",
            ]
        }
    }


    handleSelect(tabkey) {
        this.setState({ tabkey });
    }

    nextTab() {
        this.props.onChange(this.state.tabkey + 1);
    }

    handleChange(e) {

        this.setState({ checkBoxSelected: !this.state.checkBoxSelected })
        if (this.state.checkBoxSelected) {
            this.props.dispatch(change('EditCompanyForm', 'PostalPoBox', this.props.company_details.StreetNumberName));
            this.props.dispatch(change('EditCompanyForm', 'PostalSubrubName', this.props.company_details.SubrubName));
            this.props.dispatch(change('EditCompanyForm', 'PostalCityName', this.props.company_details.CityName));
            this.props.dispatch(change('EditCompanyForm', 'PostalPostalCode', this.props.company_details.PostalCode));
            this.props.dispatch(change('EditCompanyForm', 'PostalCountry', this.props.company_details.ParentCompany));
            this.props.dispatch(change('EditCompanyForm', 'PostalProvince', this.props.company_details.Province));
        } else {
            this.props.dispatch(change('EditCompanyForm', 'PostalPoBox', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalSubrubName', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalCityName', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalPostalCode', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalCountry', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalProvince', ''));
        }

    }

    componentWillReceiveProps(nextProps) {

        if (this.props.company_details_msg !== '') {

            this.setState({ isLoading: false });

        }
    }

    componentWillUnmount() {
        this.setState({ isLoading: false });
    }

    render() {
        console.log("props company", this.props.user_auth.is_view);

        console.log("check props", this.props);


        const { CompanyLogo, CompanyName, CompanyGLN } = this.props.company_details;

        return (

            <fieldset disabled={this.props.user_auth.is_modify != 1}>
                <div className="editcompanyform">
                    <Loader showloader={this.state.isLoading} />
                    <div className="cunitform">
                        <div className="edit-compny-detail">
                            <div className="pdform_column">
                                <div className="pdform-body">
                                <div className="form-group ">
									<div className="edit-company-modal-head modal-head">
                                        <h4><span><img src="assets/icons/24x24/company-profile-blue.svg" class="img-responsive"/></span>Company Detail</h4>
										<div class="form-group add-user-profile-info-wrapper modal-update">
										<p class="profile-title"> Company logo</p>
										<p class="user-upload">
										<input type="file"></input><span>upload Company Logo</span></p>
									</div>
								</div>
								
                                    </div>
                                    <div className="form-group ">
                                        
                                        <label>Company Name </label>
                                        <Field
                                            name="CompanyName"
                                            value={this.props.company_details.CompanyName}
                                            component={Common.renderInput}
                                            type="text"
                                            id="CompanyName"
                                            className="form-control hsmall"
                                            normalize={normalizeMaxLength(100)}
                                        />
                                    </div>

                                    <div className="form-group ">
                                        <label>Company Type</label>
                                        <RenderSelect name="CompanyType" component={Common.renderSelect} type="select" id="cu_functionalname" options={this.state.select_options} className="form-control hsmall" />
                                    </div>

                                    <div className="form-group ">
                                        <label>Parent Company</label>
                                        <Field name="ParentCompany" component={Common.renderSelect} type="select" id="ParentCompany" options={this.state.parent_company} className="form-control hsmall" />
                                    </div>
                                    <div className="form-group hide">
                                        <label>Company ID</label>
                                        <Field name="company_id" component={Common.renderInput} type="text" id="company_id" className="form-control hsmall" />
                                    </div>

                                    <div className="row m-0">
                                        <div className="col-md-4">
                                            <div className="form-group">
                                                <label>Batch User Id</label>
                                                <Field name="BatchUserId" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'company_details')} id="BatchUserId" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(100)} />
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="form-group ">
                                                <label>Web Service GLN</label>
                                                <Field name="WebServiceGLN" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'company_details')} id="WebServiceGLN" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(100)} />
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="form-group ">
                                                <label>Web Service Key</label>
                                                <Field name="WebServiceKey" component={Common.renderInput} type="text" onBlur={this.props.handleChange.bind(this, 'company_details')} id="WebServiceKey" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(100)} />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div className="edit-compny-physical">
                            <div className="pdform_column">
                                <div className="pdform-body">
									<div className="modal-head">
										<h4><span><img src="assets/icons/24x24/company-profile-blue.svg" class="img-responsive"/></span>Physical Address</h4>
                                    
									</div>
                                    <div className="form-group">
                                        <label>Address 1</label>
                                        <Field name="AddressLine1" component={Common.renderInput} type="text" id="address_info[BuildingName]" placeholder="Address 1" className="form-control hsmall" normalize={normalizeMaxLength(30)} />
                                    </div>

                                    <div className="form-group">
                                        <label>Address 2</label>
                                        <Field name="AddressLine2" component={Common.renderInput} type="text" id="address_info[BuildingName]" placeholder="Address 2" className="form-control hsmall" normalize={normalizeMaxLength(30)} />
                                    </div>

                                    <div className="row m-0">
                                        <div className="col-md-6 p0">
                                            <div className="form-group">
                                                <label>City Name</label>
                                                <Field name="CityName" component={Common.renderInput} type="text" placeholder="City" onChange={this.props.handleChange.bind(this, 'CityName')} id="CityName" className="form-control hsmall" normalize={normalizeMaxLength(40)} />
                                            </div>
                                        </div>
                                        <div className="col-md-6 p0">
                                            <div className="form-group">
                                                <label>Postal Code</label>
                                                <Field name="PostalCode" component={Common.renderInput} type="text" placeholder="Postal Code" onChange={this.props.handleChange.bind(this, 'PostalCode')} id="PostalCode" className="form-control hsmall" normalize={normalizeNumberAndSetLimit(20)} />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <label>Country</label>
                                        <Field name="Country" component={Common.renderSelect} type="select" id="ParentCompany" placeholder="Country" onChange={this.props.handleChange.bind(this, 'Country')} options={this.state.country_list} className="form-control hsmall" />
                                    </div>
                                    <div className="row m-0">
                                        <div className="col-md-6 p0">
                                            <div className="form-group">
                                                <label>Is Compliant</label>
                                                <Field name="IsCompliant" component={Common.renderInput} id="IsCompliant" className="form-control hsmall" normalize={normalizeNumber} />
                                            </div>
                                        </div>

                                        <div className="col-md-6 p0">
                                            <div className="form-group ">
                                                <label>% Compliant</label>
                                                <Field name="CompliantPercentage" component={Common.renderInput} type="text" id="CompliantPercentage" placeholder="%" className="form-control hsmall" normalize={normalizeNumber} />
                                            </div>
                                        </div>


                                        <div className="row m-0">
                                            <div className="col-md-6 p0 text-left edit-company-cancel-btn">
                                                <div className="form-group ">
                                                    <label for="gm">cancel</label>

                                                </div>
                                            </div>
                                            <div className="col-md-6 p0">
                                                <div className="form-group ">
                                                {  console.log( "yy", this.props) }
                                                    <button
                                                        type="submit" 
                                                        class="btn "
                                                        onClick={this.props.onSubmit}
                                                        id="user_save_option"
                                                        value="Save"><b>
                                                            Create Company
                                            </b></button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <div className="col-xs-12 col-sm-2 col-md-2">
                            <div className="saveform">
                                <div className="save_btn">
                                    <Button type="submit" id="user_save_option"
                                     className="btn-save" 
                                     value="Save">Save</Button>
                                </div>
                            </div>
                        </div> */}
                </div>

            </fieldset>

        );
    }
}


export default EditCompanyDetails;






        //  if(nextProps.company_details_msg !==''){

        //     setTimeout(this.setState({isLoading: false}), 5000);
        //     // this.setState({isLoading: false});
        //  }
        // setTimeout(
        //     function() {
        //         this.setState({isLoading: false});
        //     }
        //     .bind(this),
        //     3000
        // );