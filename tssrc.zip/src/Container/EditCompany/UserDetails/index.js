import React, { Component } from 'react';
import { Tabs, Tab} from 'react-bootstrap';
import { Field } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';

import { normalizeNumber } from '../../../Validations';

class UserDetails extends Component {

	constructor(props) {
		super(props);
    }
     

	render() {
		return (
			<div className="cunitform">
                <div className="row">
                    <div className="col-xs-12 col-sm-5 col-md-5">
                        <div className="pdform_column first_coumn">
                        <div className="form-group ">
                                <Field status={1} name="user_id" component={Common.renderInput} type="hidden" id="user_id" className="form-control hsmall" />
                            </div>
							<div className="form-group ">
                                <label>First Name</label>
                                <Field status={1} name="first_name" component={Common.renderInput} type="text" id="first_name" className="form-control hsmall" />
                            </div>

							<div className="form-group ">
                                <label>Last Name</label>
                                <Field status={1} name="last_name" component={Common.renderInput} type="text" id="last_name" className="form-control hsmall" />
                            </div>

							<div className="form-group ">
                                <label>Email Address</label>
								<Field status={1} name="email_id" component={Common.renderInput} type="text" id="email_id" className="form-control hsmall" />
                            </div>

							<div className="form-group ">
                                <label>Contact Number</label>
                                <Field status={1} name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall" normalize={normalizeNumber}/>
                            </div>

                            <div className="form-group ">
                                <label>Login Username</label>
                                <Field status={1} name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall" />
                            </div>

                            <div className="form-group ">
                                <label>Login Password</label>
                                <Field status={1} name="password" component={Common.renderInput} type="password" id="password" className="form-control hsmall" />
                            </div>	

                            <div className="form-group">
								<div className="inline-checkbox tick">
									<Field disabled={true} name="IsDataController" id="IsDataController" component="input" type="checkbox" value="1" />
									<label htmlFor="gm">This is Data Controller</label>
								</div>
                            </div>
							

						</div>
                    </div>

					
					<div className="col-xs-12 col-sm-5 col-md-5">
						<div className="pdform_column second_coumn">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Permission</th>
                                        <th>Access Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Company Management: View</td>
                                        <td><Field name="IsView" id="IsView" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management: Modify</td>
                                        <td><Field name="IsModify" id="IsModify" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management - User: View</td>
                                        <td><Field name="IsUserView" id="IsUserView" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management - User: Modify</td>
                                        <td><Field name="IsUserModify" id="IsUserModify" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    {/* <tr>
                                        <td>Company Management - User: Delete</td>
                                        <td><Field name="IsUserDelete" id="IsUserDelete" component="input" type="checkbox" value="1" /></td>
                                    </tr> */}
                                    <tr>
                                        <td>Product Data & Tools: Product: View</td>
                                        <td><Field name="IsProductView" id="IsProductView" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    <tr>
                                        <td>Product Data & Tools: Product: Modify</td>
                                        <td><Field name="IsProductEdit" id="IsProductEdit" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                    <tr>
                                        <td>Product Data & Tools: Product: Uploads</td>
                                        <td><Field name="IsProductUpload" id="IsProductUpload" component="input" type="checkbox" value="1" /></td>
                                    </tr>
                                   
                                </tbody>
                            </table>
							
						</div>
					</div>
				
					

					<div className="col-xs-12 col-sm-2 col-md-2">
                        <div className="saveform">
                            
                            <div className="save_btn">
                                <Button type="submit" id="user_save_option" className="btn-save" value="Save">Save</Button>
                            </div>
                            
                        </div>
                    </div>
					 

				</div>
			</div>
		);
	}
}

export default UserDetails;