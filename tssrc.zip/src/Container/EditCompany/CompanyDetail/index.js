import React, { Component } from 'react';
import { Field, change } from 'redux-form';
import Common from '../../../Common';
import RenderSelect from '../../../Components/SelectField';
import { Button } from 'react-bootstrap';
import SimpleReactValidator from 'simple-react-validator';
import CustomInput from '../../../Components/CustomInput';
import { connect } from 'react-redux';
import img from '../../../images/128.png';
import Config from '../../../Config';
import FileBase64 from 'react-file-base64';
import Loader from '../../../Components/Loader';
import SlidingPane from 'react-sliding-pane';
import { normalizeMaxLength, normalizeNumber, validateEmail, normalizeNumberAndSetLimit } from '../../../Validations';
import InsertUserCompanyDetails from '../../../Container/InsertUser/InsertUserCompanyDetails';

//<h5><span><img src="assets/icons/24x24/company-profile-blue.svg" class="img-responsive"></span>Company Detail</h5>

class CompanyDetail extends Component {
    constructor(props) {
        super(props);
        console.log("constructor props", props);
        this.validator = new SimpleReactValidator();
        this.nextTab = this.nextTab.bind(this);
        this.OpenPanel = this.OpenPanel.bind(this);

        this.state = {

            tabkey: 1,
            select_options: [
                { label: 'Supplier/Manufacturer', value: '1' },
                { label: 'Retailer', value: '2' },
                { label: '3rd Party', value: '7' },
            ],
            parent_company: [
                { label: 'GS1 Southafrica', value: '1' },
            ],
            company_details: [
                CompanyName => "test",
            ],
            country_list: [
                { label: 'South Africa', value: '1' },
            ],
            checkBoxSelected: false,
            files: '',
            isLoading: false,
            isPaneOpen: false,
            isPaneOpenLeft: false,


        }


        const Input = (props) => {

            return (
                <div className="form-group">
                    <label htmlFor={props.name} className="form-label">{props.title}</label>
                    <input
                        className="form-input"
                        id={props.name}
                        name={props.name}
                        type={props.type}
                        value={props.value}
                        onChange={props.handleChange}
                        placeholder={props.placeholder}
                    />
                </div>
            )
        }


    }

    OpenPanel() {
        this.setState({
            isPaneOpen: true
        });

    }

    componentDidMount() {
        this.state = {
            company_details: [
                CompanyName => "test",
            ]
        }
    }


    handleSelect(tabkey) {
        this.setState({ tabkey });
    }

    nextTab() {
        this.props.onChange(this.state.tabkey + 1);
    }

    handleChange(e) {

        this.setState({ checkBoxSelected: !this.state.checkBoxSelected })
        if (this.state.checkBoxSelected) {
            this.props.dispatch(change('EditCompanyForm', 'PostalPoBox', this.props.company_details.StreetNumberName));
            this.props.dispatch(change('EditCompanyForm', 'PostalSubrubName', this.props.company_details.SubrubName));
            this.props.dispatch(change('EditCompanyForm', 'PostalCityName', this.props.company_details.CityName));
            this.props.dispatch(change('EditCompanyForm', 'PostalPostalCode', this.props.company_details.PostalCode));
            this.props.dispatch(change('EditCompanyForm', 'PostalCountry', this.props.company_details.ParentCompany));
            this.props.dispatch(change('EditCompanyForm', 'PostalProvince', this.props.company_details.Province));
        } else {
            this.props.dispatch(change('EditCompanyForm', 'PostalPoBox', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalSubrubName', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalCityName', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalPostalCode', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalCountry', ''));
            this.props.dispatch(change('EditCompanyForm', 'PostalProvince', ''));
        }

    }

    componentWillReceiveProps(nextProps) {

        if (this.props.company_details_msg !== '') {

            this.setState({ isLoading: false });

        }

        //  if(nextProps.company_details_msg !==''){

        //     setTimeout(this.setState({isLoading: false}), 5000);
        //     // this.setState({isLoading: false});
        //  }
        // setTimeout(
        //     function() {
        //         this.setState({isLoading: false});
        //     }
        //     .bind(this),
        //     3000
        // );
    }

    componentWillUnmount() {
        this.setState({ isLoading: false });

    }


    render() {
        console.log("props company", this.props.user_auth.is_view);

        console.log("check props", this.props);

        const { CompanyLogo, CompanyName, CompanyGLN, CompanyType, company_id, BatchUserId,
            WebServiceGLN, AddressLine1, AddressLine2, CityName, PostalCode, Country,
            IsCompliant, CompliantPercentage } = this.props.company_details;

        return (
            <fieldset disabled={this.props.user_auth.is_modify != 1}>
                <div className="editcompanyform">
                    <Loader showloader={this.state.isLoading} />
                    <div className="cunitform">
                        <div className="row m0">
                            <div className="col-xs-12 col-sm-6 col-md-6">
                                <div className="company-detail-left">
                                    <div className="pdform_column">
                                        <div className="pdform-body">
                                            <div className="form-group ">
                                                <h5 style={{ "text-decoration": "underline" }}>
                                                    <span>
                                                        <img src="assets/icons/24x24/company-profile-blue.svg" class="img-responsive" />
                                                    </span>
                                                    Company Detail
                                                </h5>


                                                <div className="table-responsive">
                                                    {/* <h5  style={{"text-decoration": "underline"}}><strong>Company Detail</strong></h5> */}
                                                    <table>
                                                        <tr>
                                                            <td><label>Company Name </label></td>
                                                            <td>
                                                                <label> {CompanyName} </label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td><label>Company GLN</label></td>
                                                            <td>
                                                                <label> {CompanyGLN}</label>
                                                            </td>

                                                        </tr>
                                                        <tr>
                                                            <td><label>Company Type</label></td>
                                                            <td>
                                                                <label>  {CompanyType}</label>
                                                                {/* <RenderSelect name="CompanyType" component={Common.renderSelect} type="select" id="cu_functionalname" options={this.state.select_options} className="form-control hsmall" /> */}
                                                            </td>


                                                        </tr>
                                                        <tr>
                                                            <td>    <label>Parent Company</label></td>
                                                            <td>
                                                                <label>  {CompanyType}</label>
                                                                {/* <Field name="ParentCompany" component={Common.renderSelect} type="select" id="ParentCompany" options={this.state.parent_company} className="form-control hsmall" /> */}
                                                            </td>


                                                        </tr>
                                                        <tr>
                                                            <td><label>Company ID</label></td>
                                                            <td>
                                                                <label> {company_id}</label>
                                                            </td>


                                                        </tr>
                                                        <tr>
                                                            <td><label>Batch User Id</label></td>
                                                            <td>
                                                                <label>   {BatchUserId}</label></td>


                                                        </tr>
                                                        <tr>
                                                            <td>  <label>Web Service GLN</label></td>
                                                            <td>
                                                                <label>  {WebServiceGLN}</label></td>


                                                        </tr>
                                                    </table>

                                                </div>

                                            </div>


                                            <h5 style={{ "text-decoration": "underline" }}><span><img src="assets/icons/24x24/home-blue.svg" class="img-responsive" /></span>Physical Address</h5>

                                            {/* <h5 style={{"text-decoration": "underline"}}><strong>Physical Address</strong></h5> */}

                                            <div className="form-group">
                                                <div className="table-responsive">
                                                    <table>
                                                        <tr>
                                                            <td><label>Address 1</label></td>
                                                            <td> <label>{AddressLine1}</label></td>
                                                        </tr>
                                                        <tr>
                                                            <td><label>Address 2</label></td>
                                                            <td><label>{AddressLine2}</label></td>
                                                        </tr>
                                                        <tr>
                                                            <td><label>City Name</label></td>
                                                            <td><label> {CityName}</label></td>

                                                        </tr>
                                                        <tr>
                                                            <td><label>Postal Code</label></td>
                                                            <td> <label>{PostalCode}</label></td>
                                                        </tr>

                                                        <tr>
                                                            <td><label>Country</label></td>
                                                            <td> <label>{Country}</label></td>
                                                        </tr>

                                                        <tr>
                                                            <td><label>Is Compliant</label></td>
                                                            <td>  <label>{IsCompliant}</label></td>
                                                        </tr>

                                                        <tr>
                                                            <td><label>% Compliant</label></td>
                                                            <td><label> {CompliantPercentage}</label></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-xs-12 col-sm-6 col-md-6">
                                <div className="company-detail-right">
                                    <div className="pdform_column">
                                        <div className="pdform-body">

                                            <div className="company-detail-user">
                                            <div class="company-heade-btn-wrapper">
                                                <h5><span><img src="assets/icons/24x24/users-blue.svg" className="img-responsive" /></span>Users</h5>
                                                <button
                                                    style={{ "float": "right", "marginRight": "20px" }}
                                                    className="btn btn-primary btn-flat"
                                                    onClick={this.OpenPanel}
                                                >
                                                    Add user
                                         </button>
                                         </div>
                                            </div>
                                            <div className="form-group">
                                                <table>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>

                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                </table>

                                                <div ref={ref => this.el = ref}>
                                                    <SlidingPane
                                                        className='some-custom-class company-profile-edit-modal'
                                                        overlayClassName='some-custom-overlay-class'
                                                        isOpen={this.state.isPaneOpen}
                                                        title={<h2>Add User</h2>}
                                                        // subtitle={"this.props.autoqc_details.gtinName"}
                                                        onRequestClose={() => {
                                                            // triggered on "<" on left top click or on outside click
                                                            this.setState({ isPaneOpen: false });
                                                        }}>

                                                        <InsertUserCompanyDetails />
                                                        {/* <EditCompanyDetails getFiles={this.getFiles} handleChange={this.handleChange} onChange={this.onChange} {...this.state} {...this.props} /> */}
                                                    </SlidingPane>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br />
                        </div>
                    </div>
                </div>
            </fieldset>
        );
    }
}


export default CompanyDetail;



