import React, { Component } from 'react';
import Config from '../../Config';
import {Provider, connect} from 'react-redux';

import InsertForm from './EditCompany';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';


const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    token:state.auth.token,
    user_type:state.auth.user_type, 
    user_auth: state.auth,
    company_details: state.loadcompanydata.company_details,
    company_details_msg: state.loadcompanydata.message,
    updatecode: state.updatecompany.updatecode,
})

 
const mapDispatchToProps = (dispatch) => ({
    EditCompany: (values) => dispatch(ActionCreators.EditCompany(values)),
    CompanyTypeList:() => dispatch(ActionCreators.CompanyTypeList()),
    loadCompanyData: (values) => dispatch(ActionCreators.loadCompanyData(values)),
    updateCompany: (values) => dispatch(ActionCreators.updateCompany(values)),
    updateCodeOff: (values) => dispatch(ActionCreators.updateCodeOff(values)),
    DeleteCompany: (values) => dispatch(ActionCreators.DeleteCompany(values)),
})
  
const EditCompanyComponent  = connect(mapStateToProps, mapDispatchToProps)(InsertForm);



class EditCompany extends Component {
    
    componentDidMount(){
        document.title=Config.name+' Edit Company';
        
    }
    render(){
        return  <Provider store={AppStore}><EditCompanyComponent {...this.props}/></Provider>
    }
}





  

export default EditCompany;


