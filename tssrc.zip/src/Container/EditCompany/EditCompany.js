import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Tabs, Tab } from 'react-bootstrap';
import { reduxForm } from 'redux-form'
import Config from '../../Config';
import CompanyDetail from './CompanyDetail';
import EditCompanyDetails from './EditCompanyDetails';
import AddressInfo from './AddressInfo';
import AdditionalInfo from './AdditionalInfo';
import UserDetails from './UserDetails';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect } from 'react-router-dom';
import SimpleReactValidator from 'simple-react-validator';
import ActionCreators from '../.././Actions/ActionCreators';
import FileBase64 from 'react-file-base64';
import { Link } from 'react-router-dom';
import SlidingPane from 'react-sliding-pane';
import SlidingPanelTitle from '../../Components/SlidingPanelTitle';


// /import userImage from '../../../../src/images/128.png';



class EditCompany extends Component {
    constructor(props, context) {
        super(props, context);

        this.validator = new SimpleReactValidator();
        this.handleSelect = this.handleSelect.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.getFiles = this.getFiles.bind(this);

        this.onChange = this.onChange.bind(this);
        this.OpenPanel = this.OpenPanel.bind(this);
        this.updateCompany = this.updateCompany.bind(this);
        this.state = {
            files: '',
            actionkey: 1,
            company_details: [{
                company_name: "test",
            }],
            form_data_loaded: false,
            updatecode: false,
            isPaneOpen: false,
            isPaneOpenLeft: false,
        };
    }


    OpenPanel() {
        this.setState({
            isPaneOpen: true
        });

    }

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    handleChange(name, event) {
        const target = event.target;

        const value = target.type === 'checkbox' ? target.checked : target.value;
        // const name = target.name;
        this.setState({
            [name]: value
        });

    }

    componentWillMount() {
        this.setState({ updatecode: true })
    }

    componentDidMount() {
        let id = this.props.match.params.id;
        if (id !== 'undefined') {
            var form_details = {
                token: this.props.token,
                company_id: id
            }

            this.props.loadCompanyData(form_details);
        }

    }


    static getDerivedStateFromProps(props, state) {


        if (props.company_details.hasOwnProperty('CompanyGLN') && !state.form_data_loaded) {

            props.initialize(props.company_details);

            return {
                form_data_loaded: true,
                isLoading: false,
                company_details: props.company_details
            }

        } else {
            return true;
        }
    }

    getFiles(files) {
        //  console.log(files);
        this.setState({ files: files })
    }


    onChange(tabKey) {
        this.setState({ actionkey: tabKey })
    }

    updateCompany(values) {
        var form = document.querySelector('#update-company');
        var values = serialize(form, { hash: true });
        values.token = this.props.token;
        values.user_type = this.props.user_type;
        console.log(this.state);
        if (this.state.files.base64) {
            values.CompanyLogo = this.state.files.base64
        }

        // console.log("editcompany",values);

        this.props.updateCompany(values);
    }

    render() {
        if (this.props.updatecode === 1 && this.state.updatecode) {

            return <Redirect to={Config.userPath[this.props.user_type] + 'companymanagement'} />
        }
        console.log("this.props", this.props);
        const { CompanyName, company_id } = this.props.company_details;
        const { handleSubmit } = this.props;
        return (
            <form id="update-company" onSubmit={handleSubmit(this.updateCompany.bind(this))}>
                <div className="edit-company-main">
                    <div className="step_3main">
                        <div className="step_3main_detailsform">
                            {/* <Tab eventKey={1} title="Company Detail" tabClassName="bdata"> */}
                            {/* <h5 className="edit-company-header"><strong>{CompanyName ? CompanyName+ " Details" :"Edit Company Details"} </strong></h5> */}

                            <div className="edit-Delete">
                        
                                <h5 className="edit-company-header"> 
                                   <span>
                                    <img 
                                    src={'assets/icons/24x24/company-profile-blue.svg'}
                                    className={"img-responsive"}
                                    alt="logo" /></span>
                                    {"Unilever South Africa Pty Ltd"}
                                </h5>
                               
                                <div class="editcompany-head-btn-wrap">
                                    <span className="btn delete-btn"
                                        id={company_id} onClick={() => this.props.DeleteCompany(company_id)}
                                    >
                                        Delete
                                        </span>
                                        <span className="btn"
                                            onClick={this.OpenPanel}
                                        >
                                        Edit company
                                        </span>
                                </div>
                            </div>
                            <CompanyDetail getFiles={this.getFiles} handleChange={this.handleChange} onChange={this.onChange} {...this.state} {...this.props} />

                        </div>
                    </div>
                </div>


                <div ref={ref => this.el = ref}>
                    <SlidingPane
                        className='some-custom-class edit-company-modal'
                        overlayClassName='some-custom-overlay-class'
                        isOpen={this.state.isPaneOpen}
                        title={<h2> Edit Company</h2>}
                        // subtitle={"this.props.autoqc_details.gtinName"}
                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            this.setState({ isPaneOpen: false });
                        }}>
                        <EditCompanyDetails getFiles={this.getFiles} handleChange={this.handleChange} onSubmit={handleSubmit(this.updateCompany.bind(this))} onChange={this.onChange} {...this.state} {...this.props} />
                    </SlidingPane>
                </div>
            </form>
        );
    }
}


// const EditCompanys = connect(
//     state => ({
//       values: getFormValues('EditCompanyForm')(state),
// //       initialValues: getFormInitialValues('EditCompanyForm')(state),
// //       syncErrors: getFormSyncErrors('EditCompanyForm')(state),
// //       fields: getFormMeta('EditCompanyForm')(state),
// //       asyncErrors: getFormAsyncErrors('EditCompanyForm')(state),
// //       syncWarnings: getFormSyncWarnings('EditCompanyForm')(state),
// //       submitErrors: getFormSubmitErrors('EditCompanyForm')(state),
// //       formError: getFormError()(state),
// //       names: getFormNames()(state),
// //       dirty: isDirty('EditCompanyForm')(state),
// //       pristine: isPristine('EditCompanyForm')(state),
// //       valid: isValid('EditCompanyForm')(state),
// //       invalid: isInvalid('EditCompanyForm')(state),
// //       submitting: isSubmitting('EditCompanyForm')(state),
// //       submitSucceeded: hasSubmitSucceeded('EditCompanyForm')(state),
// //       submitFailed: hasSubmitFailed('EditCompanyForm')(state)
//      })
//   )(EditCompany)


export default reduxForm({
    form: 'EditCompanyForm',
    validate: Validation.ValidateEditCompanyForm
})(EditCompany);