import React, { Component, useState  } from 'react';
import {reset} from 'redux-form';
import { Tabs, Tab } from 'react-bootstrap';
import { reduxForm, Field, change } from 'redux-form';
import Common from '../../Common';
import Config from '../../Config';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { connect } from 'react-redux';
import ActionCreators from '../../Actions/ActionCreators';
import TablePagination from '../../Components/TablePagination';
import Pagination from './Pagination';
import Swal from 'sweetalert2';
import RenderSelect from '../../Components/SelectField';
import 'react-datepicker/dist/react-datepicker.css';
import { normalizeMaxLength, normalizeNumber, normalizeNumberAndSetLimit } from '../../Validations';
import Loader from '../../Components/Loader';




const GetPrefixCollection = (props) => {

    

    var prefixarr = Object.values(props.props);

    var currentItemId=0;

    var pc = document.getElementsByClassName("prefix-collection");

    let prefixCollection = prefixarr.map((item, index) => {
        
        return (

                <div key={index} className={"prefix-collection-main"} onClick={() => {
                         
                         props.dispatch(ActionCreators.addBtnActive(false));
                         props.changeAction(item.name, item.prefix, item.prefix_start, item.prefix_end, item.qty, item.created_by, item.supplier, item.id, item.company_id)
                       }
                     }
                    >
                        <div id="prefix-class" className="col-md-12 prefix-collection" 
                         onClick={()=> console.log()  }>
                            <div className="col-md-4">
                                <div>  {item.name}</div>
                                <div>{item.prefix}</div>
                                <div>start: {item.prefix_start}</div>
                                <div>stop: {item.prefix_end}</div>
                            </div>
                            <div className="col-md-8">
                                <div className="col-md-4 prefix-qty">Qty: {item.qty}</div>
                                <div className="col-md-8 ">
                                    <div>{item.supplier}</div>
                                    <textarea readOnly className={"insertprefixt-text-area"} defaultValue={item.supplier} onChange={this.handleChange} />
                                </div>
                            </div>
                        </div>
            </div>
        )
    });


    return prefixCollection;
}

class InsertPrefix extends Component {
    constructor(props, context) {

        super(props, context);
        this.handleSelect = this.handleSelect.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.prefixHandlechange = this.prefixHandlechange.bind(this);
        this.prefixNameHandlechange = this.prefixNameHandlechange.bind(this);
        this.onChangePage = this.onChangePage.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
        this.paginate = this.paginate.bind(this);
        this.TablePagination = React.createRef();

        this.state = {
            actionkey: 1,
            search_type: [
                { label: '13 Digit Prefix/GTIN', value: '13 Digit Prefix/GTIN' },
            ],
            startDate: moment(),
            searchByPrefix: '',
            searchByName: '',
            currentID: '',
            currentChildData: {},
            select_company: [],
            ModifyData: '',
            pageOfItems: [],
            activePage: 15,
            currentPage: 1,
            postsPerPage: 5,
            isLoading: true,
        };
    }

    handlePageChange(pageNumber) {
        // console.log(`active page is ${pageNumber}`);
        this.setState({ activePage: pageNumber });
    }

    // callbackFunction = (ChildData)=> { this.setState({ currentChildData:  ChildData})}

    handleSelect(actionkey) {
        this.setState({ actionkey });
    }

    handleChange(date) {
        this.setState({
            startDate: date
        })
    }



    prefixHandlechange(e) {

        this.setState({ currentPage: 1 });
        let searchValue = e.target.value;

        this.setState({
            searchByPrefix: searchValue.toString().substr(0, 20),
            currentID: "PrefixByPrefix"
        })

        if (searchValue.toString() == "") {
            if (this.state.searchByName != "") {
                this.setState({ currentID: "PrefixByName" });
            }
        }
    }

    prefixNameHandlechange(e) {
        //   this.setState({currentPage:1})
        let searchValue = e.target.value;
        this.setState({
            searchByName: searchValue.toString().substr(0, 20),
            currentID: "PrefixByName"
        })

        if (searchValue.toString() == "") {
            if (this.state.searchByPrefix != "") {
                this.setState({ currentID: "PrefixByPrefix" });
            }
        }

    }

    async managePrefix(values) {
        var form = document.querySelector('#insert-prefix');
        var values = serialize(form, { hash: true });
        values.token = this.props.token;

            if (!values.user_type) {
                values.user_type = this.props.user_type;
            }

             this.props.InsertPrefix(values);
           // await this.props.LoadPrefix();
             await this.props.dispatch(reset('PrefixtForm'));
    }

    async modifyPrefix(values) {

        var form = document.querySelector('#insert-prefix');
        var values = serialize(form, { hash: true });
        values.token = this.props.token;

        if (!values.user_type) {
            values.user_type = this.props.user_type;
        }

        await this.props.ModifyPrefix(values);

        //await this.props.LoadPrefix();
        this.props.dispatch(reset('PrefixtForm'));  

        this.props.dispatch(ActionCreators.addBtnActive(true));
    
    }

    async DeletePrefix(values) {
       
        Swal.fire({
            title: 'Reason',
            input: 'textarea',
            inputAttributes: {
                autocapitalize: 'off'
            },
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: () => {
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.value) {
                var form = document.querySelector('#insert-prefix');
                var values = serialize(form, { hash: true });
                values.token = this.props.token;
                values.reason = result.value;
                values.prefix_id = 4;

            
               this.props.DeletePrefix(values);
            //   Swal("Deleted!", "Data has been deleted.", "success");
            }
        }).then(() => {
          //  this.props.LoadPrefix();
        }).then(()=>{this.props.dispatch(reset('PrefixtForm')),
        this.props.dispatch(ActionCreators.addBtnActive(true))})

        
    }

    async TransferPrefix(values) {
        var form = document.querySelector('#insert-prefix');
        var values = serialize(form, { hash: true });
        values.token = this.props.token;

        if (!values.user_type) {
            values.user_type = this.props.user_type;
        }

        await this.props.TransferPrefix(values);
     //   await this.props.LoadPrefix();

        this.props.dispatch(reset('PrefixtForm'));   
        this.props.dispatch(ActionCreators.addBtnActive(true));       
      }



    searchPrefix(values) {
        var form = document.querySelector('#search-prefix');
        var values = serialize(form, { hash: true });
        values.token = this.props.token;
        this.props.SearchPrefix(values);
    }

    componentDidMount() {
        //this.props.initialize({ prefix: 'ok all values here' });
        //this.props.dispatch(change('PrefixtForm', 'prefix', 'hy i changed '));
        this.props.LoadPrefix();
        this.props.CompanyListing();
        
    }


    async suspendPrefix(values) {
        Swal.fire({
            title: 'Reason',
            input: 'textarea',
            inputAttributes: {
                autocapitalize: 'off'
            },
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: () => {
            },
            allowOutsideClick: () => !Swal.isLoading()

        }).then((result) => {
            
            if (result.value) {
                var form = document.querySelector('#insert-prefix');
                var values = serialize(form, { hash: true });
                values.token = this.props.token;
                values.reason = result.value;
                if (!values.user_type) {
                     values.user_type = this.props.user_type;
                  }

                this.props.SuspendPrefix(values);

            }
        }).then((result) => {
         //  this.props.LoadPrefix();
        }).then(()=>{ this.props.dispatch(reset('PrefixtForm')),
        this.props.dispatch(ActionCreators.addBtnActive(true));})
    }



    static getDerivedStateFromProps(props, state) {
        if (props.companylisting.length && !state.is_loaded) {
            var select_cmpany = [
                { 'label': 'Select Company', 'value': '' }
            ];
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                    'label': company.CompanyName.trim(),
                    'value': company.id,
                });
            });
            return { select_company: select_cmpany, is_loaded: true, isLoading: false };
        }
        return true;

    }


    onChangePage(pageOfItems) {
        this.setState({ pageOfItems: pageOfItems });
    }


    paginate(pageNumber) {
        this.setState({ currentPage: pageNumber })
    }

    clearItems(){
      this.props.dispatch(ActionCreators.addBtnActive(true));
      this.props.dispatch(reset('PrefixtForm'));   
    }

    render() {
        
        const { currentPage, postsPerPage } = this.state;
        const { searchByPrefix, searchByName } = this.state;
        const { prefixlisting } = this.props;

        let filteredPrefixListingByPrefix = prefixlisting.filter((prefix) => { return prefix.prefix.toLowerCase().indexOf(this.state.searchByPrefix.toLowerCase()) !== -1 });
        let filteredPrefixListingByName = prefixlisting.filter((prefix) => {  return prefix.name.toLowerCase().indexOf(this.state.searchByName.toLowerCase()) !== -1 });

        let combinedfilterPrefixListing = "";

        if (searchByPrefix !== '' && searchByName != '') {
            combinedfilterPrefixListing = prefixlisting.filter(
                (prefix) => {
                    return prefix.prefix.toLowerCase().indexOf(this.state.searchByPrefix.toLowerCase()) !== -1 &&
                    prefix.name.toLowerCase().indexOf(this.state.searchByName.toLowerCase()) !== -1
                }
            );
        }

        const indexOfLastPost = currentPage * postsPerPage;
        const indesofFirstPost = indexOfLastPost - postsPerPage;

        const currentPostsOfCombinedPrefixListing = combinedfilterPrefixListing.slice(indesofFirstPost, indexOfLastPost);
        const currentPostsOfPrefixListing = filteredPrefixListingByPrefix.slice(indesofFirstPost, indexOfLastPost);
        const currentPostsOfPrefixListingByName = filteredPrefixListingByName.slice(indesofFirstPost, indexOfLastPost);


        if (this.props.modifyprefixcode === 1) {
            // alert('Prefix Saved Successfully');
            // return <Redirect to={Config.userPath[this.props.user_type]+'prefixmanagement'}/>
            // window.location.href="#/gs1/insertprefix";
        }

        const { handleSubmit, addBtnActiveStatus } = this.props;

        const onChangePage = (pageOfItems) => this.setState({ pageOfItems: pageOfItems });

        return (

            <div className="step_3main">
                <div className="step_3main_detailsform">
                    <div className="cunitform">

                        <div className="row">
                            <div className="col-xs-12 col-sm-7 col-md-7">
                                <form id="search-prefix" className="form-inlinex">
                                <Loader showloader={this.state.isLoading} />
                                    <div className="row">
                                        <div className="col-xs-12 col-sm-12 col-md-12">

                                        {/* { console.log("  this.props.prefixDisplayMessage",   this.props.prefixDisplayMessage) } */}

                                        { this.props.prefixDisplayMessage != "" ?
                                            <div className="alert alert-success" role="alert">
                                                   { 
                                                       this.props.prefixDisplayMessage }
                                                      </div>: null
                                                    }

                                            <div className="form-group ">
                                                <label>Type</label>
                                                <Field name="searchtype" component={Common.renderSelect} type="select" id="searchtype" options={this.state.search_type} className="form-control hsmall" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-xs-12 col-sm-4 col-md-6">
                                            <div className="form-group ">
                                                <label>Prefix</label>
                                                <Field 
                                                  name="search_prefix" 
                                                  component={Common.renderInput} 
                                                  type="text" 
                                                  id="prefix" 
                                                  onChange={this.prefixHandlechange} 
                                                  placeholder="Search Prefix"
                                                  className="form-control hsmall"
                                                  />
                                            </div>
                                        </div>

                                        <div className="col-xs-12 col-sm-4 col-md-6">
                                            <div className="form-group ">
                                                <label>Supplier</label>
                                                <Field name="search_supplier"
                                                   component={Common.renderInput} 
                                                   type="text"
                                                    id="supplier" 
                                                    onChange={this.prefixNameHandlechange}
                                                    placeholder="Search Supplier" 
                                                    className="form-control hsmall"
                                                  />
                                            </div>
                                        </div>

             
                                        <div className="col-xs-12 col-sm-12 col-md-12">
                                            <div className="result-area">
                                                {
                                                    (searchByPrefix !== '' && searchByName !== '') ?

                                                        <span>
                                                            <GetPrefixCollection
                                                                props={currentPostsOfCombinedPrefixListing}
                                                                dispatch={this.props.dispatch}
                                                                changeAction={this.props.changeAction}
                                                            />

                                                            <Pagination
                                                                currentPage={this.state.currentPage}
                                                                postsPerPage={this.state.postsPerPage}
                                                                totalPosts={combinedfilterPrefixListing.length}
                                                                paginate={this.paginate}
                                                            />

                                                        </span>
                                                        :

                                                        (this.state.currentID == "PrefixByPrefix" ? (
                                                            <span>
                                                                <GetPrefixCollection
                                                                    dispatch={this.props.dispatch}
                                                                    props={currentPostsOfPrefixListing}
                                                                    changeAction={this.props.changeAction}
                                                                   
                                                                />

                                                                <Pagination
                                                                    currentPage={this.state.currentPage}
                                                                    postsPerPage={this.state.postsPerPage}
                                                                    totalPosts={filteredPrefixListingByPrefix.length}
                                                                    paginate={this.paginate}
                                                                />
                                                            </span>

                                                        ) :
                                                            (<span>
                                                                <GetPrefixCollection
                                                                    dispatch={this.props.dispatch}
                                                                    props={currentPostsOfPrefixListingByName}
                                                                    changeAction={this.props.changeAction}
                                                                  

                                                                />
                                                                <Pagination
                                                                    currentPage={this.state.currentPage}
                                                                    postsPerPage={this.state.postsPerPage}
                                                                    totalPosts={filteredPrefixListingByName.length}
                                                                    paginate={this.paginate}
                                                                />
                                                            </span>))
                                                }

                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <form id="insert-prefix" onSubmit={handleSubmit(this.managePrefix.bind(this))}>
                                <div className="col-xs-12 col-sm-5 col-md-5">
                                    <div className="pdform_column first_coumn">

                                        <div className="button-group">
                                            <button className="btn btn-primary btn-flat add" disabled={!addBtnActiveStatus}>Add</button>
                                            <button className="btn btn-primary btn-flat modify" disabled={addBtnActiveStatus} onClick={handleSubmit(this.modifyPrefix.bind(this))}>Modify</button>
                                            <button className="btn btn-primary btn-flat suspend" disabled={addBtnActiveStatus} onClick={handleSubmit(this.suspendPrefix.bind(this))}>Suspend</button>
                                            <button className="btn btn-primary btn-flat delete" disabled={addBtnActiveStatus} onClick={handleSubmit(this.DeletePrefix.bind(this))}>Delete</button>
                                            <button className="btn btn-primary btn-flat clear" type="reset" disabled={addBtnActiveStatus}  onClick={this.clearItems.bind(this)}>Clear</button>
                                        </div>

                                        <div className="form-group ">
                                            <label>Brand Owner</label>
                                            <div className="row">
                                                <div className="col-xs-12 col-sm-5 col-md-8">
                                                    <RenderSelect options={this.state.select_company} className="form-control hsmall arrow" name="company_id" id="company_id" />
                                                </div>
                                                <div className="col-xs-12 col-sm-5 col-md-4">
                                                    <button className="btn btn-primary btn-flat transfer_to" disabled={addBtnActiveStatus} onClick={handleSubmit(this.TransferPrefix.bind(this))}>Transfer To..</button>
                                                </div>
                                            </div>
                                            {/* <Field name="name" component={Common.renderInput} type="text" id="name" className="form-control hsmall" value={this.state.company_name} /> */}
                                        </div>

                                        <div className="form-group ">
                                            <label>Prefix</label>
                                            <Field name="prefix"
                                                component={Common.renderInput}
                                                type="text"
                                                id="prefix" 
                                                className="form-control hsmall" 
                                                normalize = {normalizeNumberAndSetLimit(30)} 
                                              />
                                        </div>
                                        <div className="form-group ">
                                            <label>Start</label>
                                            <Field name="prefix_start"
                                                   component={Common.renderInput} type="text" id="prefix_start" className="form-control hsmall"
                                                   normalize = {normalizeNumber} 
                                             />
                                        </div>

                                        <div className="form-group ">
                                            <label>Stop</label>
                                            <Field name="prefix_end" component={Common.renderInput} type="text" id="prefix_end" className="form-control hsmall"
                                            normalize = {normalizeNumber} 
                                             />
                                        </div>

                                        <div className="form-group ">
                                            <label>Qty</label>
                                            <Field name="qty" component={Common.renderInput} type="text" id="qty" className="form-control hsmall" 
                                            normalize = {normalizeNumber} 
                                            />
                                        </div>

                                        {/* <div className="form-group ">
                                                <label>Date Created</label>
                                                <DatePicker
                                                    selected={ this.state.startDate }
                                                    onChange={ this.handleChange }
                                                    name="date_created"
                                                    dateFormat="MM/DD/YYYY"
                                                    className="form-control hsmall"
                                                />
                                            </div> */}
                                        <div className="form-group ">
                                            <label>Created By</label>
                                            <Field name="created_by" component={Common.renderInput} type="text" id="created_by" className="form-control hsmall" 
                                                   normalize = {normalizeMaxLength(100)} 
                                            />
                                        </div>
                                        <div className="form-group ">
                                            <label>Supplier</label>
                                            <Field name="supplier" component="textarea"  type="textarea" id="supplier" className="form-control textarea" />
                                        </div>
                                        <div className="form-group hide">
                                            <label>ID</label>
                                            <Field name="id" component={Common.renderInput}  type="text" id="id" className="form-control" />
                                        </div>
                                        <div className="form-group hide">
                                            <label>Name</label>
                                            <Field name="name" component={Common.renderInput} type="text" id="name" className="form-control" />
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        );
    }
}



const Form = reduxForm({
    form: 'PrefixtForm',
    validate: Validation.ValidatePrefixForm
})(InsertPrefix);



const mapDispatchToProps = (dispatch) => {

    return {
        //dispatch
            changeAction(name, prefix, prefix_start, prefix_end, qty, created_by, supplier, id, company_id) {
                dispatch(change('PrefixtForm', 'name', name));
                dispatch(change('PrefixtForm', 'company_id', company_id));
                dispatch(change('PrefixtForm', 'prefix', prefix));
                dispatch(change('PrefixtForm', 'prefix_start', prefix_start));
                dispatch(change('PrefixtForm', 'prefix_end', prefix_end));
                dispatch(change('PrefixtForm', 'qty', qty));
                dispatch(change('PrefixtForm', 'created_by', created_by));
                dispatch(change('PrefixtForm', 'supplier', supplier));
                return dispatch(change('PrefixtForm', 'id', id));
        }
    }
}

const mapStateToProps = (state) => {
    return {
        addBtnActiveStatus: state.prefixlist.addBtnActive,
      //  currentSelectedID: currentSelectedID

    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Form);


// company_id: "207"
// created_by: "8"
// prefix: "321321321321321     "
// prefix_end: "321343245353543"
// prefix_start: "34343"
// qty: "8"
// supplier: "fjdkslfjls"
// token: "af77ac51e67348f8a8b39711cee7ba16"
// user_type: 4



// if(state.form.PrefixtForm.values)
//          currentSelectedID = state.form.PrefixtForm.values.id;