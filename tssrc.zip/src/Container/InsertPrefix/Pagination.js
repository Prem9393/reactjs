

import React, { useState } from 'react';



const setPage = (page, totalPages) => {
  if (page < 1 || page > totalPages) {
    return;
  } else {
    return page;
  }
}


const Pagination = ({ currentPage, postsPerPage, totalPosts, paginate }) => {
  //  function Pagination (currentPage, postsPerPage, totalPosts, paginate){
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }


  var currentPageNumbers = [];
  if (pageNumbers.length <= 5) {
    currentPageNumbers = pageNumbers;
  } else {
    for (let i = currentPage; i < currentPage + 5; i++) {
      if (currentPage + 4 > pageNumbers.length) {
        for (let i = pageNumbers.length - 4; i <= pageNumbers.length; i++) {
          currentPageNumbers.push(i);
        }
        break;
      }
      currentPageNumbers.push(i);
    }
  }


  if (pageNumbers.length <= 1) {
    // don't display pager if there is only 1 page
    return null;
  }

  return (<nav>
    <ul className="pagination">
      <li className={currentPage === 1 ? 'btn-disable' : ''}>
        <a onClick={() => paginate(1)} >«</a>
      </li>
      <li className={currentPage === 1 ? 'btn-disable' : ''}>
        <a onClick={() => paginate(setPage(currentPage - 1, pageNumbers.length))} >⟨</a>
      </li>
      {
        currentPage != 1 && pageNumbers.length > 5 ?
          <li className={'page-item'}>
            <a>
              {'...'}
            </a>
          </li> : ''
      }
      {
        currentPageNumbers.map(number => (
          <li key={number} className={'page-item'}>
            <a onClick={() => paginate(number)} className={currentPage === number ? 'active-btn' : ''} >
              {
                number
              }
            </a>
          </li>
        ))

      }

      {
        (pageNumbers.length > 5 && currentPage < pageNumbers.length - 4) ?
          <li className={'page-item'}>
            <a>
              {'...'}
            </a>
          </li> : ''
      }

      <li className={currentPage === pageNumbers.length ? 'btn-disable' : ''}>
        <a onClick={() => { paginate(currentPage + 1) }} > ⟩ </a>
      </li>
      <li className={currentPage === pageNumbers.length ? 'btn-disable' : ''}>
        <a onClick={() => paginate(pageNumbers.length)} >»</a>
      </li>
    </ul>
  </nav>);
}

export default Pagination;


