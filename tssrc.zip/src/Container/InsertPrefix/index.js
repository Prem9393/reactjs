import React, { Component } from 'react';
import Config from '../../Config';
import {Provider, connect} from 'react-redux';

import InsertForm from './InsertPrefix';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';

const mapStateToProps = (state) => ({
    auth:state.auth.auth,
    token:state.auth.token,
    user_type:state.auth.user_type,
    modifyprefixcode:state.modifyprefix.insertcode,
    modifyprefixmsg:state.modifyprefix.insertmessage,
    searchlist:state.searchprefix.searchlist,
    prefixlisting:state.prefixlist.prefixlisting,
    addBtnActiveStatus: state.prefixlist.addBtnActive,
    prefixCurrentPageData:state.prefixlist.prefixCurrentPageData,
    companylisting:state.companylist.companylisting,
    prefixDisplayMessage:state.prefixlist.prefixDisplayMessage,
    insertprefixlisting:state.insertprefix.prefixlisting
})


const mapDispatchToProps = (dispatch) => ({
    InsertPrefix: (values) => dispatch(ActionCreators.InsertPrefix(values)),
    LoadPrefix: (values) => dispatch(ActionCreators.PrefixListing(values)),
    ModifyPrefix: (values) => dispatch(ActionCreators.ModifyPrefix(values)),
    DeletePrefix: (values) => dispatch(ActionCreators.DeletePrefix(values)),
    SearchPrefix: (values) => dispatch(ActionCreators.SearchPrefix(values)),
    addBtnActive: (values) => dispatch(ActionCreators.addBtnActive(values)),
    CompanyListing: (values) => dispatch(ActionCreators.CompanyListing(values)),
    TransferPrefix: (values) => dispatch(ActionCreators.TransferPrefix(values)),
    SuspendPrefix: (values) => dispatch(ActionCreators.SuspendPrefix(values))
})
  
const InsertPrefixComponent  = connect(mapStateToProps, mapDispatchToProps)(InsertForm);

class InsertPrefix extends Component {
    
    componentDidMount(){
        document.title=Config.name+' Prefix';
    }
    render(){
        return  <Provider store={AppStore}><InsertPrefixComponent/></Provider>
    }
}


export default InsertPrefix;


