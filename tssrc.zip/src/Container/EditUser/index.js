import React, { Component } from 'react';
import Config from '../../Config';
import { Provider, connect } from 'react-redux';

import EditForm from './EditUser';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    user_details:state.loaduserformdata.user_details,
    id:state.auth.id,
    user_auth:state.auth,
    companylisting:state.companylist.companylisting,
    updatecode:state.updateuser.updatecode,
    editusermessage: state.updateuser.updateusermessage,
    updatedisplaystatus: state.updateuser.updatedisplaystatus,    
    languagelisting: state.languagelisting.languagelisting
})


const mapDispatchToProps = (dispatch) => ({
    UpdateUser: (values) => dispatch(ActionCreators.UpdateUser(values)),
    loadUserFormData: (values) => dispatch(ActionCreators.loadUserFormData(values)),    
    CompanyListing: (values) => dispatch(ActionCreators.CompanyListing(values)),
    getLanguageCode: (values) => dispatch(ActionCreators.getLanguageCode(values)),
})

const EditUserComponent = connect(mapStateToProps, mapDispatchToProps)(EditForm);

class EditUser extends Component {
    
    componentDidMount() {
        document.title = Config.name + ' Edit User';
    }
    
    render() {
        return <Provider store={AppStore}><EditUserComponent {...this.props} /></Provider>
    }
}


export default EditUser;


