import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import Config from '../../Config';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect } from 'react-router-dom';
import Loader from '../../Components/Loader';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import { Button } from 'react-bootstrap';
import FileBase64 from 'react-file-base64';
import styles from './adminlte.css';

import { normalizeNumberAndSetLimit } from '../../Validations';

class EditUser extends Component {
    constructor(props, context) {
        super(props, context);
        this.manageUser = this.manageUser.bind(this);
        this.state = {
            actionkey: 1,
            files:'',
            select_options: [
                {label: 'Select User Type', value: ''},
                {label: 'Supplier', value: '1'},
                {label: 'Retailer', value: '2'},
                {label: 'GS1User', value: '3'},
                {label: 'TrustedSource', value: '4'},
            ],
            showResults: false,
            select_company: [],
            select_language: [],
            user_details: [],
            user_details_loaded: false,
            isLoading: true,
            user_type_selected: '',
            editUserCode: false
        };

    }    

    componentDidMount() {
        this.setState({editUserCode: true})
        
        let id = this.props.match.params.id;
        this.props.CompanyListing();
        if (id !== 'undefined') {
            var form_details = {
                token: this.props.token,
                user_id: id
            }
            this.props.loadUserFormData(form_details);
        }
        var token_value = {
            token: this.props.token
        }
        document.title = Config.name + ' - Edit User';
        
    }
    getFiles(files){
        this.setState({ files: files })
    }

    
     static getDerivedStateFromProps(props, state) {

        

         if (props.user_details.hasOwnProperty('id') && props.companylisting.length && !state.user_details_loaded && props.match.params.id == props.user_details.id) {
             props.initialize(props.user_details);
             
            var select_cmpany = [
                {'label': 'Select Company','value': ''}
            ];

            // var companylisting=[];
        
            // companylisting = props.companylisting;
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                        'label' : company.CompanyName.trim(),
                        'value' : company.id,
                });
            });
            var select_language = [
                {'label': 'Select Language','value': ''}
            ];
            
       //    try{
                if(props.languagelisting.length && props.languagelisting != [] && 
                    props.languagelisting != ""){
                        
                    console.log("props.languagelisting",props);
                    props.languagelisting.forEach((language, index) => {
                        select_language.push({
                                'label' : language.LanguageName.trim(),
                                'value' : language.LanguageCode.trim(),
                        });
                    });
                }

        //   }
        //   catch(e){
       //        console.log("edit lang list error", e);
       //    }
           
            
           // console.log("company",select_cmpany);

             return {
                 select_company : select_cmpany,
                 select_language:select_language,
                 user_details_loaded: true,
                 isLoading: false,
                 user_type_selected: props.user_details.user_type.trim()
             }
         } else {
             return;
         }
     }
     togglePassword(){
        this.setState({ showResults: true });
     }

    manageUser(field_values) {

        let form = document.querySelector('#edit-user');
        let values = serialize(form, { hash: true });
        let userid = this.props.match.params.id;
       // values.user_type = this.props.user_type;
        values.user_image = '';

        //console.log("field_values", field_values); 

        if(this.state.files.base64){
            values.user_image = this.state.files.base64
        }

        if(!values.user_type && this.props.user_type == 1){
            values.user_type = 5;
        }
        if(!values.user_type && this.props.user_type == 2){
            values.user_type = 6;
        }

        if(!values.user_type){
            values.user_type = this.props.user_type;
        }
        values.created_role = this.props.user_type;
        values.created_by = this.props.id;

        

        console.log("update values", values, this.props);
        
        this.props.UpdateUser(values);
    }


    render() {
        if (this.props.updatecode === 1 && this.state.editUserCode) {
            //alert('User Updated Successfully');
            return <Redirect to={Config.userPath[this.props.user_type] + 'usermanagement'} />
        }
      

        const { handleSubmit } = this.props;

        return (
            <div>
                { 
                     this.props.updatedisplaystatus.message ? 
                     <div className="alert alert-danger" role="alert">
                         Something went wrong. Please try again
                     </div>:""
                 }
            
                <Loader showloader={this.state.isLoading}/>
                <section className="content">
                  <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-3">
                          <div className="card card-primary card-outline">
                            <div className="card-body box-profile">
                              <div className="text-center">
                                  <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                  <img src={(this.props.user_details.user_image) ? Config.user_img_path + this.props.user_details.user_image : Config.assetspath + 'default.png'} className="profile-user-img img-fluid img-circle" alt="" width="128" />                  
                              </div>

                              <h3 className="profile-username text-center">{this.props.user_details.first_name} {this.props.user_details.last_name}</h3>

                              <p className="text-muted text-center">{this.state.user_type_selected}</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-9">
                          <div className="card">
                            <form className="form-horizontal"  onSubmit={handleSubmit(this.manageUser.bind(this))} id="edit-user">
                              <div className="form-group row">
                                <label for="inputName" className="col-sm-2 col-form-label">Name</label>
                                <div className="col-sm-10">
                                  <input type="email" className="form-control" id="inputName" placeholder="Name" />
                                </div>
                              </div>
                              <div className="form-group row">
                                <label for="inputEmail" className="col-sm-2 col-form-label">Email</label>
                                <div className="col-sm-10">
                                  <input type="email" className="form-control" id="inputEmail" placeholder="Email" />
                                </div>
                              </div>
                              <div className="form-group row">
                                <label for="inputName2" className="col-sm-2 col-form-label">Name</label>
                                <div className="col-sm-10">
                                  <input type="text" className="form-control" id="inputName2" placeholder="Name" />
                                </div>
                              </div>
                              <div className="form-group row">
                                <label for="inputExperience" className="col-sm-2 col-form-label">Experience</label>
                                <div className="col-sm-10">
                                  <textarea className="form-control" id="inputExperience" placeholder="Experience"></textarea>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label for="inputSkills" className="col-sm-2 col-form-label">Skills</label>
                                <div className="col-sm-10">
                                  <input type="text" className="form-control" id="inputSkills" placeholder="Skills" />
                                </div>
                              </div>
                              <div className="form-group row">
                                <div className="offset-sm-2 col-sm-10">
                                  <div className="checkbox">
                                    <label>
                                      <input type="checkbox" /> I agree to the <a href="#">terms and conditions</a>
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div className="form-group row">
                                <div className="offset-sm-2 col-sm-10">
                                  <button type="submit" className="btn btn-danger">Submit</button>
                                </div>
                              </div>

                              <div className="form-group row">
                                  <label>First Name</label>
                                  <div className="col-sm-10">
                                    <Field name="first_name" component={Common.renderInput} type="text" id="first_name" value={this.props.user_details.first_name} className="form-control hsmall" />
                                  </div>
                              </div>                                           
                              <div className="form-group row">
                                  <label>Last Name</label>
                                  <div className="col-sm-10">
                                    <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" value={this.props.user_details.last_name} className="form-control hsmall" />
                                  </div>
                              </div>  
                              <div className="form-group row" >
                                  <label>Email</label>
                                  <div className="col-sm-10">
                                    <Field readOnly name="email" component={Common.renderInput} id="email" value={()=> this.props.user_details.email } className="form-control hsmall"/>
                                  </div>
                              </div>                              
                              <div className="form-group hide">
                                  <label>User Type</label> 
                                  <div className="col-sm-10">
                                    <Field selected_value={this.state.user_type_selected} options={this.state.select_options}  className="form-control hsmall arrow" label="User Type" name="user_type" id="user_type" component={Common.renderSelect} disabled={true}></Field> 
                                  </div>
                              </div> 
                              <div className="form-group hide">
                                <div className="col-sm-10">
                                  <Field name="id" component={Common.renderInput} type="text" id="id" className="form-control hsmall" value={this.props.user_details.id}/>
                                </div>
                              </div> 
                              <div className="form-group row">
                                  <label>Telephone</label>
                                  <div className="col-sm-10">
                                    <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                    normalize={ normalizeNumberAndSetLimit(30)  } 
                                    />
                                  </div>
                              </div>                                       
                              <div className="form-group row">
                                  <label>User Name</label>
                                  <div className="col-sm-10">
                                    <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  value={this.props.user_details.user_name}/>
                                  </div>
                              </div>
                              <div className="form-group row">
                                  <a className="forget-password" href="javascript:void(0);" onClick={this.togglePassword.bind(this)}>Forget Password</a>
                              </div>
                              { this.state.showResults ?   
                                <div className="form-group row">
                                    <label>New Password</label>
                                    <div className="col-sm-10">
                                      <Field name="user_password" component={Common.renderInput} type="password" id="password" className="form-control hsmall"/>
                                    </div>
                                </div>: null 
                              }                                        
                              {this.props.user_type == 4 ? 
                                <fieldset disabled={this.props.user_details.user_type == 1 && this.props.user_details.user_company != '' || this.props.user_details.user_type == 2 && this.props.user_details.user_company != '' }>
                                    <div className="form-group row">
                                        <label>User Company</label>
                                        <div className="col-sm-10">                 
                                          <RenderSelect 
                                              options={this.state.select_company}    
                                              className="form-control hsmall arrow" 
                                              name="user_company" 
                                              id="user_company" 
                                          />
                                        </div>      
                                    </div>
                                    </fieldset>  : null 
                              } 
                              <div className="form-group row">
                                  <label>Language</label>
                                  <div className="col-sm-10">
                                    <RenderSelect 
                                        options={this.state.select_language}  
                                        className="form-control hsmall arrow" 
                                        name="userLanguage"
                                        id="userLanguage" 
                                    />
                                  </div> 
                                </div> 
                                {/* <div className="form-group row">
                                    <label>User Image</label>
                                    <div className="col-sm-10">
                                      <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                      <img src={(this.props.user_details.user_image) ? Config.user_img_path + this.props.user_details.user_image : Config.assetspath + 'default.png'} alt="" width="200"/>
                                    </div>
                                </div>  */}
                            </form>
                          </div>
                        </div>
                    </div>
                  </div>
                </section>
                <form onSubmit={handleSubmit(this.manageUser.bind(this))} id="edit-user">
                <div className="step_3main">
                    <div className="step_3main_detailsform">
                        <div className="col-xs-12 col-sm-12 col-md-12">
                            <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-5">
                                    <div className="pdform_column first_coumn">
                                        <div className="form-group"  >
                                            <label>First Name</label>
                                            <Field name="first_name" component={Common.renderInput} type="text" id="first_name" value={this.props.user_details.first_name} className="form-control hsmall" />
                                        </div>           

                                        <div className="form-group" tabIndex="2" >
                                            <label>Last Name</label>
                                            <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" value={this.props.user_details.last_name} className="form-control hsmall" />
                                        </div>  
                                        <div className="form-group" >
                                            <label>Email</label>
                                            
                                            <Field readOnly name="email" component={Common.renderInput} id="email" value={()=> this.props.user_details.email } className="form-control hsmall"/>
                                        </div>                              
                                        {/* <div className="form-group ">
                                            <label>InformationProviderGLN</label>
                                            <Field name="InformationProviderGLN" component={Common.renderInput} type="text" id="InformationProviderGLN" className="form-control hsmall" value={this.props.user_details.InformationProviderGLN} />
                                        </div> */}
                                    
                                        {/* <div className="form-group ">
                                            <label>Password</label>
                                            <Field name="password" component={Common.renderInput} type="password" id="password" className="form-control hsmall" />
                                        </div> */}
                                        
                                        
                                    
                                        {/* <div className="form-group ">
                                            <label>User Image</label>
                                            <Field name="user_image" component={Common.renderInput} type="text" id="user_image" className="form-control hsmall" />
                                        </div> */}
                                        <div className="form-group hide">
                                            <label>User Type</label>
                                            {/* <Select id="user-type-select" 
                                                options={this.state.select_options}
                                                clearable={true} 
                                                name="UserType" 
                                                searchable={true} 
                                                placeholder={false}                                                        
                                            /> */}

                                            <Field selected_value={this.state.user_type_selected} options={this.state.select_options}  className="form-control hsmall arrow" label="User Type" name="user_type" id="user_type" component={Common.renderSelect} disabled={true}>
                                            </Field>
                                            {/* <RenderSelect options={this.state.select_options} selected_value={this.props.user_details.user_type} className="form-control hsmall arrow" name="user_type" id="user_type" /> */}
                                        </div>
                                        
                                        <div className="form-group hide">
                                            <Field name="id" component={Common.renderInput} type="text" id="id" className="form-control hsmall" value={this.props.user_details.id}/>
                                        </div> 
                                        <div className="form-group ">
                                            <label>Telephone</label>
                                            <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                             normalize={ normalizeNumberAndSetLimit(30)  } 
                                             />
                                        </div>                                       
                                        <div className="form-group ">
                                            <label>User Name</label>
                                            <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  value={this.props.user_details.user_name}/>
                                        </div>
                                        <div className="form-group">
                                            <a className="forget-password" href="javascript:void(0);" onClick={this.togglePassword.bind(this)}>Forget Password</a>
                                            { this.state.showResults ?   
                                                <div className="form-group ">
                                                    <label>New Password</label>
                                                    <Field name="user_password" component={Common.renderInput} type="password" id="password" className="form-control hsmall"/>
                                                </div>: null }
                                        </div>                                        
                                        {this.props.user_type == 4 ? 
                                        <fieldset disabled={this.props.user_details.user_type == 1 && this.props.user_details.user_company != '' || this.props.user_details.user_type == 2 && this.props.user_details.user_company != '' }>
                                            <div className="form-group ">
                                                <label>User Company</label>                                 
                                             <RenderSelect 
                                                options={this.state.select_company}    
                                                className="form-control hsmall arrow" 
                                                name="user_company" 
                                                id="user_company" 
                                             />      
                                            </div>
                                            </fieldset>  : null } 

                                            <div className="form-group ">
                                                <label>Language</label>
                                                  <RenderSelect 
                                                     options={this.state.select_language}  
                                                     className="form-control hsmall arrow" 
                                                     name="userLanguage"
                                                     id="userLanguage" 
                                                 />  
                                             </div> 

                                            <div className="form-group">
                                                <label>User Image</label>
                                                <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                                <img src={(this.props.user_details.user_image) ? Config.user_img_path + this.props.user_details.user_image : Config.assetspath + 'default.png'} alt="" width="200"/>
                                                {/* <img src={Config.user_img_path + this.props.user_details.user_image} width="100" /> */}
                                            </div> 
                                            
                                        </div>                                        
                                    </div>
                                    <div className="col-xs-12 col-sm-5 col-md-5">
                                        <div className="pdform_column second_coumn">
                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        <th>Permission</th>
                                                        <th>Access Type</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Company Management: View</td>
                                                        <td><Field name="IsView" id="IsView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 }/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Company Management: Modify</td>
                                                        <td><Field name="IsModify" id="IsModify" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 } /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Company Management - User: View</td>
                                                        <td><Field name="IsUserView" id="IsUserView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 } /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Company Management - User: Modify</td>
                                                        <td><Field name="IsUserModify" id="IsUserModify" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3} /></td>
                                                    </tr>
                                                    {/* <tr>
                                                        <td>Company Management - User: Delete</td>
                                                        <td><Field name="IsUserDelete" id="IsUserDelete" component="input" type="checkbox" value="1" /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Product Data & Tools: My product Data</td>
                                                        <td><Field name="MyProductData" id="MyProductData" component="input" type="checkbox" value="1" /></td>
                                                    </tr> */}
                                                    <tr>
                                                        <td>Product Data & Tools: Product: View</td>
                                                        <td><Field name="IsProductView" id="IsProductView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 } /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Product Data & Tools: Product: Modify</td>
                                                        <td><Field name="IsProductEdit" id="IsProductEdit" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 } /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Product Data & Tools: Product: Uploads</td>
                                                        <td><Field name="IsProductUpload" id="IsProductUpload" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4 || this.props.user_details.user_type == 3 } /></td>
                                                    </tr>                                                      
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                    </div> 
                                <div className="col-xs-12 col-sm-2 col-md-2">
                                    <div className="saveform">   
                                        <div className="save_btn">
                                            <Button type="submit" id="cu_status_save_option" 
                                            className="btn-save"
                                             value="Save">Save</Button>
                                        </div>                                        
                                    </div>
                                </div>   
                            </div>
                        </div>                      
                    </div>
                </div>
            </form>
            </div>
        );
    }
}

export default reduxForm({
    form: 'EditUserForm',
    validate: Validation.ValidatEditUserForm
})(EditUser);




