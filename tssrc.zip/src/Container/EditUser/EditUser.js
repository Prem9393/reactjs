import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import Config from '../../Config';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect, Link } from 'react-router-dom';
import Loader from '../../Components/Loader';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import { Button } from 'react-bootstrap';
import FileBase64 from 'react-file-base64';
import './EditUser.css';
import { Tabs, Tab } from 'react-bootstrap';
import PropTypes from 'prop-types';
import SlidingPane from 'react-sliding-pane';
import EditUserDetails from './EditUserDetails';

import { normalizeNumberAndSetLimit } from '../../Validations';

class EditUser extends Component {
    constructor(props, context) {
        super(props, context);

        this.manageUser = this.manageUser.bind(this);
        this.OpenPanel = this.OpenPanel.bind(this);
        this.selectedCompany = this.selectedCompany.bind(this);

        this.state = {
            actionkey: 1,
            files:'',
            select_options: [
                {label: 'Select User Type', value: ''},
                {label: 'Supplier', value: '1'},
                {label: 'Retailer', value: '2'},
                {label: 'GS1User', value: '3'},
                {label: 'TrustedSource', value: '4'},
            ],
            showResults: false,
            select_company: [],
            select_language: [],
            user_details: [],
            user_details_loaded: false,
            isLoading: true,
            user_type_selected: '',
            editUserCode: false,
            userCanEditField : false,
            isPaneOpen: false,
            isPaneOpenLeft: false,

            selected_profile : "",
            selected_company: "",
            selected_user_type : "",
            selected_language : "",
            selected_username : "",
            selected_first_name : "",
            selected_last_name : "",
            selected_email : "",
            selected_phone : "",
            selected_InformationProviderGLN : ""
        };
    }
    
    OpenPanel() {
        this.setState({
            isPaneOpen: !(this.state.isPaneOpen)
        });
    }

    selectedCompany(event,value){
        var index = event.target.selectedIndex;
        //console.log('--index--',index,'--id--',event.target[index].text,'--target--',value);
         this.setState({
             selected_company: event.target[index].text
         });

    }

    componentWillMount(){
        this.props.getLanguageCode(); 
    }

    componentDidMount() {
        this.setState({editUserCode: true})
        
        let id = this.props.match.params.id;
        this.props.CompanyListing();
        if (id !== 'undefined') {
            var form_details = {
                token: this.props.token,
                user_id: id
            }
            this.props.loadUserFormData(form_details);
        }
        var token_value = {
            token: this.props.token
        }
        document.title = Config.name + ' - Edit User';
        
    }
    getFiles(files){
        this.setState({ files: files })       
    }

    
     static getDerivedStateFromProps(props, state) {

          const { languagelisting } = props;
        
           if(props.updatedisplaystatus.message)  
            return  {isLoading: false};

         if (props.user_details.hasOwnProperty('id') && props.companylisting.length && !state.user_details_loaded && props.match.params.id == props.user_details.id) {
             props.initialize(props.user_details);
             
            var select_cmpany = [
                {'label': 'Select Company','value': ''}
            ];
            
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                        'label' : company.CompanyName.trim(),
                        'value' : company.id,
                });
            });

            var select_language = [
                {'label': 'Select Language','value': ''}
            ];

          try{
                if(typeof languagelisting !== 'string' && languagelisting.length > 0 && languagelisting.length != undefined && 
                    languagelisting != [] && 
                    languagelisting != "" ){
                        
                    console.log("props.languagelisting",props);

                    languagelisting.forEach((language, index) => {
                        select_language.push({
                                'label' : language.LanguageName.trim(),
                                'value' : language.LanguageCode.trim(),
                        });

                    });

                }

          }
          catch(e){
              console.log("edit lang list error", e);
          }
           
       
             return {
                 select_company : select_cmpany,
                 select_language:select_language,
                 user_details_loaded: true,
                 isLoading: false,
                 user_type_selected: props.user_details.user_type.trim(),

                 selected_InformationProviderGLN : props.user_details.InformationProviderGLN,
                 selected_company:props.user_details.user_company,
                 selected_user_type : props.user_details.user_type,
                 selected_language : props.user_details.userLanguage,
                 selected_username : props.user_details.user_name,
                 selected_first_name : props.user_details.first_name,
                 selected_last_name : props.user_details.last_name,
                 selected_email : props.user_details.email,
                 selected_phone : props.user_details.user_telephone,
                 selected_profile : props.user_details.user_image
             }
         } else {
             return true;
         }
     }
     togglePassword(){
        this.setState({ showResults: true });
     }

    manageUser(field_values) {

        this.setState({isLoading: true});

        let form = document.querySelector('#edit-user');
        let values = serialize(form, { hash: true });
        let userid = this.props.match.params.id;
       // values.user_type = this.props.user_type;
        values.user_image = '';

        //console.log("field_values", field_values);

        if(this.state.files.base64){
            values.user_image = this.state.files.base64
        }

        if(!values.user_type && this.props.user_type == 1){
            values.user_type = 5;
        }
        if(!values.user_type && this.props.user_type == 2){
            values.user_type = 6;
        }

        if(!values.user_type){
            values.user_type = this.props.user_type;
        }
        values.created_role = this.props.user_type;
        values.created_by = this.props.id;
    
        console.log("update values", values, this.props);
        this.props.UpdateUser(values);
    }

    handleUserCanEditField(e){
        e.preventDefault();
        this.setState(previousState => {
            return{
                userCanEditField : !previousState.userCanEditField
            }
        });
    }

    render() {
        if (this.props.updatecode === 1 && this.state.editUserCode) {
            //alert('User Updated Successfully');
            return <Redirect to={Config.userPath[this.props.user_type] + 'usermanagement'} />
        }
      

        const { handleSubmit } = this.props;

        return (
            <fieldset disabled={this.props.user_auth.is_user_modify != 1}>
            <div className="user-management-view">
                  { 
                         this.props.updatedisplaystatus.message ? 
                            <div className="alert alert-danger" role="alert">
                              Something went wrong. Please try again
                            </div>:""
                    }
            
              { 
               console.log("main props", this.props) }

                <Loader showloader={this.state.isLoading}/>

                {/* New Tag  */}
                    <div className="user-management-view-card">
                        <div className="account_info">
                            
                            <div className="row">
                                <div className="col-md-4">
                                    <span className="title">
                                        {this.state.selected_first_name}  {this.state.selected_last_name}
                                    </span>
                                </div>
                                <div className="col-md-2">
                                    <span className="text-danger" > DELETE </span>
                                </div>
                                <div className="col-md-2">
                                    <span className="btn btn-primary" onClick={this.OpenPanel}> Edit User </span>
                                </div>
                                <div className="col-md-2"></div>
                            </div>                            
                            
                            <h3>
                                <img src="assets/images/phone.svg" class="setting-img" /> Account Info
                            </h3>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="col-sm-4">
                                        <p><span>GLN</span></p>
                                    </div>
                                    <div className="col-sm-4">
                                        {this.state.selected_InformationProviderGLN}
                                    </div> 
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="col-sm-4">
                                        <p><span>COMPANY</span></p>
                                    </div>
                                    <div className="col-sm-4">
                                        { this.state.selected_company}
                                    </div> 
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="col-sm-4">
                                        <p><span>TYPE</span></p>
                                    </div>
                                    <div className="col-sm-4">
                                        {this.state.selected_user_type}
                                    </div> 
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="col-sm-4">
                                        <p><span>LANGUAGE</span></p>
                                    </div>
                                    <div className="col-sm-4">
                                        {this.state.selected_language}
                                    </div> 
                                </div>
                                <div className="col-md-2"></div>
                            </div>

                            <div className="personal_info">
                                <h3>
                                    <img src="assets/images/phone.svg" class="setting-img" />Personal Info
                                </h3>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>PROFILE IMAGE</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            <img src={(this.state.selected_profile) ? this.state.selected_profile + this.props.user_details.user_image : Config.companylogopath + 'default.png'} alt="" width="100" className="profile-user-img img-responsive img-circle" id="profileImg" />
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>FIRST NAME</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            {this.state.selected_first_name}
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>LAST NAME</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            {this.state.selected_last_name}
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>EMAIL</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            {this.state.selected_email}
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>PHONE</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            {this.state.selected_phone}
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                                <div className="row">
                                    <div className="col-md-2"></div>
                                    <div className="col-md-8">
                                        <div className="col-sm-4">
                                            <p><span>USERNAME</span></p>
                                        </div>
                                        <div className="col-sm-4">
                                            {this.state.selected_username}
                                        </div> 
                                    </div>
                                    <div className="col-md-2"></div>
                                </div>
                            </div>
                        </div>

                        <div ref={ref => this.el = ref}>
                        {/* title={<button style={{ "float": "right", "marginRight": "20px" }} className="btn btn-primary btn-flat"></button>} */}
                            <SlidingPane
                                className='some-custom-class'
                                overlayClassName='some-custom-overlay-class'
                                isOpen={this.state.isPaneOpen}
                                onRequestClose={() => {
                                    this.setState({ isPaneOpen: false });
                                }}>
                                <EditUserDetails getFiles={this.getFiles} handleChange={this.handleChange} onChange={this.onChange} handlePanel={this.OpenPanel} {...this.state} {...this.props} />
                            </SlidingPane>
                        </div>
                </div>
            </div>
        </fieldset>

        );
    }
}



// EditUser.propTypes ={
//     languagelisting: PropTypes.object.isRequired
// }




export default reduxForm({
    form: 'EditUserForm',
    validate: Validation.ValidatEditUserForm
})(EditUser);




