import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import Config from '../../Config';
import Validation from '../../Validations';
import serialize from 'form-serialize';
import { Redirect } from 'react-router-dom';
import Loader from '../../Components/Loader';
import RenderSelect from '../../Components/SelectField';
import Common from '../../Common';
import { Button } from 'react-bootstrap';
import FileBase64 from 'react-file-base64';
import './EditUser.css';
import { Tabs, Tab } from 'react-bootstrap';
import PropTypes from 'prop-types';

import { normalizeNumberAndSetLimit } from '../../Validations';

class EditUser extends Component {
    constructor(props, context) {
        super(props, context);
        this.manageUser = this.manageUser.bind(this);
        this.state = {
            actionkey: 1,
            files:'',
            select_options: [
                {label: 'Select User Type', value: ''},
                {label: 'Supplier', value: '1'},
                {label: 'Retailer', value: '2'},
                {label: 'GS1User', value: '3'},
                {label: 'TrustedSource', value: '4'},
            ],
            showResults: false,
            select_company: [],
            select_language: [],
            user_details: [],
            user_details_loaded: false,
            isLoading: true,
            user_type_selected: '',
            editUserCode: false,
            userCanEditField : false
        };
    }    

    componentWillMount(){
        this.props.getLanguageCode(); 
    }

    componentDidMount() {
        this.setState({editUserCode: true})
        
        let id = this.props.match.params.id;
        this.props.CompanyListing();
        if (id !== 'undefined') {
            var form_details = {
                token: this.props.token,
                user_id: id
            }
            this.props.loadUserFormData(form_details);
        }
        var token_value = {
            token: this.props.token
        }
        document.title = Config.name + ' - Edit User';
        
    }
    getFiles(files){
        this.setState({ files: files })       
    }

    
     static getDerivedStateFromProps(props, state) {

          const { languagelisting } = props;
        
           if(props.updatedisplaystatus.message)  
            return  {isLoading: false};

         if (props.user_details.hasOwnProperty('id') && props.companylisting.length && !state.user_details_loaded && props.match.params.id == props.user_details.id) {
             props.initialize(props.user_details);
             
            var select_cmpany = [
                {'label': 'Select Company','value': ''}
            ];
            
            props.companylisting.forEach((company, index) => {
                select_cmpany.push({
                        'label' : company.CompanyName.trim(),
                        'value' : company.id,
                });
            });

            var select_language = [
                {'label': 'Select Language','value': ''}
            ];

          try{
                if(typeof languagelisting !== 'string' && languagelisting.length > 0 && languagelisting.length != undefined && 
                    languagelisting != [] && 
                    languagelisting != "" ){
                        
                    console.log("props.languagelisting",props);

                    languagelisting.forEach((language, index) => {
                        select_language.push({
                                'label' : language.LanguageName.trim(),
                                'value' : language.LanguageCode.trim(),
                        });

                    });

                }

          }
          catch(e){
              console.log("edit lang list error", e);
          }
           
       
             return {
                 select_company : select_cmpany,
                 select_language:select_language,
                 user_details_loaded: true,
                 isLoading: false,
                 user_type_selected: props.user_details.user_type.trim()
             }
         } else {
             return true;
         }
     }
     togglePassword(){
        this.setState({ showResults: true });
     }

    manageUser(field_values) {

        this.setState({isLoading: true});

        let form = document.querySelector('#edit-user');
        let values = serialize(form, { hash: true });
        let userid = this.props.match.params.id;
       // values.user_type = this.props.user_type;
        values.user_image = '';

        //console.log("field_values", field_values);

        if(this.state.files.base64){
            values.user_image = this.state.files.base64
        }

        if(!values.user_type && this.props.user_type == 1){
            values.user_type = 5;
        }
        if(!values.user_type && this.props.user_type == 2){
            values.user_type = 6;
        }

        if(!values.user_type){
            values.user_type = this.props.user_type;
        }
        values.created_role = this.props.user_type;
        values.created_by = this.props.id;
    
        console.log("update values", values, this.props);
        this.props.UpdateUser(values);
    }

    handleUserCanEditField(e){
        e.preventDefault();
        this.setState(previousState => {
            return{
                userCanEditField : !previousState.userCanEditField
            }
        });
    }

    render() {
        if (this.props.updatecode === 1 && this.state.editUserCode) {
            //alert('User Updated Successfully');
            return <Redirect to={Config.userPath[this.props.user_type] + 'usermanagement'} />
        }
      

        const { handleSubmit } = this.props;

        return (
            <fieldset disabled={this.props.user_auth.is_user_modify != 1}>
            <div>
                  { 
                         this.props.updatedisplaystatus.message ? 
                            <div className="alert alert-danger" role="alert">
                              Something went wrong. Please try again
                            </div>:""
                    }
            
              { 
               console.log("main props", this.props) }

                <Loader showloader={this.state.isLoading}/>

                {/* New Tag  */}
                {/* <div className='user-profile-edit'>
                    <div class="card" >
                        <div className='card-head'>
                            <div className='row'>
                                <div className='col-lg-6'>
                                    user name
                                </div>
                                <div className='col-lg-6'>
                                    <label className='text-danger'>DELETE USER</label>
                                    <button className="btn btn-primary" onClick={this.handleUserCanEditField.bind(this)}>Edit User</button>  
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-title">
                                Account info
                            </div>
                            <hr/>
                        </div>
                    </div>
                </div> */}

                {/* <section className="content-header">
                    <h1>
                        User Profile
                    </h1>
                </section> */}

                <section className="content user_tabs">
                <div className="row">
                    <div className="col-md-12 editcompanyform">
                  {/* <div className="col-md-3">
                    <div className="box box-primary">
                        <div className="box-body box-profile">
                          <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                          <img src={(this.props.user_details.user_image) ? Config.user_img_path + this.props.user_details.user_image : Config.assetspath + 'default.png'} className="profile-user-img img-fluid img-circle" alt="" width="128" />
                          <h3 className="profile-username text-center">{this.props.user_details.first_name} {this.props.user_details.last_name}</h3>
                          <p className="text-muted text-center">{this.props.user_details.user_type}</p> 
                        </div>
                    </div>
                  </div> */}
                <form onSubmit={handleSubmit(this.manageUser.bind(this))} id="edit-user">
                    <div className="col-md-3">
                    <div className="box box-primary">
                        <div className="box-body box-profile">
                           <div className="img_wrapper"> 
                                <img src={(this.props.user_details.user_image) ? Config.user_img_path + this.props.user_details.user_image : Config.companylogopath + 'default.png'} alt="" width="200" className="profile-user-img img-responsive img-circle" id="profileImg" />

                                <div className="file-field big">
                                        <a className="btn-floating btn-lg pink lighten-1 mt-0 float-left">
                                        <i className="fa fa-fw fa-cloud-upload" aria-hidden="true"></i>
                                        <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                        </a>                                    
                                </div>
                            </div>

                            <h3 className="profile-username text-center">{this.props.user_details.first_name}</h3>

                            <p className="text-muted text-center">{this.props.user_details.email}</p>
                            <Button type="submit" id="cu_status_save_option" className="btn btn-primary btn-block" >Save</Button>
                        </div>
                    </div>               
                </div>

                    <div className="col-md-9">

                    

                    <Tabs defaultActiveKey="user_details" id="uncontrolled-tab-example">
                        <Tab eventKey="user_details" title="Details">
                            <div className="form-group">
                                <label>First Name</label>
                                <Field name="first_name" component={Common.renderInput} type="text" id="first_name" value={this.props.user_details.first_name} className="form-control hsmall" />
                            </div>                                           
                            <div className="form-group">
                                <label>Last Name</label>                                
                                <Field  name="last_name" component={Common.renderInput} type="text" id="last_name" value={this.props.user_details.last_name} className="form-control hsmall" />                               
                            </div> 
                            <div className="form-group" >
                                <label>Email</label>                                
                                <Field readOnly name="email" component={Common.renderInput} id="email" value={()=> this.props.user_details.email } className="form-control hsmall"/>                                
                            </div>                              
                            <div className="form-group hide">
                                <label>User Type</label> 
                                <Field selected_value={this.state.user_type_selected} options={this.state.select_options}  className="form-control hsmall arrow" label="User Type" name="user_type" id="user_type" component={Common.renderSelect} disabled={true}></Field>
                            </div>

                            <div className="form-group hide">
                            <div className="col-sm-10">
                                <Field name="id" component={Common.renderInput} type="text" id="id" className="form-control hsmall" value={this.props.user_details.id}/>
                            </div>
                            </div> 
                            <div className="form-group">
                                <label>Telephone</label>
                                <Field name="user_telephone" component={Common.renderInput} type="text" id="user_telephone" className="form-control hsmall"
                                normalize={ normalizeNumberAndSetLimit(30)  } 
                                />
                            </div>                                       
                            <div className="form-group">
                                <label>User Name</label>
                                <Field name="user_name" component={Common.renderInput} type="text" id="user_name" className="form-control hsmall"  value={this.props.user_details.user_name}/>
                            </div>
                            <div className="form-group">
                                <a className="forget-password" href="javascript:void(0);" onClick={this.togglePassword.bind(this)}>Forget Password</a>
                            </div>
                            { this.state.showResults ?   
                            <div className="form-group">
                                <label>New Password</label>
                                    <Field name="user_password" component={Common.renderInput} type="password" id="password" className="form-control hsmall"/>
                                
                            </div>: null 
                            }                                        
                            {this.props.user_type == 4 ? 
                            <fieldset disabled={this.props.user_details.user_type == 1 && this.props.user_details.user_company != '' || this.props.user_details.user_type == 2 && this.props.user_details.user_company != '' }>
                                <div className="form-group">
                                    <label>User Company</label>             
                                        <RenderSelect 
                                            options={this.state.select_company}    
                                            className="form-control hsmall arrow" 
                                            name="user_company" 
                                            id="user_company" 
                                        />  
                                </div>
                                </fieldset>  : null 
                            } 
                            <div className="form-group">
                                <label>Language</label>
                                <RenderSelect 
                                    options={this.state.select_language}  
                                    className="form-control hsmall arrow" 
                                    name="userLanguage"
                                    id="userLanguage" 
                                />
                            </div> 
                            {/* <div className="form-group">
                                <label>User Image</label>
                                    <FileBase64 multiple={ false } onDone={ this.getFiles.bind(this) } />
                                   
                            </div>  */}
                        </Tab>
                        <Tab eventKey="user_permission" title="Access">
                            {/* <fieldset disabled={this.props.user_details.user_type == 2 || this.props.user_details.user_type == 6}> */}
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Permission</th>
                                        <th>Access Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Company Management: View</td>
                                        <td><Field name="IsView" id="IsView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4}/></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management: Modify</td>
                                        <td><Field name="IsModify" id="IsModify" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management - User: View</td>
                                        <td><Field name="IsUserView" id="IsUserView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>
                                    <tr>
                                        <td>Company Management - User: Modify</td>
                                        <td><Field name="IsUserModify" id="IsUserModify" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>
                                    <tr>
                                        <td>Product Data & Tools: Product: View</td>
                                        <td><Field name="IsProductView" id="IsProductView" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>
                                    <tr>
                                        <td>Product Data & Tools: Product: Modify</td>
                                        <td><Field name="IsProductEdit" id="IsProductEdit" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>
                                    <tr>
                                        <td>Product Data & Tools: Product: Uploads</td>
                                        <td><Field name="IsProductUpload" id="IsProductUpload" component="input" type="checkbox" value="1" disabled={this.props.user_details.user_type == 4} /></td>
                                    </tr>                                                      
                                </tbody>
                            </table> 
                            {/* </fieldset>                            */}
                        </Tab>
                    </Tabs>
                  </div>
                </form> 
                </div>
                </div>
             </section>
                </div>
                </fieldset>
        );
    }
}



// EditUser.propTypes ={
//     languagelisting: PropTypes.object.isRequired
// }




export default reduxForm({
    form: 'EditUserForm',
    validate: Validation.ValidatEditUserForm
})(EditUser);




