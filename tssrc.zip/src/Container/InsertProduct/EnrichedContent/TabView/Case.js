import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Button } from 'react-bootstrap';
let PREFIX ='case_';
const lang = ['NL','XU'];

export default class Case extends Component {


constructor(props){
    super(props);

    this.state={
        addLang_product_description: false,
        addLang_tradeItem_Features: false,
        addLang_safety_warnings: false,
        addLang_consumer_usage: false,
        addLang_consumer_storage: false
    }
}

    render() {

        const {  userSelectedLanguage } = this.props;

        

        return (
            <div className="row">
                <div className="col-xs-12 col-md-3">
                    <div className="preview_div">
                        <div className="pdform_column last_coumn">
                            <div className="preview_title">
                                <p>Preview</p>
                            </div>
                            <div className="preview_img">
                                <img src="assets/images/default.png " alt="" />
                            </div>
                        </div>
                    </div>
                    <div className="selected_list_prew">
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Brand:</p>
                                    <p className="det preview_brand">{this.props.case_details['case_languageSpecificBrandName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Sub Brand</p>
                                    <p className="det preview_sub_brand">{this.props.case_details['case_Subbrand_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Functional Name:</p>
                                    <p className="det preview_functional">{this.props.case_details['case_FunctionalName_en']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Variant:</p>
                                    <p className="det preview_variant">{this.props.case_details['case_Varient_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                        <div className="col-xs-12">
                                <div className="prwrow">
                                    <p className="title">Product Name:</p>
                                    <p className="det preview_product_name">{this.props.case_details['case_gtinName_en']}</p>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">GTIN:</p>
                                    <p className="det preview_gtin">{this.props.case_details['case_GTIN']}</p>
                                </div>
                            </div>
                            <div className="col-xs-6">
                                <div className="prwrow">
                                    <p className="title">Size:</p>
                                    <p className="det preview_net">{this.props.case_details['case_NetContent']}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-4">
                    <div className="enrcih_des_fea lightgray">
                        <h4 className="ftitle">Long Product Description</h4>
                        <div className="form-group">
                            <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                             
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    name={PREFIX+"longProductDescription["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_long_description"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Insert description here("+lang.LanguageCode.trim()+")"}
                                    component="textarea"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }

                             

                            </div>
                        </div>
                      


                        <div className="title-button">
                            <h4 className="ftitle">Features & Benefits</h4>
                            
                        </div>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                { this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit1["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features1"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 1 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }

                         
                            </div>

                        </div>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit2["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features2"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 2 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }


                             
                            </div>
                        </div>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>

                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit3["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features3"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 3 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }


                            </div>
                        </div>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit4["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features4"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 4 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }

                            
                            </div>
                        </div>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit5["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features5"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 5 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }

                             
                            </div>
                        </div>
                        <div className="form-group features_6">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {this.props.languagelist != undefined && this.props.languagelist.length > 0 && this.props.languagelist !=[] ?    
                            this.props.languagelist.map( (lang, index)=>{
                               return ( 
                                  <Field 
                                    key={index} 
                                    type="text" 
                                    name={PREFIX+"tradeItemFeatureBenefit6["+lang.LanguageCode.toLowerCase().trim()+"]"}
                                    className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }
                                    id={"case_features6"+lang.LanguageCode.toLowerCase().trim() } 
                                    placeholder={"Features 6 "+lang.LanguageCode.trim() }
                                    component="input"
                                    onBlur={this.props.handleChange.bind(this,'case')}
                                    />
                                ) 
                            }
                            ) : ''
                         }

                            </div>
                        </div>

                  

                        <h4 className="ftitle">Safety Warnings</h4>
                        <div className="form-group">
      
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                    this.props.languagelist.map( (lang, index)=>{
                                    return ( 
                                        <textarea 
                                        key={index} 
                                        name={PREFIX+"safetyWarnings["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                        id={"case_safety_warnings"+lang.LanguageCode.toLowerCase().trim() }  
                                        placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                        component="textarea" 
                                       
                                    />
                                     ) 
                                        }
                                        ) : ''
                                }

                         
                              </div>
                        </div>

            
                    </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-4">
                    <div className="enrcih_des_fea lightgray">
                        <h4 className="ftitle">Goes well with</h4>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith1"} className="form-control segwllw" id="case_goes_well_with1" placeholder="Product 1" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith2"} className="form-control segwllw" id="case_goes_well_with2" placeholder="Product 2" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith3"} className="form-control segwllw" id="case_goes_well_with3" placeholder="Product 3" component="input" type="text" />
                        </div>
                        <div className="form-group">
                            <Field name={PREFIX+"goesWellWith4"} className="form-control segwllw" id="case_goes_well_with4" placeholder="Product 4" component="input" type="text" />
                        </div>
                        <h4 className="ftitle">Search Terms</h4><p>Separate by comma</p>
                        <div className="form-group">
                            <Field name={PREFIX+"search_terms"} className="form-control" id="case_search_terms" placeholder="Keywords (Seperated by Commas)" component="input" type="text" />
                        </div>
                        <h4 className="ftitle">Consumer User Instructions</h4>


                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                    this.props.languagelist.map( (lang, index)=>{
                                    return ( 
                                        <textarea 
                                        key={index} 
                                        name={PREFIX+"ConsumerUsageInstructions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                        id={"case_consumer_user_instructions"+lang.LanguageCode.toLowerCase().trim() }  
                                        placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                        component="textarea" 
                                       
                                    />
                                     ) 
                                        }
                                        ) : ''
                                }
                          
                             </div>
                        </div>

                    
                        <h4 className="ftitle">Consumer Storage Instructions</h4>
                        <div className="form-group">
                        <div className="input-group lang_div">
                                <span class="input-group-addon">{userSelectedLanguage}</span>
                                {
                                    this.props.languagelist != undefined && this.props.languagelist.length > 0 &&this.props.languagelist !=[] ?    
                                    this.props.languagelist.map( (lang, index)=>{
                                    return ( 
                                        <textarea 
                                        key={index} 
                                        name={PREFIX+"StorageUsageInstructions["+lang.LanguageCode.toLowerCase().trim()+"]"} 
                                        className={lang.LanguageCode.trim() != userSelectedLanguage.trim() ? 'form-control hsmall hide': "form-control hsmall" }  
                                        id={"case_consumer_storage_instructions"+lang.LanguageCode.toLowerCase().trim() }  
                                        placeholder={"Insert description here ("+lang.LanguageCode.trim()+")..." }
                                        component="textarea" 
                                       
                                    />
                                     ) 
                                        }
                                        ) : ''
                                }

                               
                             </div>
                        </div>

                        

    

                    </div>
                </div>
                <div className="col-xs-12 col-md-1">
                    <div className="adv_column"   id="adv_column" style={{height: '900px'}}>
                        <div className="adv_section">
                            <img src="assets/images/google_adwrd.jpg" alt="" />
                        </div>
                        <div className="saveform">
                            <div className="profile_cmpletd">
                                <img src="assets/images/percentage_img2.png" alt="" />
                            </div>
                            <div className="save_btn">
                                <Button type="submit" className="btn-save" value="Save">Save</Button>
                            </div>
                            <div className="next_btn">
                                <Button type="button" onClick={this.props.nextTab} className="btn-next"><img src="assets/images/nxt_btn.png" alt="Next tab" /> Next Tab</Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
} 