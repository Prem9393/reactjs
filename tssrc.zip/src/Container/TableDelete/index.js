import React, { Component } from 'react';
import {Button, Row, Col } from 'react-bootstrap'; 
import Config from '../../Config';
import { Provider, connect } from 'react-redux';
import {Field, reduxForm} from 'redux-form';
import Common from '../../Common'
import Validation from '../../Validations'
import AlertDismisable from '../../Components/AlertDismissable'





class TableDelete extends Component {

    constructor(props){ 
        super(props);
        this.state = {
            message: '',
            companyname:[],
            selectedcompnay:'',
            files:'',
      };
    }
    TableDelete(vlaues){
        vlaues.remember_token=this.props.match.params.id;
        this.props.TableDelete(vlaues);
        
    }

    
    render(){
       
        const { handleSubmit } = this.props
        return   <div>
        <form>
            <div className="form-group">
                <label>Brand Name</label>
                <input name="" type="checkbox" id="" className="form-control hsmall" />
            </div>
            <div className="form-group">
                <label>Brand Name</label>
                <input name="" type="checkbox" id="" className="form-control hsmall" />
            </div>
            <div className="form-group">
                <label>Brand Name</label>
                <input name="" type="checkbox" id="" className="form-control hsmall" />
            </div>
            <div className="form-group">
                <label>Brand Name</label>
                <input name="" type="checkbox" id="" className="form-control hsmall" />
            </div>
            <div className="form-group">
                <input name="" type="submit" id="" value='submit' className="form-control hsmall" />
            </div>
         </form>
         </div>;
    }
}


export default TableDelete;


