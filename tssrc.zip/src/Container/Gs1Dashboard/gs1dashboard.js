import React,{Component} from 'react';
import { Col,Row  } from 'react-bootstrap';
import Piechart from '../../Components/Charts/Piechart'
import ImageChart from '../../Components/ImageChart';
import InfoBox from '../../Components/InfoBox'
import Config from '../../Config';
import Loader from '../../Components/Loader';

const option1 =  {
	cutoutPercentage: 80,
	legend: {
		display: false
	},
	layout:{
		padding:40
	}, 
	elements: {
		arc: {
			roundedCornersFor: 0
		},
		center: {
			text: '67%',
		}
	}
};


const GetImageChart = (props) =>{
    let leftdetails='';
    let bgName ='';
    let iconName ='';
    if(props.details){
        if(props.details.length){
            leftdetails = props.details.map((list, key)=>{
             
                if(key ==1){
                    bgName = 'small-box bg-green';
                    iconName = 'ion ion-clock';
                }else if(key ==2){
                    bgName = 'small-box bg-aqua-active';
                    iconName = 'ion ion-checkmark-circled';
                } else if(key ==3){
                    bgName = 'small-box bg-red';
                    iconName = 'ion ion-edit';
                }else {
                    bgName = 'small-box bg-lime';
                    iconName = 'ion ion-alert-circled';
                }

            return (<InfoBox 
                key={key} 
                link={Config.userPath[props.user_type]+'productbrowser/'+list.status_name}
                bgName= {bgName } 
                imagename={iconName} 
                count={list.count} 
                text={list.status_name}/>)
            })
        }
    }
    return leftdetails;
 }
 


export default class SupplierDashbaord extends Component{

    constructor(props){
        super(props);
        this.state ={
            rightpannel:[],
            products:0,
            leftpannel:[],
            colorcode:[],
            colorcount:[],
            isLoading: true
        }
    }

    static getDerivedStateFromProps(props,state){
        if(props.dashboard.hasOwnProperty('active_count')){
            return {
				leftpannel : props.dashboard.left_panel,				
				entirepannel : props.dashboard.entire_panel,
                products : props.dashboard.active_count,
                rightpannel : props.dashboard.right_panel,
                colorcode : props.dashboard.pie_chart.color_code,
                colorcount : props.dashboard.pie_chart.color_count,
                isLoading: false
            }
        }
        return null
       
    }

    componentDidMount(){
        document.title = Config.name+' Dashboard ';
        var token_value={
            token:this.props.token
        }
        this.props.DashbaordListing(token_value);
        this.props.ResetStateMessage('login');
        this.props.ResetStateMessage('register');
		this.props.ResetStateMessage('reset');
		this.props.ResetStateMessage('forget');
    }


  render() {
    const chart4 = {
        labels: {display:false},
        datasets: [{
            data: this.state.colorcount,
            borderWidth:0,
            backgroundColor: this.state.colorcode,
        }],
        text: '23%'
    };
    return (
      <div className="dashboard_chart gs1_dashboard">
        <Loader showloader={this.state.isLoading} />
    <Row>
				<Col xs={12} md={12}>
						<div className="row">
                            <GetImageChart details = {this.state.entirepannel} user_type={this.props.user_type}/>
						</div>
				</Col>
				{/* <Col xs={12} md={6}>
							<div className="no_files" >
									<div id="pieChart">
										<Piechart width={200} height={200}  data={chart4} option={option1} text={'8 Active'}/>
                                        <div className="chartCount">
                                            {this.state.products} <br/> Active
                                        </div>
									</div>
							</div>
				</Col>
				<Col xs={12} md={3}>
						<div className="right_side">
                        <GetImageChart details = {this.state.rightpannel} user_type={this.props.user_type}/>
						</div>
				</Col> */}
                </Row>

                <Row>
							
		

		<div class="col-md-7">
		  
		  
		  <div class="box box-warning">
		    <div class="box-header" style={{backgroundColor: '#888'}}>
		      <h3 class="box-title">Pending Approval</h3>
		    </div>
		  
		    <div class="box-body">
		      <table id="example2" class="table table-bordered table-striped">
		        <thead>
		        <tr>
		          <th>Sector</th>
		          <th></th>
		          <th>Information Provider</th>
		          <th></th>
		          <th>Description</th>
		          <th>GTIN</th>
				  <th></th>
				  <th>Pass/Fail</th>
		        </tr>
		        </thead>
		        <tbody>
					<tr>
					  <td>CPG</td>
					  <td></td>
					  <td>Mondelez</td>
					  <td><i class="fa fa-pencil"></i></td>
					  <td>Cadbury Lunch Bar Treat Size 144g</td>
					  <td>6001065033990</td>
					  <td><i class="fa fa-eye"></i></td>
					  <td>
					  	<div class="form-group">
					  			<div class="radio">
					  				<i class="fa fa-check-circle"></i>
					  			</div>
					  			<div class="radio">
					  				<i class="fa fa-times-circle"></i>
					  			</div>
					  	</div>
					  </td>
					</tr>
					<tr>
					  <td>CPG</td>
					  <td><i class="fa fa-check-square"></i></td>
					  <td>Unilever SA</td>
					  <td><i class="fa fa-star"></i></td>
					  <td><strong>Skip Perfect Whites Auto Washing Liquid 1.5l</strong></td>
					  <td>6001087375719</td>
					  <td><i class="fa fa-eye"></i></td>
					  <td>
					  	<div class="form-group">
					  			<div class="radio">
					  				<i class="fa fa-check-circle"></i>
					  			</div>
					  			<div class="radio">
					  				<i class="fa fa-times-circle"></i>
					  			</div>
					  	</div>
					  </td>
					</tr>			
					
					<tr>
					  <td>GenMerch</td>
					  <td></td>
					  <td>Creative Housewares</td>
					  <td><i class="fa fa-star"></i></td>
					  <td><strong>Mellerware 1.7L Glass Kettle</strong></td>
					  <td>6002674006009</td>
					  <td><i class="fa fa-eye"></i></td>
					  <td>
					  	<div class="form-group">
					  			<div class="radio">
					  				<i class="fa fa-check-circle"></i>
					  			</div>
					  			<div class="radio">
					  				<i class="fa fa-times-circle"></i>
					  			</div>
					  	</div>
					  </td>
					</tr>
					<tr>
					  <td>GenMerch</td>
					  <td></td>
					  <td>Addis Housewares</td>
					  <td><i class="fa fa-star"></i></td>
					  <td><strong>Addis Slotted Laundry Basket</strong></td>
					  <td>6001246391468</td>
					  <td><i class="fa fa-eye"></i></td>
					  <td>
					  	<div class="form-group">
					  			<div class="radio">
					  				<i class="fa fa-check-circle"></i>
					  			</div>
					  			<div class="radio">
					  				<i class="fa fa-times-circle"></i>
					  			</div>
					  	</div>
					  </td>
					</tr>

					<tr>
					  <td>GenMerch</td>
					  <td></td>
					  <td>Addis Housewares</td>
					  <td><i class="fa fa-star"></i></td>
					  <td><strong>Addis Slotted Laundry Basket</strong></td>
					  <td>6001246391468</td>
					  <td><i class="fa fa-eye"></i></td>
					  <td>
					  	<div class="form-group">
					  			<div class="radio">
					  				<i class="fa fa-check-circle"></i>
					  			</div>
					  			<div class="radio">
					  				<i class="fa fa-times-circle"></i>
					  			</div>
					  	</div>
					  </td>
					</tr>
					
		        </tbody>
		      </table>
		    </div>
		  
		  </div>
		 
		  
		</div>
		
		 <div class="col-md-5">
			<div class="row">
				<div class="col-md-12">
				  
				  <div class="box">
		            <div class="box-header">
		              <h3 class="box-title">Recent Notifications</h3>
		
		              
		            </div>
		           
		            <div class="table-responsive mailbox-messages">
		              <table class="table table-hover table-striped">
		                <tbody>
		                <tr>
		                  
		            		<td><i class="fa fa-flag text-red text-red"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Sifiso Buthelezi</a></td>
		                  <td class="mailbox-subject"><b>TrustedSource</b> - If you having trouble logging in...
		                  </td>
		                  <td class="mailbox-attachment"></td>
		                  <td class="mailbox-date">5 mins ago</td>
		                </tr>
		                <tr>
		                  
		            		<td><i class="fa fa-bell text-yellow"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o  text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Dimakatso Mnisi</a></td>
		                  <td class="mailbox-subject"><b>Check Data</b> - Trying to find a solution to this problem...
		                  </td>
		                  <td class="mailbox-attachment"><i class="fa fa-paperclip"></i></td>
		                  <td class="mailbox-date">28 mins ago</td>
		                </tr>
		                <tr>
		                  
		            		<td><i class="fa fa-envelope text-green"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o  text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Esther Young</a></td>
		                  <td class="mailbox-subject"><b>Check Product</b> - Please confirm the details are correct...
		                  </td>
		                  <td class="mailbox-attachment"><i class="fa fa-paperclip"></i></td>
		                  <td class="mailbox-date">11 hours ago</td>
		                </tr>
		                <tr>
		                  
		            		<td><i class="fa fa-bell text-yellow"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Thembi Xaba</a></td>
		                  <td class="mailbox-subject"><b>Check Data</b> - Trying to find a solution to this problem...
		                  </td>
		                  <td class="mailbox-attachment"></td>
		                  <td class="mailbox-date">15 hours ago</td>
		                </tr>
		                
		               
		                <tr>
		                  
		            		<td><i class="fa fa-envelope text-green"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Yusuf Theron</a></td>
		                  <td class="mailbox-subject"><b>Check Product</b> - Please confirm the details are correct...
		                  </td>
		                  <td class="mailbox-attachment"></td>
		                  <td class="mailbox-date">5 days ago</td>
		                </tr>
		                <tr>
		                  
		            		<td><i class="fa fa-flag text-red"></i></td>
		                  <td class="mailbox-star"><a href="#"><i class="fa fa-star-o  text-yellow"></i></a></td>
		                  <td class="mailbox-name"><a href="gs1_email_read.html">Thandi Xhoswa</a></td>
		                  <td class="mailbox-subject"><b>TrustedSource</b> - System down for maintenance...
		                  </td>
		                  <td class="mailbox-attachment"></td>
		                  <td class="mailbox-date">6 days ago</td>
		                </tr>
		                </tbody>
		              </table>
		           
		            </div>
		            
		          </div>
				</div>
			</div>
		
		 </div>
		 
			
              
				<div class="col-md-7">
				<div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
						<li class="active"><a href="#tab_1" data-toggle="tab">Admin Lookup</a></li>
						<li><a href="#tab_2" data-toggle="tab">Product Search</a></li>
						<li><a href="#tab_3" data-toggle="tab">Import Data</a></li>
						<li><a href="#tab_3" data-toggle="tab">Upload Image</a></li>
				</ul>
				<div class="tab-content">
						<div class="tab-pane active" id="tab_1">
							<form role="form">
									<div class="box-body">
										<div class="form-group">
												<label for="exampleInputEmail1">Search Items</label>
												<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter search term" />
										</div>
									</div>
									<div class="box-footer">
										<button type="submit" class="btn btn-primary">Submit</button>
									</div>
							</form>
						</div>
						<div class="tab-pane" id="tab_2">
							<form role="form">
									<div class="box-body">
										<div class="form-group">
												<label for="exampleInputFile">File input</label>
												<input type="file" id="exampleInputFile" />
										</div>
									</div>
									<div class="box-footer">
										<button type="submit" class="btn btn-primary">Submit</button>
									</div>
							</form>
						</div>
						<div class="tab-pane" id="tab_3">
							<form role="form">
									<div class="box-body">
										<div class="form-group">
												<label for="exampleInputFile">File input</label>
												<input type="file" id="exampleInputFile" />
										</div>
									</div>
									<div class="box-footer">
										<button type="submit" class="btn btn-primary">Submit</button>
									</div>
							</form>
						</div>
				</div>
				</div>
				</div>			
				
		 
		

     

      </Row>



      </div>
    );
  }
}
