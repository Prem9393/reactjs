import React, { Component } from 'react';
import Config from '../../Config';
import { Provider, connect } from 'react-redux';
import { reduxForm } from 'redux-form';

import ListingMain from './list';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators'

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
})


const mapDispatchToProps = (dispatch) => ({

})

const PrefixListComponent = connect(mapStateToProps, mapDispatchToProps)(ListingMain);

class PrefixManagement extends Component {

    componentDidMount() {
        document.title = Config.name + ' Prefix Management ';
    }
    render() {
        return <Provider store={AppStore}><PrefixListComponent {...this.props} /></Provider>
    }
}


export default reduxForm({
    form: 'PrefixFilters',
})(PrefixManagement);


