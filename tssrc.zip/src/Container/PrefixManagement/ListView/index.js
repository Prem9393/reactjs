import React, { Component } from 'react';
// import Table from '../../../Components/Table';
import Table from '../../../Components/Table/table';
import Config from '../../../Config';
    

    const tableColumn = [       
        {key: 'Name', label: 'Assignment Brand Owner', isSort: true},
        {key: 'PrefixStart', label: 'Prefix Start', isSort: true},
        {key: 'PrefixStop', label: 'Prefix Stop', isSort: true},
        {key: 'PrefixQty', label: 'Prefix Qty', isSort: true},
        {key: 'PrefixValidityStartDate', label: 'Validity Start Date', isSort: true},
        {key: 'PrefixValidityEndDate', label: 'Validity End Date', isSort: true},
        {key: 'StatusNum', label: 'Status', isSort: true},
        {key: 'PrefixQty', label: 'Reason', isSort: true},
        {key: 'DateCreated', label: 'Date Created', isSort: true},
        {key: 'CreatedByUserID', label: 'Created By', isSort: true},
        {key: 'DateStatusChanged', label: 'Date Changed', isSort: true},
        {key: 'StatusChangedByUserID', label: 'Changed by', isSort: true},
    ];
    
class ListView extends Component {
    
    render() {
        return(
            <Table user_type={this.props.user_type} column={tableColumn} name="prefix_management" classname="table table-bordered table-striped table-hover"/>
        )
    }
}

export default ListView;
