import React, { Component } from 'react';
import { Field } from 'redux-form';
import ListView from './ListView';

class PrefixList extends Component {
    constructor(props) {
        super(props)
    }
  
    render(){
        return (
            <div className="container">
                <div className="row no-gutter">
                    <div className="col-sm-12 col-xs-12">
                        <div className="setp_2maintable"> 
                            <div className="table-responsive prefix_listing custom_table">
                            
                                <div className="button-group">
                                    <a className="btn btn-primary btn-flat" href='#/gs1/insertprefix'>Add New</a>
                                </div>
                                <ListView  {...this.props} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default PrefixList;