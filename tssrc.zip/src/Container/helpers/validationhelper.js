
 export const companyDetailValidation =(values)=> {

	console.log("helloq", values)
	
	// console.log(
	// 	values.CompanyGLN, values.CompanyName ,
	// 	values.CompanyType ,values.ContactEmail, values.ContactFax,
	// 	values.ContactName, values.ContactTel, values.WebServiceGLN, 
	// 	values.WebServiceKey)

	// if( values.CompanyGLN.length>0 && values.CompanyName.length>0 && 
	// 	values.CompanyType.length>0 && values.ContactEmail.length>0 && values.ContactFax.length>0 &&
	// 	values.ContactName.length>0 && values.ContactTel.length>0 && values.WebServiceGLN.length>0 && 
	// 	values.WebServiceKey.length>0
	// 	){	 
	// 		return true;
	//   }
    return false;
 }


//  ContactName:"",
//  CompanyGLN:"",
//  ContactEmail:"",
//  BatchUserId:"",
//  ContactTel:"",
//  ContactFax:"",
//  WebServiceGLN:"",
//  WebServiceKey:""   

