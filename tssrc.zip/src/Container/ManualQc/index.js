import React, { Component } from 'react';
import Table from '../../Components/Table/table';
//import '../custom/css/adminlte.css';
import Common from '../../Common';
import Config from '../../Config';
import { Col, Row } from 'react-bootstrap';
import {reset} from 'redux-form';
import { reduxForm, Field, change } from 'redux-form';
import { connect } from 'react-redux';
import AppStore from '../../Store/AppStore';
import ActionCreators from '../../Actions/ActionCreators';
import Pagination from '../../Components/QcPagination';
import serialize from 'form-serialize';
import Loader from '../../Components/Loader';
import {PanelGroup, Panel } from 'react-bootstrap';
import Modal from 'react-modal';
import SlidingPane from 'react-sliding-pane';
import 'react-sliding-pane/dist/react-sliding-pane.css';
import {Link} from 'react-router-dom';
import ManualQcDetail from '../../Components/ManualQcDetail';
import FilterSupplierList from '../../Components/ManualQcDetail/FilterSupplierList';
import SlidingPanelTitleMQC from '../../Components/SlidingPanelTitleMQC';

const tableColumn = [       
    {key: 'id', label: 'ID', isSort : true,type: 'checkbox' },
    {key: 'GTIN', label: 'GTIN', isSort: true, type: 'callback', callback_function: 'ManualQcProductEditLink'},
    {key: 'gtinName', label: 'Description', isSort: true},
    {key: 'InformationProviderGLN', label: 'Supplier', isSort: true},
    {key: 'time', label: 'Date', isSort: true},
    {key: 'Action', label: 'Accept', isSort: true, type:"AcceptBtn",  callback_function: 'AcceptBtnBtnLink'}
];

class ManualQc extends Component {

    constructor(props, context) {
        super(props, context);

        this.state = {
            isLoading: true,
            isPaneOpen: false,
            isPaneOpenLeft: false,
            checked:false,
            GTIN : '',
        };

        
        this.ManualQcProductsPagination = this.ManualQcProductsPagination.bind(this);
        this.OpenPanel = this.OpenPanel.bind(this);
        this.getCheckboxCount = this.getCheckboxCount.bind(this);
    }

    getCheckboxCount(idx){
        const items = this.state.items.concat();
            items[idx].checked = !items[idx].checked;
            this.setState({items});     
    }

    onCheckChange(idx) {
        return () => {
            const items = this.state.items.concat();
           
            items[idx].checked = !items[idx].checked;
            if(this.state.items[idx].checked = "false"){
                items[idx].checked = "true";
            } else {
                items[idx].checked = "false";
            }
            this.setState({items});
            
        }
    }

    totalChecked() {
        if(this.state.items != undefined){
            return this.state.items.filter(props => props.checked).length;
        }
        
    }

    static getDerivedStateFromProps(props) {
        if  (props.manualqclisting != undefined && props.manualqclisting.length > 0) {
            return {
                isLoading: false,
                items: props.manualqclisting.concat(),
            }
        } else {
            return null;
        }
    }

    ManualQcProductsPagination(pagenumber) {
        if(!pagenumber){
            pagenumber = 1;
        }
        var form = document.querySelector('#ManualQc-frm');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = pagenumber;
        form_fields.record_limit = this.props.recordlimit;
        console.log("product pagination",form_fields);
        this.setState({ isLoading: true });
        this.props.ManualQcListing(form_fields);
    }

    clearItems(){
        this.props.dispatch(reset('ManualQcForm'));   
        this.props.ManualQcListing();
      }

    componentDidMount() {
        document.title = Config.name + ' Quality Control';
        var form = document.querySelector('#ManualQc-frm');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = this.props.pagenumber;
        form_fields.record_limit = this.props.recordlimit;
        this.props.ManualQcListing(form_fields);
        this.props.ManualQcFilterList();
        Modal.setAppElement(this.el);
    }

    OpenPanel(aID,GTIN,GUID){
        this.setState({ isPaneOpen: true, aID:aID, GTIN:GTIN, GUID:GUID});
    }

    render(){
        console.log("ManualQc",this.props);
        const {  handleSubmit } = this.props;
      
        return (
            <div className="step_3main bg-grey">
            <form id="ManualQc-frm" >
                <Loader showloader={this.state.isLoading} />
                <div className="quality_control-ManualQc manual-page">

                    <div class="row content-main-header">
						<div class="col-md-2 col-sm-6 col-xs-6">
							<div class="content-head-left-side">
								<div class="project-count-wrap">
									<p>Suppliers<span><strong>8</strong></span></p>
								</div>								
							</div>
						</div>
						<div class="col-md-10  col-sm-6 col-xs-6">
							<div class="right-bar">
								<div class="project-count-wrap">
									<p>ICU Medical Inc<span><strong>65</strong></span></p>
								</div>
							</div>
						</div>						
					</div>

                    {/* <section className="content-header">
                        <h5 style={{'fontWeight': 'bold'}}>
                            Manual QC - Work List (Rejected Products)
                        </h5>
                        <ol className="breadcrumb">
                            <li><a href=""><i className="fa fa-dashboard"></i> Home</a></li>
                            <li className="active">Quality Control</li>
                        </ol>
                    </section> */}
                    <section className="content">
                    <div className="row">
                       
                            {/* <PanelGroup accordion id="ct_accordion" defaultActiveKey="1">
                                <Panel eventKey="1">
                                    <Panel.Heading>
                                    <Panel.Title toggle>
                                        Suppliers
                                    </Panel.Title>
                                    </Panel.Heading>
                                    <Panel.Body collapsible>
                                        {                                            
                                           Object.values(this.props.manualqcfilterlist).length > 0 ? 
                                           Object.values(this.props.manualqcfilterlist).map((list,index) => (
                                                <div key={index} className="form-group">
                                                    <div className="inline-checkbox">
                                                        <input name="product_supplier[]" type="checkbox" onClick={this.ManualQcProductsPagination} value={list.InformationProviderGLN.trim()}/>
                                                        <label className="">{list.company_suppliers != null ? list.company_suppliers.CompanyName.trim() : ''}</label>
                                                    </div>
                                                </div>
                                            ))
                                            : 'No Filter(s) found'
                                        }
                                        
                                    </Panel.Body>
                                </Panel>                         
                            </PanelGroup> */}

                            <div class="manual-submenu">
                                <div class="manual-wrap">
                                    <FilterSupplierList {...this.props} ManualQcProductsPagination={this.ManualQcProductsPagination} />                                   
                                </div>
                            </div>

                        

                            <div class="main-table">
					            <div class="inner-main-padding">
                                    <div className="table-data-wrapper table-responsive">                                    
                                        <Table user_type={this.props.user_type}
                                    state={this.state}
                                    OpenPanel={this.OpenPanel}
                                    column={tableColumn}
                                    name="quality_control"
                                    classname="table table-hover"
                                    getCheckboxCount={this.getCheckboxCount}
                                    rows={this.props.manualqclisting }
                                    {...this.props} />  
                                    </div>                                  
                                </div>
                            </div>
                            
                            <div className="table-pagination">
                                <Pagination {...this.props} state={this.state} AutoQcProductsPagination={this.ManualQcProductsPagination} />    
                            </div>

                        <div ref={ref => this.el = ref}>
                            <SlidingPane
                                className='some-custom-class'
                                overlayClassName='some-custom-overlay-class'
                                isOpen={ this.state.isPaneOpen }
                                title={<SlidingPanelTitleMQC {...this.props} />}
                                subtitle=''                               
                                onRequestClose={ () => {
                                    // triggered on "<" on left top click or on outside click
                                    this.setState({ isPaneOpen: false });
                                } }>
                                <ManualQcDetail {...this.props} state = {this.state}/>
                            </SlidingPane>            
                        </div>

                    </div>
                </section>
                </div>
            </form>
            </div>
        )
    }
}

const Form = reduxForm({
    form: 'ManualQcForm',
})(ManualQc);

const mapStateToProps = (state) => ({
    auth: state.auth.auth,
    token: state.auth.token,
    user_type: state.auth.user_type,
    manualqclisting:state.manualqclist.manualqclisting,
    manualqcfilterlist:state.manualqcfilterlist.filterlist,
    totalproducts: state.manualqclist.totalqcproducts,
    pagenumber: state.manualqclist.pagenumber,
    recordlimit: state.manualqclist.recordlimit,
    manualqc_details:state.manualqcdata.manualqc_details,
    productrevisions:state.manualqcdata.productrevisions,
    manualqc_parent_details:state.manualqcdata.manualqc_parent_details,
    qcproducttime:state.manualqclist.qcproducttime,
    manualqcrevisiondata:state.manualqcrevisiondata.manualqc_revisiondetails,
})


const mapDispatchToProps = (dispatch) => ({
    ManualQcListing: (values) => dispatch(ActionCreators.ManualQcListing(values)),
    ManualQcFilterList: (values) => dispatch(ActionCreators.ManualQcFilterList(values)),
    GetManualQcDetails: (values) => dispatch(ActionCreators.GetManualQcDetails(values)),
    GetManualRevisionQcDetails: (values) => dispatch(ActionCreators.GetManualRevisionQcDetails(values)),
})

export default connect(mapStateToProps, mapDispatchToProps)(Form);