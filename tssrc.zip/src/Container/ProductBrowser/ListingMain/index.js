import React, { Component } from 'react';
import ProductsList from '../../ProductBrowser/list';
import { Col } from 'react-bootstrap';
import Filters from '../Filters';
import serialize from 'form-serialize';
import Pagination from '../../../Components/Pagination';
import Config from '../.././../Config';
import Basket from '../Basket';
import Loader from '../../../Components/Loader';

class ListingMain extends Component {
    constructor(props) {
        super(props);
        this.filterProducts = this.filterProducts.bind(this);
        this.filterProductsPagination = this.filterProductsPagination.bind(this);
        this.manageBasket = this.manageBasket.bind(this);
        this.exportExcel = this.exportExcel.bind(this);
        this.exportPDF = this.exportPDF.bind(this);
        this.state = {
            isLoading: true,
            reset_sub_category: 0
        };

    }

    static getDerivedStateFromProps(props, state) {
        if (props.productsmessage !== '' || props.excelexportmessage !== '' || props.pdfexportmessage !== '') {
            return {
                isLoading: false
            }
        } else {
            return null;
        }
    }

    componentDidMount() {
        this.props.ResetStateMessage('update_product');
        this.props.ResetStateMessage('edit_product');
        var token_value = {
            token: this.props.token
        }
        //this.props.ProductListing(token_value);
        // this.filterProducts();
        let product_status = (this.props.match.params.status) ? this.props.match.params.status : '';
        this.filterProducts('', product_status);
        this.props.FilterDataList(token_value);
        if (this.props.user_type === Config.userTypes.Retailer) {
            this.manageBasket();
        }
    }

    filterProducts(e, status = '') {
        var form = document.querySelector('#product-browser');
        var form_fields = serialize(form, { hash: true });
        var token_value= '';
        form_fields.token = this.props.token;
        form_fields.record_limit = this.props.recordlimit;
        if (status !== '' && status !== 'All Active' && status !== 'desc' && status !== 'asc') {
            form_fields.product_status = [status];
        }
        this.setState({ isLoading: true });
        this.props.ProductListing(form_fields);
        if (form_fields.product_category) {
            token_value = {
                token: this.props.token,
                category: form_fields.product_category,
                reset_sub_category : 1 
            }
            this.props.FilterDataList(token_value);
			// this.setState({ reset_sub_category: 1 });
            // this.state.reset_sub_category = 1;
        } else if(this.state.reset_sub_category === 1) {
            token_value = {
                token: this.props.token,
                reset_sub_category : 0,
            }
            this.props.FilterDataList(token_value);
			// this.setState({ reset_sub_category: 0 });
           // this.state.reset_sub_category = 0;
        }
    }

    filterProductsPagination(pagenumber) {
        var form = document.querySelector('#product-browser');
        var form_fields = serialize(form, { hash: true });
        form_fields.token = this.props.token;
        form_fields.page_number = pagenumber;
        form_fields.record_limit = this.props.recordlimit;
        this.setState({ isLoading: true });
        this.props.ProductListing(form_fields);
    }

    manageBasket(gtin = '', action = '') {
        if (action === '') {
            action = 'count';
        }
        var form_fields = {
            token: this.props.token,
            action: action,
            product_gtin: gtin
        }
        this.props.ManageBasket(form_fields);
    }

    exportExcel() {
        let values = {
            token: this.props.token
        }
        this.setState({isLoading: true});
        this.props.ExportExcel(values);
    }

    exportPDF() {
        let values = {
            token: this.props.token
        }
        this.setState({isLoading: true});
        this.props.ExportPDF(values);
    }

    render() {
        return <div>

            <div class="row content-main-header">
            <div class="col-md-12 col-sm-12 col-lg-8">
            <div class="content-head-left-side"><div class="project-count-wrap"><p>products<span><strong>4869</strong></span></p></div>
            <div class="product-top-filter-wrap">
            <div class="suppliers-dropdown">
            <select name="search_Supplier" class="form-control hsmall arrow" id="search_Supplier" data-tabbrand="">
            <option value="">All Categories</option>
            <option value="245">Unilever South Africa (Pty) Ltd</option>
            </select>
            <div class="text-danger"></div>
            </div>

            <div class="suppliers-dropdown">
            <select name="search_Supplier" class="form-control hsmall arrow" id="search_Supplier" data-tabbrand="">
            <option value="">All Sub Categories</option>
            <option value="245">Unilever South Africa (Pty) Ltd</option>
            </select>
            <div class="text-danger"></div>
            </div>
            <div class="suppliers-dropdown">
            <select name="search_Supplier" class="form-control hsmall arrow" id="search_Supplier" data-tabbrand="">
            <option value="">All Brands</option>
            <option value="245">Unilever South Africa (Pty) Ltd</option>
            </select>
            <div class="text-danger"></div>
            </div>
            </div>
            </div>
            </div>
            <div class="col-lg-4 col-md-12 col-sm-12">
            <div class="cont-head-right-side">
            <div class="col-md-6">
            <div class="suppliers-dropdown pull-right">
            <select name="search_Supplier" class="form-control hsmall arrow" id="search_Supplier" data-tabbrand="">
            <option value="">All Status</option>
            <option value="245">Unilever South Africa (Pty) Ltd</option>
            </select>
            <div class="text-danger"></div>
            </div>
            </div>
            <div class="col-md-6">
				<div className="table-list-switcher pull-right">
					<input id="pro-toggle-on" className="toggle toggle-left" name="toggle" value="false" type="radio" defaultChecked="checked" onChange={this.handleChange} />
					<label htmlFor="pro-toggle-on" className="btn">Table</label>
					<input id="pro-toggle-off" className="toggle toggle-right" name="toggle" value="true" type="radio" />
					<label htmlFor="pro-toggle-off" className="btn">List</label>
				</div>
            </div>
            </div>
            </div>
            </div>

            <form onSubmit={this.handleSubmit} id="product-browser">
                <Loader showloader={this.state.isLoading} />
                <div className="top_search">
                    <input onKeyUp={this.filterProducts} type="text" id="search_terms" className="form-control" name="search_terms" placeholder="Search Product / Brand / GTIN" />
                    <Basket usertype={this.props.user_type} basketcount={this.props.basketcount} filterProducts={this.filterProducts} export={this.exportExcel} exportPdf={this.exportPDF} />
                </div>
                <div className="step_2main">
                    <div className="container-fluid">
                        <div className="row no-gutter">
                            <Filters {...this.props} filterProducts={this.filterProducts} />
                            <Col xs={12} sm={12}>
                                <ProductsList {...this.props} manageBasket={this.manageBasket} />
                                <Pagination {...this.props} filterProductsPagination={this.filterProductsPagination} />
                            </Col>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    }
}

export default ListingMain;

