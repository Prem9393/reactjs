import 'whatwg-fetch'
import { post } from 'axios';

//  const site_name = 'http://202.129.196.139:5112/trustedsource/api/';
// const site_name = 'http://172.16.20.71/trustedsource/api/api/';
// const site_name = 'http://tsourceapi.azurewebsites.net/api/';
// const site_name = 'https://trustedsource.azurewebsites.net/api/api/';
// const site_name = 'http://localhost/trustedsource/api/api/';
//const site_name = 'https://trustedsourcepilot.azurewebsites.net/api/api/';


		  //const site_name =   'https://apitrustedsource.azurewebsites.net/api/';
		  
		  const site_name ='http://172.16.14.175:81/ts/api/';

//const site_name = 'https://trustedsourcepilotapi.azurewebsites.net/tsourcedev/index.php/api/';
// const site_name = 'http://localhost/trustedsource_api/api/';
let UserAPI = {
    UserLogin(values){
		
			return fetch(site_name+'login',{
				method: "POST",
				body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	UserRegister(values){
			return fetch(site_name+'userregister',{
				method: "POST",
				body: JSON.stringify(values),
		}).then((response)=>response.json());
	},


	// UserLogout(){
	// 	return fetch(site_name+'logout',{
	// 		method: "GET",
	// 	}).then((response)=>response.json());
	// },

	UserLogout(values){
			return fetch(site_name+'logout',{
				method: "POST",
				body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	
	ForgotPassword(values){
		return fetch(site_name+'rememberme',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ResetPassword(values){
		return fetch(site_name+'resetrequest',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	

	UserDashboard(values){
		return fetch(site_name+'dashboard',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},


	CompnayName(){
		return fetch(site_name+'companyautocomplete',{
				method: "POST",
		}).then((response)=>response.json());
	},


	ProductList(values){
		return fetch(site_name+'productlist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	UploadExcel(file){
		const url = site_name+'excelimport';
		const formData = new FormData();
		formData.append('file_upload',file.files)
		formData.append('token',file.token)
		return  post(url, formData)
	},

	UploadXML(file){
		const url = site_name+'xmlimport';
		const formData = new FormData();
		formData.append('file_upload',file.files)
		formData.append('token',file.token)
		return  post(url, formData)
	},

	UploadDataNetXML(file){
		const url = site_name+'datanetxmlimport';
		const formData = new FormData();
		formData.append('file_upload',file.files)
		formData.append('token',file.token)
		return  post(url, formData)
	},

	UploadAssets(files){
		return fetch(site_name+'assetimport',{
			method: "POST",
			body: JSON.stringify(files),
		}).then((response)=>response.json());
	},

	FilterDataList(values){
		return fetch(site_name+'filter_product_details',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ManualQCSupplierFilter(values){
		return fetch(site_name+'manualQcFilter',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ManageBasket(values){
		return fetch(site_name+'manage_basket_products',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	
	AddProduct(values){
		return fetch(site_name+'addproduct',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	UpdateProduct(values){
		return fetch(site_name+'editproduct',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ProductOptionsList(values){
		return fetch(site_name+'productoptionslist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	SubCategoryList(values){
		return fetch(site_name+'subcategorylist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	
	CompanyTypeList(values){
		return fetch(site_name+'companytypelist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	MarketList(values){
		return fetch(site_name+'targetmarketlist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ExportExcel(values){
		return fetch(site_name+'exportexcelfile',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	ExportPdf(values){
		return fetch(site_name+'exportpdffile',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	loadFormData(values){
		return fetch(site_name+'editproductlist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	loadCompanyData(values){
		return fetch(site_name+'companydetails',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	loadNutritionData(values){
		return fetch(site_name+'nutritionlist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	productsynclist(values){
		return fetch(site_name+'productsynclist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},

	producttotalquantity(values){
		return fetch(site_name+'producttotalquantity',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	CompanyList(values){
		return fetch(site_name+'companylist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	CompanySave(values){
		console.log(values);
		return fetch(site_name+'savecompany',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	PrefixSave(values){
		return fetch(site_name+'create_prefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	PrefixModify(values){		
		return fetch(site_name+'update_prefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	SearchPrefix(values){		
		return fetch(site_name+'search_prefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	UserList(values){
		return fetch(site_name+'userlist',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	UserSave(values){
		return fetch(site_name+'insertuser',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	loadUserFormData(values){
		return fetch(site_name+'getuser',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	UpdateUser(values){
		console.log(values);
		return fetch(site_name+'updateuser',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	PrefixListing(values){
		return fetch(site_name+'get_prefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	DeletePrefix(values){
		return fetch(site_name+'deleteprefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	updateCompany(values){
		return fetch(site_name+'updatecompany',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	DeleteCompany(values){
		return fetch(site_name+'deletecompany',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	TransferPrefix(values){
		return fetch(site_name+'transferprefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	SuspendPrefix(values){
		return fetch(site_name+'suspendprefix',{
			method: "POST",
			body: JSON.stringify(values),			
		}).then((response)=>response.json());
	},
	getLanguageCode(values){
		return fetch(site_name+'languagecode',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	AutoQcListing(values){
		return fetch(site_name+'autoqcdata',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	ManualQcListing(values){
	
		return fetch(site_name+'manualqcdata',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	GetAutoQcDetails(values){
		return fetch(site_name+'getautoqcbyid',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	GetManualQcDetails(values){
		return fetch(site_name+'getautoqcbyid',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	GetAutoRevisionQcDetails(values){
		return fetch(site_name+'getautoqcrevisionbyid',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	GetManualRevisionQcDetails(values){
		return fetch(site_name+'getautoqcrevisionbyid',{
			method: "POST",
			body: JSON.stringify(values),
		}).then((response)=>response.json());
	},
	
}
export default UserAPI;



// try {
// 	const response = await fetch(url, {
// 	  method: 'POST', // or 'PUT'
// 	  body: JSON.stringify(data), // data can be `string` or {object}!
// 	  headers: {
// 		'Content-Type': 'application/json'
// 	  }
// 	});
// 	const json = await response.json();
// 	console.log('Success:', JSON.stringify(json));
//   } catch (error) {
// 	console.error('Error:', error);
//   }


// headers: {
// 	'Content-Type': 'application/json'
//   },