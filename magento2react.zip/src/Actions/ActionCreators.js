import { PRODUCT_GET_REQUESTED, PRODUCT_GET_RECEIVED, PRODUCT_GET_ERROR,
    PRODUCT_INSERT_REQUESTED,PRODUCT_INSERT_RECEIVED,PRODUCT_INSERT_ERROR } from './Actions';
import WebApi from '../Api';

const ActionCreators = {
    GetProduct() {
        return (dispatch) => {
            dispatch({ type: PRODUCT_GET_REQUESTED, success: true, payload: 'Get products...' })
            WebApi.GetProduct().then(
                (productdetails) => {
                    console.log(productdetails.items);
                    dispatch({
                        type: PRODUCT_GET_RECEIVED, success: true, payload: {                            
                            products: productdetails.items
                        }
                    })
                },
                (error) => dispatch({ type: PRODUCT_GET_ERROR, success: false, payload: error.message })
            )
                .catch(
                    (error) => dispatch({ type: PRODUCT_GET_ERROR, success: false, payload: error.message })
                )
        }
    },
    InsertProduct() {
        return (dispatch) => {
            dispatch({ type: PRODUCT_INSERT_REQUESTED, success: true, payload: 'Insert products...' })
            WebApi.InsertProduct().then(
                (insertproductdetails) => {
                    dispatch({
                        type: PRODUCT_INSERT_RECEIVED, success: true, payload: {                            
                            insertproduct: insertproductdetails
                        }
                    })
                },
                (error) => dispatch({ type: PRODUCT_INSERT_ERROR, success: false, payload: error.message })
            )
                .catch(
                    (error) => dispatch({ type: PRODUCT_INSERT_ERROR, success: false, payload: error.message })
                )
        }
    },
}
export default ActionCreators;