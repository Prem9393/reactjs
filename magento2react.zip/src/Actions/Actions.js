export const PRODUCT_GET_REQUESTED ="Product requested";
export const PRODUCT_GET_RECEIVED ="Product received";
export const PRODUCT_GET_ERROR = "Product Error";

export const PRODUCT_INSERT_REQUESTED ="Product requested";
export const PRODUCT_INSERT_RECEIVED ="Product received";
export const PRODUCT_INSERT_ERROR = "Product Error";