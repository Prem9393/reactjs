
const AppValidation = {	


	ValidateInsertProductForm(values){
		const errors = {}
		
		if (!values.productname) {
			errors.productname = 'Product Name is Required';
		} 

		return errors
		  
	},



};

export default AppValidation;


export const normalizeMaxLength = max => value => {
    if(!value)
          return value;
     if (value.length <= max){
         return value;
       }
     }  
    
    
export const normalizeNumber = values => {
    const onlyNums =/^[0-9]\d*$/.test(values);

    if(!values)
      return values;

    if (onlyNums)
       return values;
}

export const validateEmail = value => { 
    
    return value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
    ? 'Invalid email address'
    : undefined
}


export const normalizeNumberAndSetLimit = max=> values => {
	const errors = {}

    const onlyNums =/^[0-9]\d*$/.test(values);
    if(!values)
	   return values;
	
    //  if(values){
	// 	if(isNaN(Number(values))){
	// 		AppValidation.ValidateEditProductForm( {shr_GTIN: values})
	// 	    } 
	//   }

    if (onlyNums)
        if (values.length <= max){
         return values;
       }  
}


export const requiredNumberAndSetLimit = max=> values =>{
	
	const onlyNums =/^[0-9]\d*$/.test(values);
    if(!values)
       return values;

    if (onlyNums)
        if (values.length <= max){
         return values;
       }  

	return 'GTIN field should be Numbers';
}

