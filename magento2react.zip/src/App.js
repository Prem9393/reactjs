import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import AppStore from './Store/AppStore'
import ActionCreators from './Actions/ActionCreators';
import {Provider, connect} from 'react-redux';
import WebRouter from './Container/WebRouter';

const mapStateToProps = (state) => ({
  products:state.products.products, 
})


const mapDispatchToProps = (dispatch) => ({
  GetProduct: () => dispatch(ActionCreators.GetProduct()),
  InsertProduct: () =>  dispatch(ActionCreators.InsertProduct()),
})

const MainComponent  = connect(mapStateToProps, mapDispatchToProps)(WebRouter);

class App extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      items: []
    };
  }
  

  render() {    
      return (
        <Provider store={AppStore}><MainComponent/></Provider>
      );
  }
}

export default App;