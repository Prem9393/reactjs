
const url = 'http://127.0.0.1/SKWAD/';

let UserAPI = {
  GetProduct() {
    return fetch(url + 'm2api', {
      method: "POST",
    }).then((response) => response.json());
  },
  InsertProduct() {
    return fetch(url + 'm2api/insertproduct', {
      method: "POST",
    }).then((response) => response.json());
  }
}

export default UserAPI;

