import {PRODUCT_INSERT_REQUESTED, PRODUCT_INSERT_RECEIVED, PRODUCT_INSERT_ERROR} from '../Actions/Actions';


const initailstate = {
    products:[],
}

const InsertProductReducer = (state = initailstate, action) =>{
    switch(action.type){     

        case PRODUCT_INSERT_REQUESTED:
        return {...state, registermessage:action.payload};

        case PRODUCT_INSERT_RECEIVED:
        return Object.assign({}, state, action.payload);

        case PRODUCT_INSERT_ERROR:
        return {...state, registermessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default InsertProductReducer;