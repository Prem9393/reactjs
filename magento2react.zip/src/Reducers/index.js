import { combineReducers } from 'redux';
import {reducer as reduxFormReducer } from 'redux-form'
import productreducer from './ProductReducer';

const RootReducer = combineReducers({
	form: reduxFormReducer,
	products: productreducer,
});

export default RootReducer;