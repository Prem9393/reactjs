import {PRODUCT_GET_REQUESTED, PRODUCT_GET_RECEIVED, PRODUCT_GET_ERROR} from '../Actions/Actions';


const initailstate = {
    products:[],
}

const ProductReducer = (state = initailstate, action) =>{
    switch(action.type){     

        case PRODUCT_GET_REQUESTED:
        return {...state, registermessage:action.payload};

        case PRODUCT_GET_RECEIVED:
        return Object.assign({}, state, action.payload);

        case PRODUCT_GET_ERROR:
        return {...state, registermessage:action.payload};

        default :
        return Object.assign({}, state)

    }
}


export default ProductReducer;