import React, { Component } from 'react';

class ProdutDetails extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      items: []
    };

  }

  componentDidMount() {
    this.props.GetProduct()
  }

  render() {   
      console.log("123",this.props.products); 
      return (
        <div>
          {this.props.products != undefined && this.props.products.map((product, index) => (
              <div key={index}>
                  <div><p> Title: {product.name}</p></div>
                  <div><p> Price: {product.price}</p></div>
                  <div><p> SKU: {product.sku}</p></div>
              </div>
            ))
          }
          </div>
     );
  }
}

export default ProdutDetails;