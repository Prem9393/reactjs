import React, { Component } from 'react';
import { connect } from 'react-redux';
import Validation from '../../Validations';
import { reduxForm, Field } from 'redux-form';
import { Button } from 'react-bootstrap';
import Common from '../../Common';


class InsertProduct extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      items: []
    };
    this.insertProduct = this.insertProduct.bind(this);
  }

  componentDidMount() {
    this.props.GetProduct()
  }

  insertProduct() {
    alert(1);
  }


  render() {   
      const {  handleSubmit } = this.props;

      return (
        <div>
          <form name="product-insert-frm" onSubmit={handleSubmit(this.insertProduct.bind(this))}>
              <Field name="productname" component={Common.renderInput} type="text" id="productname" className="form-control hsmall" />
              <Button type="submit" id="product_save_option" className="btn btn-primary btn-block"  value="Save">Save</Button>
          </form>
        </div>
     );
  }
}
export default reduxForm({
  form: 'InsertProductForm',
  validate:Validation.ValidateInsertProductForm
})(InsertProduct);
