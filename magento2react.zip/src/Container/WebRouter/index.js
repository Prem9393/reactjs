import React,{Component} from 'react';
import {HashRouter as Router, Route, Switch}  from 'react-router-dom';
import ProductDetails from '../ProductDetails';
import InsertProduct from '../InsertProduct';



class WebRouter extends Component{
	constructor(props) {
		super(props);

	}

	render(){
		return  <Router>
					<Switch>
						<Route exact path="/"   render = {(props)=> <ProductDetails {...props}  {...this.props}/>} />
						<Route  path="/insertproduct"   render = {(props)=> <InsertProduct {...props}  {...this.props}/>} />
					</Switch>
			    </Router>
	}
}


export default WebRouter;